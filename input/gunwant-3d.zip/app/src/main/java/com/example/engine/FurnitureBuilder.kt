package com.example.engine

import com.example.model.BoxPart3D
import com.example.model.CutListItem
import com.example.model.CutListSummary
import com.example.model.FurnitureType
import com.example.model.PartCategory
import com.example.model.StudioConfig
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

object FurnitureBuilder {

    private const val MM2_PER_SQFT = 92903.04f
    private const val SQFT_PER_8X4_SHEET = 32f

    fun buildParts(config: StudioConfig): List<BoxPart3D> {
        return when (config.furnitureType) {
            FurnitureType.WARDROBE -> buildWardrobe(config)
            FurnitureType.SLIDING_WARDROBE -> buildSlidingWardrobe(config)
            FurnitureType.KITCHEN_CABINET -> buildKitchenCabinet(config)
            FurnitureType.POOJA_UNIT -> buildPoojaUnit(config)
            FurnitureType.SHOE_RACK -> buildShoeRack(config)
            FurnitureType.DRAWER_CHEST -> buildDrawerChest(config)
            FurnitureType.STUDY_DESK -> buildStudyDesk(config)
            FurnitureType.TV_CONSOLE -> buildTvConsole(config)
            FurnitureType.BOOKSHELF -> buildBookshelf(config)
            FurnitureType.STORAGE_BED -> buildStorageBed(config)
            FurnitureType.COFFEE_TABLE -> buildCoffeeTable(config)
        }
    }

    fun buildCutList(parts: List<BoxPart3D>): CutListSummary {
        val boardParts = parts.filter { !it.isHardware }
        val grouped = boardParts.groupBy { it.groupId }
        val items = grouped.map { (groupId, groupParts) ->
            val first = groupParts.first()
            val dims = listOf(first.sizeX, first.sizeY, first.sizeZ).sortedDescending()
            val lengthMm = dims[0]
            val widthMm = dims[1]
            val thicknessMm = dims[2]
            val singleAreaSqFt = (lengthMm * widthMm) / MM2_PER_SQFT
            CutListItem(
                groupId = groupId,
                nameEn = first.nameEn,
                nameMr = first.nameMr,
                category = first.category,
                qty = groupParts.size,
                lengthMm = lengthMm,
                widthMm = widthMm,
                thicknessMm = thicknessMm,
                totalAreaSqFt = singleAreaSqFt * groupParts.size,
                edgeBandingEn = first.edgeBandingEn,
                edgeBandingMr = first.edgeBandingMr,
            )
        }
        val totalPieces = items.sumOf { it.qty }
        val totalArea = items.sumOf { it.totalAreaSqFt.toDouble() }.toFloat()
        val sheets = max(1, ceil((totalArea * 1.12f) / SQFT_PER_8X4_SHEET).toInt())
        return CutListSummary(
            items = items,
            totalPieces = totalPieces,
            totalAreaSqFt = totalArea,
            estimatedSheets8x4 = sheets,
        )
    }

    private fun buildWardrobe(c: StudioConfig): List<BoxPart3D> {
        val w = c.widthMm
        val h = c.heightMm
        val d = c.depthMm
        val t = c.thicknessMm
        val backT = 8f
        val plinthH = 85f
        val carcassD = d - t
        val carcassZ = -t / 2f
        val innerW = w - 2f * t
        val innerH = h - plinthH - 2f * t
        val sideH = h - plinthH
        val sideCenterY = plinthH + sideH / 2f
        val parts = mutableListOf<BoxPart3D>()

        parts += BoxPart3D(
            id = "plinth_front",
            groupId = "wardrobe_plinth",
            nameEn = "Plinth Skirting",
            nameMr = "तळ पट्टी (Plinth)",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = plinthH / 2f,
            centerZ = carcassZ + carcassD / 2f - t * 1.5f,
            sizeX = w - 2f * t,
            sizeY = plinthH,
            sizeZ = t,
            explodeY = -0.6f,
            explodeZ = 0.5f,
            edgeBandingEn = "Top edge",
            edgeBandingMr = "वरची कडा",
        )

        parts += BoxPart3D(
            id = "side_left",
            groupId = "wardrobe_sides",
            nameEn = "Side Panel",
            nameMr = "बाजूचा पत्रा (Side)",
            category = PartCategory.CARCASS,
            centerX = -w / 2f + t / 2f,
            centerY = sideCenterY,
            centerZ = carcassZ,
            sizeX = t,
            sizeY = sideH,
            sizeZ = carcassD,
            explodeX = -1.2f,
            edgeBandingEn = "Front + Top",
            edgeBandingMr = "समोर + वर",
        )
        parts += BoxPart3D(
            id = "side_right",
            groupId = "wardrobe_sides",
            nameEn = "Side Panel",
            nameMr = "बाजूचा पत्रा (Side)",
            category = PartCategory.CARCASS,
            centerX = w / 2f - t / 2f,
            centerY = sideCenterY,
            centerZ = carcassZ,
            sizeX = t,
            sizeY = sideH,
            sizeZ = carcassD,
            explodeX = 1.2f,
            edgeBandingEn = "Front + Top",
            edgeBandingMr = "समोर + वर",
        )

        parts += BoxPart3D(
            id = "bottom_panel",
            groupId = "wardrobe_top_bottom",
            nameEn = "Top / Bottom Panel",
            nameMr = "वरचा / खालचा पत्रा",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = plinthH + t / 2f,
            centerZ = carcassZ,
            sizeX = innerW,
            sizeY = t,
            sizeZ = carcassD,
            explodeY = -0.9f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )
        parts += BoxPart3D(
            id = "top_panel",
            groupId = "wardrobe_top_bottom",
            nameEn = "Top / Bottom Panel",
            nameMr = "वरचा / खालचा पत्रा",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = h - t / 2f,
            centerZ = carcassZ,
            sizeX = innerW,
            sizeY = t,
            sizeZ = carcassD,
            explodeY = 1.1f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )

        parts += BoxPart3D(
            id = "back_ply",
            groupId = "wardrobe_back",
            nameEn = "Back Ply (8mm)",
            nameMr = "मागील प्लाय (8mm)",
            category = PartCategory.BACK,
            centerX = 0f,
            centerY = sideCenterY,
            centerZ = carcassZ - carcassD / 2f - backT / 2f,
            sizeX = w - 6f,
            sizeY = sideH - 6f,
            sizeZ = backT,
            explodeZ = -1.3f,
            isBackPly = true,
            edgeBandingEn = "None",
            edgeBandingMr = "गरज नाही",
        )

        parts += BoxPart3D(
            id = "center_divider",
            groupId = "wardrobe_divider",
            nameEn = "Center Divider",
            nameMr = "मधला उभा भाग",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = plinthH + t + innerH / 2f,
            centerZ = carcassZ - 4f,
            sizeX = t,
            sizeY = innerH,
            sizeZ = carcassD - 10f,
            explodeZ = 0.3f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )

        val bayW = (innerW - t) / 2f
        val leftBayX = -t / 2f - bayW / 2f
        val rightBayX = t / 2f + bayW / 2f
        val shelfD = carcassD - 24f

        val loftY = h - t - innerH * 0.22f
        parts += BoxPart3D(
            id = "left_top_shelf",
            groupId = "wardrobe_shelves",
            nameEn = "Bay Shelf",
            nameMr = "कप्प्याचा शेल्फ",
            category = PartCategory.SHELF,
            centerX = leftBayX,
            centerY = loftY,
            centerZ = carcassZ - 6f,
            sizeX = bayW,
            sizeY = t,
            sizeZ = shelfD,
            explodeX = -0.3f,
            explodeZ = 0.4f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )
        parts += BoxPart3D(
            id = "hanging_rod",
            groupId = "wardrobe_rod",
            nameEn = "Hanger Rod",
            nameMr = "हँगर रॉड",
            category = PartCategory.HARDWARE,
            centerX = leftBayX,
            centerY = loftY - 75f,
            centerZ = carcassZ,
            sizeX = bayW - 10f,
            sizeY = 22f,
            sizeZ = 22f,
            isHardware = true,
            explodeZ = 0.5f,
        )

        // Internal drawers on right bay bottom if drawerCount > 0
        val internalDrawers = c.drawerCount.coerceIn(0, 2)
        val drawerH = 165f
        val drawerReserveH = if (internalDrawers > 0) internalDrawers * (drawerH + 10f) + t else 0f
        if (internalDrawers > 0) {
            val topCoverY = plinthH + t + drawerReserveH - t / 2f
            parts += BoxPart3D(
                id = "drawer_cover_shelf",
                groupId = "wardrobe_shelves",
                nameEn = "Bay Shelf",
                nameMr = "कप्प्याचा शेल्फ",
                category = PartCategory.SHELF,
                centerX = rightBayX,
                centerY = topCoverY,
                centerZ = carcassZ - 6f,
                sizeX = bayW,
                sizeY = t,
                sizeZ = shelfD,
                explodeZ = 0.5f,
                edgeBandingEn = "Front edge",
                edgeBandingMr = "समोरची कडा",
            )
            for (di in 0 until internalDrawers) {
                val dy = plinthH + t + drawerH / 2f + 4f + di * (drawerH + 6f)
                parts += BoxPart3D(
                    id = "inner_drawer_$di",
                    groupId = "wardrobe_inner_drawers",
                    nameEn = "Inner Drawer Front",
                    nameMr = "आतील ड्रॉवर",
                    category = PartCategory.DOOR,
                    centerX = rightBayX,
                    centerY = dy,
                    centerZ = carcassZ + shelfD / 2f - 10f,
                    sizeX = bayW - 16f,
                    sizeY = drawerH - 8f,
                    sizeZ = t,
                    explodeZ = 0.9f,
                    isDoorOrFront = true,
                    slideOffsetZMaxMm = if (di == internalDrawers - 1) 120f else 30f,
                    edgeBandingEn = "All 4 edges",
                    edgeBandingMr = "चारही बाजू",
                )
            }
        }

        val rightShelfCount = max(1, min(6, c.shelfCount))
        val availShelfH = innerH - drawerReserveH
        val stepY = availShelfH / (rightShelfCount + 1)
        for (i in 1..rightShelfCount) {
            parts += BoxPart3D(
                id = "right_shelf_$i",
                groupId = "wardrobe_shelves",
                nameEn = "Bay Shelf",
                nameMr = "कप्प्याचा शेल्फ",
                category = PartCategory.SHELF,
                centerX = rightBayX,
                centerY = plinthH + t + drawerReserveH + stepY * i,
                centerZ = carcassZ - 6f,
                sizeX = bayW,
                sizeY = t,
                sizeZ = shelfD,
                explodeX = 0.3f,
                explodeZ = 0.5f,
                edgeBandingEn = "Front edge",
                edgeBandingMr = "समोरची कडा",
            )
        }

        val doorGap = 4f
        val doorW = (w - doorGap * 3f) / 2f
        val doorH = sideH - 4f
        val doorZ = carcassZ + carcassD / 2f + t / 2f + 2f
        parts += BoxPart3D(
            id = "door_left",
            groupId = "wardrobe_doors",
            nameEn = "Shutter Door",
            nameMr = "समोरचा दरवाजा",
            category = PartCategory.DOOR,
            centerX = -doorW / 2f - doorGap / 2f,
            centerY = sideCenterY,
            centerZ = doorZ,
            sizeX = doorW,
            sizeY = doorH,
            sizeZ = t,
            explodeZ = 1.4f,
            explodeX = -0.4f,
            isDoorOrFront = true,
            swingPivotX = -w / 2f + doorGap,
            swingPivotZ = doorZ,
            swingAngleMaxDeg = 82f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )
        parts += BoxPart3D(
            id = "door_right",
            groupId = "wardrobe_doors",
            nameEn = "Shutter Door",
            nameMr = "समोरचा दरवाजा",
            category = PartCategory.DOOR,
            centerX = doorW / 2f + doorGap / 2f,
            centerY = sideCenterY,
            centerZ = doorZ,
            sizeX = doorW,
            sizeY = doorH,
            sizeZ = t,
            explodeZ = 1.4f,
            explodeX = 0.4f,
            isDoorOrFront = true,
            swingPivotX = w / 2f - doorGap,
            swingPivotZ = doorZ,
            swingAngleMaxDeg = -82f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )

        val handleH = min(280f, doorH * 0.22f)
        val handleZ = doorZ + t / 2f + 10f
        parts += BoxPart3D(
            id = "handle_left",
            groupId = "wardrobe_handles",
            nameEn = "Door Handle",
            nameMr = "दरवाजा हँडल",
            category = PartCategory.HARDWARE,
            centerX = -32f,
            centerY = sideCenterY,
            centerZ = handleZ,
            sizeX = 16f,
            sizeY = handleH,
            sizeZ = 20f,
            explodeZ = 1.6f,
            explodeX = -0.4f,
            isHardware = true,
            swingPivotX = -w / 2f + doorGap,
            swingPivotZ = doorZ,
            swingAngleMaxDeg = 82f,
        )
        parts += BoxPart3D(
            id = "handle_right",
            groupId = "wardrobe_handles",
            nameEn = "Door Handle",
            nameMr = "दरवाजा हँडल",
            category = PartCategory.HARDWARE,
            centerX = 32f,
            centerY = sideCenterY,
            centerZ = handleZ,
            sizeX = 16f,
            sizeY = handleH,
            sizeZ = 20f,
            explodeZ = 1.6f,
            explodeX = 0.4f,
            isHardware = true,
            swingPivotX = w / 2f - doorGap,
            swingPivotZ = doorZ,
            swingAngleMaxDeg = -82f,
        )

        return parts
    }

    private fun buildSlidingWardrobe(c: StudioConfig): List<BoxPart3D> {
        val w = c.widthMm
        val h = c.heightMm
        val d = c.depthMm
        val t = c.thicknessMm
        val trackZone = 68f
        val carcassD = d - trackZone
        val carcassZ = -trackZone / 2f
        val plinthH = 85f
        val sideH = h - plinthH
        val sideCenterY = plinthH + sideH / 2f
        val innerW = w - 2f * t
        val innerH = sideH - 2f * t
        val parts = mutableListOf<BoxPart3D>()

        // Plinth
        parts += BoxPart3D(
            id = "sw_plinth",
            groupId = "sw_plinth",
            nameEn = "Plinth Skirting",
            nameMr = "तळ पट्टी (Plinth)",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = plinthH / 2f,
            centerZ = carcassZ + carcassD / 2f - t,
            sizeX = innerW,
            sizeY = plinthH,
            sizeZ = t,
            explodeY = -0.6f,
            edgeBandingEn = "Top edge",
            edgeBandingMr = "वरची कडा",
        )

        // Outer Sides (full depth for sliding track hood)
        parts += BoxPart3D(
            id = "sw_side_l",
            groupId = "sw_sides",
            nameEn = "Outer Side Panel",
            nameMr = "बाजूचा पत्रा (Side)",
            category = PartCategory.CARCASS,
            centerX = -w / 2f + t / 2f,
            centerY = sideCenterY,
            centerZ = 0f,
            sizeX = t,
            sizeY = sideH,
            sizeZ = d,
            explodeX = -1.2f,
            edgeBandingEn = "Front + Top",
            edgeBandingMr = "समोर + वर",
        )
        parts += BoxPart3D(
            id = "sw_side_r",
            groupId = "sw_sides",
            nameEn = "Outer Side Panel",
            nameMr = "बाजूचा पत्रा (Side)",
            category = PartCategory.CARCASS,
            centerX = w / 2f - t / 2f,
            centerY = sideCenterY,
            centerZ = 0f,
            sizeX = t,
            sizeY = sideH,
            sizeZ = d,
            explodeX = 1.2f,
            edgeBandingEn = "Front + Top",
            edgeBandingMr = "समोर + वर",
        )

        // Top & Bottom (full depth to carry aluminum track channels)
        parts += BoxPart3D(
            id = "sw_bottom",
            groupId = "sw_top_bottom",
            nameEn = "Top / Bottom Slab",
            nameMr = "वरचा / खालचा पत्रा",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = plinthH + t / 2f,
            centerZ = 0f,
            sizeX = innerW,
            sizeY = t,
            sizeZ = d,
            explodeY = -0.8f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )
        parts += BoxPart3D(
            id = "sw_top",
            groupId = "sw_top_bottom",
            nameEn = "Top / Bottom Slab",
            nameMr = "वरचा / खालचा पत्रा",
            category = PartCategory.TOP,
            centerX = 0f,
            centerY = h - t / 2f,
            centerZ = 0f,
            sizeX = innerW,
            sizeY = t,
            sizeZ = d,
            explodeY = 1.1f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )

        // Back ply
        parts += BoxPart3D(
            id = "sw_back",
            groupId = "sw_back",
            nameEn = "Back Ply (8mm)",
            nameMr = "मागील प्लाय (8mm)",
            category = PartCategory.BACK,
            centerX = 0f,
            centerY = sideCenterY,
            centerZ = -d / 2f - 4f,
            sizeX = w - 6f,
            sizeY = sideH - 6f,
            sizeZ = 8f,
            explodeZ = -1.3f,
            isBackPly = true,
            edgeBandingEn = "None",
            edgeBandingMr = "गरज नाही",
        )

        // 2 vertical dividers -> 3 bays
        val bayW = (innerW - 2f * t) / 3f
        val divX = bayW / 2f + t / 2f
        parts += BoxPart3D(
            id = "sw_div_l",
            groupId = "sw_dividers",
            nameEn = "Bay Divider",
            nameMr = "आतील पार्टीशन",
            category = PartCategory.CARCASS,
            centerX = -divX,
            centerY = plinthH + t + innerH / 2f,
            centerZ = carcassZ,
            sizeX = t,
            sizeY = innerH,
            sizeZ = carcassD,
            explodeZ = 0.3f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )
        parts += BoxPart3D(
            id = "sw_div_r",
            groupId = "sw_dividers",
            nameEn = "Bay Divider",
            nameMr = "आतील पार्टीशन",
            category = PartCategory.CARCASS,
            centerX = divX,
            centerY = plinthH + t + innerH / 2f,
            centerZ = carcassZ,
            sizeX = t,
            sizeY = innerH,
            sizeZ = carcassD,
            explodeZ = 0.3f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )

        // Left & Right bays: hanging rod + top shelf
        val loftY = h - t - innerH * 0.22f
        listOf(-bayW - t, bayW + t).forEachIndexed { idx, bx ->
            parts += BoxPart3D(
                id = "sw_loft_$idx",
                groupId = "sw_shelves",
                nameEn = "Bay Shelf",
                nameMr = "कप्प्याचा शेल्फ",
                category = PartCategory.SHELF,
                centerX = bx,
                centerY = loftY,
                centerZ = carcassZ,
                sizeX = bayW,
                sizeY = t,
                sizeZ = carcassD - 16f,
                explodeZ = 0.4f,
                edgeBandingEn = "Front edge",
                edgeBandingMr = "समोरची कडा",
            )
            parts += BoxPart3D(
                id = "sw_rod_$idx",
                groupId = "sw_rods",
                nameEn = "Hanger Rod",
                nameMr = "हँगर रॉड",
                category = PartCategory.HARDWARE,
                centerX = bx,
                centerY = loftY - 75f,
                centerZ = carcassZ,
                sizeX = bayW - 10f,
                sizeY = 22f,
                sizeZ = 22f,
                isHardware = true,
            )
        }

        // Center bay: internal drawers + adjustable shelves
        val internalDrawers = c.drawerCount.coerceIn(0, 2)
        val drawerH = 165f
        val drawerReserve = if (internalDrawers > 0) internalDrawers * (drawerH + 10f) + t else 0f
        if (internalDrawers > 0) {
            parts += BoxPart3D(
                id = "sw_drawer_top",
                groupId = "sw_shelves",
                nameEn = "Bay Shelf",
                nameMr = "कप्प्याचा शेल्फ",
                category = PartCategory.SHELF,
                centerX = 0f,
                centerY = plinthH + t + drawerReserve - t / 2f,
                centerZ = carcassZ,
                sizeX = bayW,
                sizeY = t,
                sizeZ = carcassD - 16f,
                edgeBandingEn = "Front edge",
                edgeBandingMr = "समोरची कडा",
            )
            for (di in 0 until internalDrawers) {
                val dy = plinthH + t + drawerH / 2f + 4f + di * (drawerH + 6f)
                parts += BoxPart3D(
                    id = "sw_inner_drawer_$di",
                    groupId = "sw_drawers",
                    nameEn = "Inner Drawer Front",
                    nameMr = "आतील ड्रॉवर",
                    category = PartCategory.DOOR,
                    centerX = 0f,
                    centerY = dy,
                    centerZ = carcassZ + carcassD / 2f - 18f,
                    sizeX = bayW - 16f,
                    sizeY = drawerH - 8f,
                    sizeZ = t,
                    isDoorOrFront = true,
                    edgeBandingEn = "All 4 edges",
                    edgeBandingMr = "चारही बाजू",
                )
            }
        }

        val shelfCount = max(1, min(6, c.shelfCount))
        val availH = innerH - drawerReserve
        val step = availH / (shelfCount + 1)
        for (i in 1..shelfCount) {
            parts += BoxPart3D(
                id = "sw_center_shelf_$i",
                groupId = "sw_shelves",
                nameEn = "Bay Shelf",
                nameMr = "कप्प्याचा शेल्फ",
                category = PartCategory.SHELF,
                centerX = 0f,
                centerY = plinthH + t + drawerReserve + step * i,
                centerZ = carcassZ,
                sizeX = bayW,
                sizeY = t,
                sizeZ = carcassD - 16f,
                explodeZ = 0.5f,
                edgeBandingEn = "Front edge",
                edgeBandingMr = "समोरची कडा",
            )
        }

        // Aluminum Top & Bottom Sliding Track Bars
        val trackZ = d / 2f - trackZone / 2f
        parts += BoxPart3D(
            id = "sw_track_top",
            groupId = "sw_tracks",
            nameEn = "Sliding Track Rail",
            nameMr = "स्लायडिंग चॅनेल",
            category = PartCategory.HARDWARE,
            centerX = 0f,
            centerY = h - t - 8f,
            centerZ = trackZ,
            sizeX = innerW,
            sizeY = 16f,
            sizeZ = trackZone - 12f,
            isHardware = true,
        )
        parts += BoxPart3D(
            id = "sw_track_bottom",
            groupId = "sw_tracks",
            nameEn = "Sliding Track Rail",
            nameMr = "स्लायडिंग चॅनेल",
            category = PartCategory.HARDWARE,
            centerX = 0f,
            centerY = plinthH + t + 6f,
            centerZ = trackZ,
            sizeX = innerW,
            sizeY = 12f,
            sizeZ = trackZone - 12f,
            isHardware = true,
        )

        // 3 Overlapping Sliding Doors (left & right on front track, center on rear track)
        val doorW = innerW / 3f + 22f
        val doorH = innerH - 12f
        val doorCenterY = plinthH + t + innerH / 2f
        val frontTrackZ = d / 2f - t / 2f - 8f
        val rearTrackZ = frontTrackZ - t - 10f
        val shift = innerW / 3f - 10f

        parts += BoxPart3D(
            id = "sw_door_left",
            groupId = "sw_doors",
            nameEn = "Sliding Shutter",
            nameMr = "स्लायडिंग दरवाजा",
            category = PartCategory.DOOR,
            centerX = -innerW / 3f,
            centerY = doorCenterY,
            centerZ = frontTrackZ,
            sizeX = doorW,
            sizeY = doorH,
            sizeZ = t,
            explodeZ = 1.4f,
            isDoorOrFront = true,
            slideOffsetXMaxMm = shift,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )
        parts += BoxPart3D(
            id = "sw_door_center",
            groupId = "sw_doors",
            nameEn = "Sliding Shutter",
            nameMr = "स्लायडिंग दरवाजा",
            category = PartCategory.DOOR,
            centerX = 0f,
            centerY = doorCenterY,
            centerZ = rearTrackZ,
            sizeX = doorW,
            sizeY = doorH,
            sizeZ = t,
            explodeZ = 1.1f,
            isDoorOrFront = true,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )
        parts += BoxPart3D(
            id = "sw_door_right",
            groupId = "sw_doors",
            nameEn = "Sliding Shutter",
            nameMr = "स्लायडिंग दरवाजा",
            category = PartCategory.DOOR,
            centerX = innerW / 3f,
            centerY = doorCenterY,
            centerZ = frontTrackZ,
            sizeX = doorW,
            sizeY = doorH,
            sizeZ = t,
            explodeZ = 1.4f,
            isDoorOrFront = true,
            slideOffsetXMaxMm = -shift,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )

        // Recessed aluminum profile handles on outer doors
        val handleH = min(380f, doorH * 0.28f)
        parts += BoxPart3D(
            id = "sw_handle_l",
            groupId = "sw_handles",
            nameEn = "Profile Handle",
            nameMr = "स्लायडिंग हँडल",
            category = PartCategory.HARDWARE,
            centerX = -innerW / 2f + 36f,
            centerY = doorCenterY,
            centerZ = frontTrackZ + t / 2f + 4f,
            sizeX = 14f,
            sizeY = handleH,
            sizeZ = 8f,
            explodeZ = 1.5f,
            isHardware = true,
            slideOffsetXMaxMm = shift,
        )
        parts += BoxPart3D(
            id = "sw_handle_r",
            groupId = "sw_handles",
            nameEn = "Profile Handle",
            nameMr = "स्लायडिंग हँडल",
            category = PartCategory.HARDWARE,
            centerX = innerW / 2f - 36f,
            centerY = doorCenterY,
            centerZ = frontTrackZ + t / 2f + 4f,
            sizeX = 14f,
            sizeY = handleH,
            sizeZ = 8f,
            explodeZ = 1.5f,
            isHardware = true,
            slideOffsetXMaxMm = -shift,
        )

        return parts
    }

    private fun buildKitchenCabinet(c: StudioConfig): List<BoxPart3D> {
        val w = c.widthMm
        val h = c.heightMm
        val d = c.depthMm
        val t = c.thicknessMm
        val counterT = 28f
        val plinthH = 100f
        val bodyH = h - counterT - plinthH
        val bodyD = d - t - 20f
        val bodyZ = -10f
        val bodyCenterY = plinthH + bodyH / 2f
        val innerW = w - 2f * t
        val parts = mutableListOf<BoxPart3D>()

        parts += BoxPart3D(
            id = "counter_top",
            groupId = "kitchen_counter",
            nameEn = "Countertop Slab",
            nameMr = "ओट्याचा टॉप स्लॅब",
            category = PartCategory.TOP,
            centerX = 0f,
            centerY = h - counterT / 2f,
            centerZ = 6f,
            sizeX = w + 20f,
            sizeY = counterT,
            sizeZ = d + 18f,
            explodeY = 1.2f,
            isCounterTop = true,
            edgeBandingEn = "Front + Sides",
            edgeBandingMr = "समोर + दोन्ही बाजू",
        )

        parts += BoxPart3D(
            id = "toe_kick",
            groupId = "kitchen_plinth",
            nameEn = "Toe-Kick Skirting",
            nameMr = "खालची पट्टी",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = plinthH / 2f,
            centerZ = bodyZ + bodyD / 2f - 40f,
            sizeX = innerW,
            sizeY = plinthH,
            sizeZ = t,
            explodeY = -0.8f,
            edgeBandingEn = "Top edge",
            edgeBandingMr = "वरची कडा",
        )

        parts += BoxPart3D(
            id = "side_left",
            groupId = "kitchen_sides",
            nameEn = "Cabinet Side",
            nameMr = "बाजूचा पत्रा",
            category = PartCategory.CARCASS,
            centerX = -w / 2f + t / 2f,
            centerY = bodyCenterY,
            centerZ = bodyZ,
            sizeX = t,
            sizeY = bodyH,
            sizeZ = bodyD,
            explodeX = -1.1f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )
        parts += BoxPart3D(
            id = "side_right",
            groupId = "kitchen_sides",
            nameEn = "Cabinet Side",
            nameMr = "बाजूचा पत्रा",
            category = PartCategory.CARCASS,
            centerX = w / 2f - t / 2f,
            centerY = bodyCenterY,
            centerZ = bodyZ,
            sizeX = t,
            sizeY = bodyH,
            sizeZ = bodyD,
            explodeX = 1.1f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )

        parts += BoxPart3D(
            id = "bottom_panel",
            groupId = "kitchen_bottom",
            nameEn = "Bottom Panel",
            nameMr = "खालचा पत्रा",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = plinthH + t / 2f,
            centerZ = bodyZ,
            sizeX = innerW,
            sizeY = t,
            sizeZ = bodyD,
            explodeY = -0.6f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )
        parts += BoxPart3D(
            id = "top_rail_front",
            groupId = "kitchen_rails",
            nameEn = "Top Stretcher Rail",
            nameMr = "वरची सपोर्ट पट्टी",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = plinthH + bodyH - t / 2f,
            centerZ = bodyZ + bodyD / 2f - 45f,
            sizeX = innerW,
            sizeY = t,
            sizeZ = 90f,
            explodeY = 0.6f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )

        parts += BoxPart3D(
            id = "back_ply",
            groupId = "kitchen_back",
            nameEn = "Back Ply (8mm)",
            nameMr = "मागील प्लाय (8mm)",
            category = PartCategory.BACK,
            centerX = 0f,
            centerY = bodyCenterY,
            centerZ = bodyZ - bodyD / 2f - 4f,
            sizeX = w - 6f,
            sizeY = bodyH - 6f,
            sizeZ = 8f,
            explodeZ = -1.2f,
            isBackPly = true,
            edgeBandingEn = "None",
            edgeBandingMr = "गरज नाही",
        )

        val shelfCount = max(1, min(3, c.shelfCount))
        val step = (bodyH - t) / (shelfCount + 1)
        for (i in 1..shelfCount) {
            parts += BoxPart3D(
                id = "shelf_$i",
                groupId = "kitchen_shelves",
                nameEn = "Inner Shelf",
                nameMr = "आतील शेल्फ",
                category = PartCategory.SHELF,
                centerX = 0f,
                centerY = plinthH + t + step * i,
                centerZ = bodyZ - 8f,
                sizeX = innerW,
                sizeY = t,
                sizeZ = bodyD - 24f,
                explodeZ = 0.5f,
                edgeBandingEn = "Front edge",
                edgeBandingMr = "समोरची कडा",
            )
        }

        val doorGap = 4f
        val doorW = (w - doorGap * 3f) / 2f
        val doorH = bodyH - 4f
        val doorZ = bodyZ + bodyD / 2f + t / 2f + 2f
        parts += BoxPart3D(
            id = "door_left",
            groupId = "kitchen_doors",
            nameEn = "Cabinet Shutter",
            nameMr = "कॅबिनेट दरवाजा",
            category = PartCategory.DOOR,
            centerX = -doorW / 2f - doorGap / 2f,
            centerY = bodyCenterY,
            centerZ = doorZ,
            sizeX = doorW,
            sizeY = doorH,
            sizeZ = t,
            explodeZ = 1.3f,
            explodeX = -0.3f,
            isDoorOrFront = true,
            swingPivotX = -w / 2f + doorGap,
            swingPivotZ = doorZ,
            swingAngleMaxDeg = 80f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )
        parts += BoxPart3D(
            id = "door_right",
            groupId = "kitchen_doors",
            nameEn = "Cabinet Shutter",
            nameMr = "कॅबिनेट दरवाजा",
            category = PartCategory.DOOR,
            centerX = doorW / 2f + doorGap / 2f,
            centerY = bodyCenterY,
            centerZ = doorZ,
            sizeX = doorW,
            sizeY = doorH,
            sizeZ = t,
            explodeZ = 1.3f,
            explodeX = 0.3f,
            isDoorOrFront = true,
            swingPivotX = w / 2f - doorGap,
            swingPivotZ = doorZ,
            swingAngleMaxDeg = -80f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )

        val handleY = plinthH + bodyH - 95f
        val handleZ = doorZ + t / 2f + 9f
        parts += BoxPart3D(
            id = "handle_left",
            groupId = "kitchen_handles",
            nameEn = "Pull Handle",
            nameMr = "हँडल",
            category = PartCategory.HARDWARE,
            centerX = -30f,
            centerY = handleY,
            centerZ = handleZ,
            sizeX = 14f,
            sizeY = 140f,
            sizeZ = 18f,
            explodeZ = 1.5f,
            isHardware = true,
            swingPivotX = -w / 2f + doorGap,
            swingPivotZ = doorZ,
            swingAngleMaxDeg = 80f,
        )
        parts += BoxPart3D(
            id = "handle_right",
            groupId = "kitchen_handles",
            nameEn = "Pull Handle",
            nameMr = "हँडल",
            category = PartCategory.HARDWARE,
            centerX = 30f,
            centerY = handleY,
            centerZ = handleZ,
            sizeX = 14f,
            sizeY = 140f,
            sizeZ = 18f,
            explodeZ = 1.5f,
            isHardware = true,
            swingPivotX = w / 2f - doorGap,
            swingPivotZ = doorZ,
            swingAngleMaxDeg = -80f,
        )

        return parts
    }

    private fun buildPoojaUnit(c: StudioConfig): List<BoxPart3D> {
        val w = c.widthMm
        val h = c.heightMm
        val d = c.depthMm
        val t = c.thicknessMm
        val plinthH = 75f
        val baseCabH = min(500f, h * 0.34f)
        val innerW = w - 2f * t
        val mandirBottomY = plinthH + baseCabH
        val canopyH = 90f
        val mandirH = h - mandirBottomY - canopyH
        val parts = mutableListOf<BoxPart3D>()

        // Plinth
        parts += BoxPart3D(
            id = "pj_plinth",
            groupId = "pj_plinth",
            nameEn = "Base Skirting",
            nameMr = "तळ पट्टी",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = plinthH / 2f,
            centerZ = d / 2f - t * 2f,
            sizeX = innerW,
            sizeY = plinthH,
            sizeZ = t,
            explodeY = -0.8f,
            edgeBandingEn = "Top edge",
            edgeBandingMr = "वरची कडा",
        )

        // Full side panels
        val sideH = h - plinthH - canopyH * 0.4f
        parts += BoxPart3D(
            id = "pj_side_l",
            groupId = "pj_sides",
            nameEn = "Side Panel",
            nameMr = "बाजूचा पत्रा",
            category = PartCategory.CARCASS,
            centerX = -w / 2f + t / 2f,
            centerY = plinthH + sideH / 2f,
            centerZ = 0f,
            sizeX = t,
            sizeY = sideH,
            sizeZ = d,
            explodeX = -1.1f,
            edgeBandingEn = "Front + Top",
            edgeBandingMr = "समोर + वर",
        )
        parts += BoxPart3D(
            id = "pj_side_r",
            groupId = "pj_sides",
            nameEn = "Side Panel",
            nameMr = "बाजूचा पत्रा",
            category = PartCategory.CARCASS,
            centerX = w / 2f - t / 2f,
            centerY = plinthH + sideH / 2f,
            centerZ = 0f,
            sizeX = t,
            sizeY = sideH,
            sizeZ = d,
            explodeX = 1.1f,
            edgeBandingEn = "Front + Top",
            edgeBandingMr = "समोर + वर",
        )

        // Base cabinet bottom & mandir platform deck
        parts += BoxPart3D(
            id = "pj_bottom",
            groupId = "pj_decks",
            nameEn = "Cabinet Deck Panel",
            nameMr = "तळ / देवघर स्लॅब",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = plinthH + t / 2f,
            centerZ = 0f,
            sizeX = innerW,
            sizeY = t,
            sizeZ = d,
            explodeY = -0.5f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )
        parts += BoxPart3D(
            id = "pj_mandir_deck",
            groupId = "pj_decks",
            nameEn = "Cabinet Deck Panel",
            nameMr = "तळ / देवघर स्लॅब",
            category = PartCategory.TOP,
            centerX = 0f,
            centerY = mandirBottomY - t / 2f,
            centerZ = 18f,
            sizeX = w + 16f,
            sizeY = t,
            sizeZ = d + 36f,
            explodeZ = 0.6f,
            edgeBandingEn = "Front + Sides",
            edgeBandingMr = "समोर + बाजू",
        )

        // Pull-out Diya tray just under mandir deck
        parts += BoxPart3D(
            id = "pj_diya_tray",
            groupId = "pj_diya_tray",
            nameEn = "Pull-Out Diya Tray",
            nameMr = "नंदादीप / आरती ट्रे",
            category = PartCategory.DOOR,
            centerX = 0f,
            centerY = mandirBottomY - t - 22f,
            centerZ = d / 2f - t / 2f,
            sizeX = innerW - 12f,
            sizeY = 34f,
            sizeZ = t,
            isDoorOrFront = true,
            slideOffsetZMaxMm = 110f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )

        // Lower storage double doors
        val lowerDoorH = baseCabH - t - 48f
        val lowerDoorY = plinthH + t + lowerDoorH / 2f
        val doorGap = 4f
        val doorW = (w - doorGap * 3f) / 2f
        val doorZ = d / 2f + t / 2f + 2f
        parts += BoxPart3D(
            id = "pj_door_l",
            groupId = "pj_doors",
            nameEn = "Lower Cabinet Door",
            nameMr = "खालचा दरवाजा",
            category = PartCategory.DOOR,
            centerX = -doorW / 2f - doorGap / 2f,
            centerY = lowerDoorY,
            centerZ = doorZ,
            sizeX = doorW,
            sizeY = lowerDoorH,
            sizeZ = t,
            explodeZ = 1.2f,
            isDoorOrFront = true,
            swingPivotX = -w / 2f + doorGap,
            swingPivotZ = doorZ,
            swingAngleMaxDeg = 80f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )
        parts += BoxPart3D(
            id = "pj_door_r",
            groupId = "pj_doors",
            nameEn = "Lower Cabinet Door",
            nameMr = "खालचा दरवाजा",
            category = PartCategory.DOOR,
            centerX = doorW / 2f + doorGap / 2f,
            centerY = lowerDoorY,
            centerZ = doorZ,
            sizeX = doorW,
            sizeY = lowerDoorH,
            sizeZ = t,
            explodeZ = 1.2f,
            isDoorOrFront = true,
            swingPivotX = w / 2f - doorGap,
            swingPivotZ = doorZ,
            swingAngleMaxDeg = -80f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )

        // Brass/Black door knobs
        parts += BoxPart3D(
            id = "pj_knob_l",
            groupId = "pj_knobs",
            nameEn = "Door Knob",
            nameMr = "नॉब / हँडल",
            category = PartCategory.HARDWARE,
            centerX = -26f,
            centerY = lowerDoorY + lowerDoorH * 0.2f,
            centerZ = doorZ + t / 2f + 10f,
            sizeX = 18f,
            sizeY = 26f,
            sizeZ = 18f,
            isHardware = true,
            swingPivotX = -w / 2f + doorGap,
            swingPivotZ = doorZ,
            swingAngleMaxDeg = 80f,
        )
        parts += BoxPart3D(
            id = "pj_knob_r",
            groupId = "pj_knobs",
            nameEn = "Door Knob",
            nameMr = "नॉब / हँडल",
            category = PartCategory.HARDWARE,
            centerX = 26f,
            centerY = lowerDoorY + lowerDoorH * 0.2f,
            centerZ = doorZ + t / 2f + 10f,
            sizeX = 18f,
            sizeY = 26f,
            sizeZ = 18f,
            isHardware = true,
            swingPivotX = w / 2f - doorGap,
            swingPivotZ = doorZ,
            swingAngleMaxDeg = -80f,
        )

        // Back ply (accented inside mandir!)
        parts += BoxPart3D(
            id = "pj_back",
            groupId = "pj_back",
            nameEn = "Mandir Back Panel",
            nameMr = "मागील बॅक पॅनेल",
            category = PartCategory.BACK,
            centerX = 0f,
            centerY = plinthH + sideH / 2f,
            centerZ = -d / 2f - 4f,
            sizeX = w - 6f,
            sizeY = sideH - 6f,
            sizeZ = 8f,
            explodeZ = -1.2f,
            isBackPly = true,
            edgeBandingEn = "None",
            edgeBandingMr = "गरज नाही",
        )

        // Mandir decorative front pillars + inner idol pedestal shelf
        val pillarW = 42f
        parts += BoxPart3D(
            id = "pj_pillar_l",
            groupId = "pj_pillars",
            nameEn = "Mandir Pillar",
            nameMr = "मंदिर खांब",
            category = PartCategory.DOOR,
            centerX = -w / 2f + t + pillarW / 2f,
            centerY = mandirBottomY + mandirH / 2f,
            centerZ = d / 2f - pillarW / 2f,
            sizeX = pillarW,
            sizeY = mandirH,
            sizeZ = pillarW,
            explodeZ = 0.7f,
            isDoorOrFront = true,
            edgeBandingEn = "All 4 sides",
            edgeBandingMr = "चारही बाजू",
        )
        parts += BoxPart3D(
            id = "pj_pillar_r",
            groupId = "pj_pillars",
            nameEn = "Mandir Pillar",
            nameMr = "मंदिर खांब",
            category = PartCategory.DOOR,
            centerX = w / 2f - t - pillarW / 2f,
            centerY = mandirBottomY + mandirH / 2f,
            centerZ = d / 2f - pillarW / 2f,
            sizeX = pillarW,
            sizeY = mandirH,
            sizeZ = pillarW,
            explodeZ = 0.7f,
            isDoorOrFront = true,
            edgeBandingEn = "All 4 sides",
            edgeBandingMr = "चारही बाजू",
        )

        // Elevated idol step shelf inside mandir
        parts += BoxPart3D(
            id = "pj_idol_step",
            groupId = "pj_idol_step",
            nameEn = "Idol Pedestal Step",
            nameMr = "मूर्ती पाट / शेल्फ",
            category = PartCategory.SHELF,
            centerX = 0f,
            centerY = mandirBottomY + 55f,
            centerZ = -d * 0.12f,
            sizeX = innerW * 0.72f,
            sizeY = 22f,
            sizeZ = d * 0.45f,
            explodeZ = 0.4f,
            edgeBandingEn = "Front + Sides",
            edgeBandingMr = "समोर + बाजू",
        )

        // Stepped Top Canopy / Shikhar
        parts += BoxPart3D(
            id = "pj_canopy_base",
            groupId = "pj_canopy",
            nameEn = "Top Canopy Slab",
            nameMr = "वरचा छत स्लॅब",
            category = PartCategory.TOP,
            centerX = 0f,
            centerY = h - canopyH + t / 2f,
            centerZ = 10f,
            sizeX = w + 30f,
            sizeY = t + 10f,
            sizeZ = d + 30f,
            explodeY = 1.1f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )
        parts += BoxPart3D(
            id = "pj_shikhar_tier",
            groupId = "pj_shikhar",
            nameEn = "Shikhar Crown Trim",
            nameMr = "शिखर कळस पट्टी",
            category = PartCategory.DOOR,
            centerX = 0f,
            centerY = h - canopyH * 0.35f,
            centerZ = 0f,
            sizeX = w * 0.56f,
            sizeY = canopyH * 0.55f,
            sizeZ = d * 0.56f,
            explodeY = 1.4f,
            isDoorOrFront = true,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )

        return parts
    }

    private fun buildShoeRack(c: StudioConfig): List<BoxPart3D> {
        val w = c.widthMm
        val h = c.heightMm
        val d = c.depthMm
        val t = c.thicknessMm
        val legH = 85f
        val drawerH = 140f
        val cabH = h - legH - drawerH
        val innerW = w - 2f * t
        val bodyD = d - t
        val bodyZ = -t / 2f
        val parts = mutableListOf<BoxPart3D>()

        // 4 Legs
        val legX = w / 2f - 45f
        val legZ = bodyD / 2f - 35f
        listOf(-legX to legZ, legX to legZ, -legX to -legZ, legX to -legZ).forEachIndexed { i, (lx, lz) ->
            parts += BoxPart3D(
                id = "sr_leg_$i",
                groupId = "sr_legs",
                nameEn = "Rack Leg",
                nameMr = "स्टँड पाय",
                category = PartCategory.HARDWARE,
                centerX = lx,
                centerY = legH / 2f,
                centerZ = lz,
                sizeX = 28f,
                sizeY = legH,
                sizeZ = 28f,
                explodeY = -0.9f,
                isHardware = true,
            )
        }

        // Sides
        val sideH = h - legH - t
        val sideCenterY = legH + sideH / 2f
        parts += BoxPart3D(
            id = "sr_side_l",
            groupId = "sr_sides",
            nameEn = "Side Panel",
            nameMr = "बाजूचा पत्रा",
            category = PartCategory.CARCASS,
            centerX = -w / 2f + t / 2f,
            centerY = sideCenterY,
            centerZ = bodyZ,
            sizeX = t,
            sizeY = sideH,
            sizeZ = bodyD,
            explodeX = -1.1f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )
        parts += BoxPart3D(
            id = "sr_side_r",
            groupId = "sr_sides",
            nameEn = "Side Panel",
            nameMr = "बाजूचा पत्रा",
            category = PartCategory.CARCASS,
            centerX = w / 2f - t / 2f,
            centerY = sideCenterY,
            centerZ = bodyZ,
            sizeX = t,
            sizeY = sideH,
            sizeZ = bodyD,
            explodeX = 1.1f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )

        // Top, Divider under drawer, Bottom
        parts += BoxPart3D(
            id = "sr_top",
            groupId = "sr_top",
            nameEn = "Top Slab",
            nameMr = "वरचा टॉप स्लॅब",
            category = PartCategory.TOP,
            centerX = 0f,
            centerY = h - t / 2f,
            centerZ = 4f,
            sizeX = w + 10f,
            sizeY = t,
            sizeZ = d + 10f,
            explodeY = 1.1f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )
        parts += BoxPart3D(
            id = "sr_mid_deck",
            groupId = "sr_decks",
            nameEn = "Bottom / Mid Deck",
            nameMr = "तळ / मधला पत्रा",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = legH + cabH,
            centerZ = bodyZ,
            sizeX = innerW,
            sizeY = t,
            sizeZ = bodyD,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )
        parts += BoxPart3D(
            id = "sr_bottom",
            groupId = "sr_decks",
            nameEn = "Bottom / Mid Deck",
            nameMr = "तळ / मधला पत्रा",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = legH + t / 2f,
            centerZ = bodyZ,
            sizeX = innerW,
            sizeY = t,
            sizeZ = bodyD,
            explodeY = -0.6f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )

        // Back ply
        parts += BoxPart3D(
            id = "sr_back",
            groupId = "sr_back",
            nameEn = "Back Ply (8mm)",
            nameMr = "मागील प्लाय (8mm)",
            category = PartCategory.BACK,
            centerX = 0f,
            centerY = sideCenterY,
            centerZ = bodyZ - bodyD / 2f - 4f,
            sizeX = w - 6f,
            sizeY = sideH - 6f,
            sizeZ = 8f,
            explodeZ = -1.1f,
            isBackPly = true,
            edgeBandingEn = "None",
            edgeBandingMr = "गरज नाही",
        )

        // Inner shoe shelves
        val shelfCount = max(2, min(6, c.shelfCount))
        val availH = cabH - 2f * t
        val step = availH / (shelfCount + 1)
        for (i in 1..shelfCount) {
            parts += BoxPart3D(
                id = "sr_shelf_$i",
                groupId = "sr_shelves",
                nameEn = "Shoe Shelf",
                nameMr = "चप्पल शेल्फ",
                category = PartCategory.SHELF,
                centerX = 0f,
                centerY = legH + t + step * i,
                centerZ = bodyZ - 6f,
                sizeX = innerW,
                sizeY = t,
                sizeZ = bodyD - 20f,
                explodeZ = 0.5f,
                edgeBandingEn = "Front edge",
                edgeBandingMr = "समोरची कडा",
            )
        }

        // Top utility drawer (keys / polish)
        val doorZ = bodyZ + bodyD / 2f + t / 2f + 2f
        parts += BoxPart3D(
            id = "sr_top_drawer",
            groupId = "sr_drawer",
            nameEn = "Top Utility Drawer",
            nameMr = "वरचा ड्रॉवर",
            category = PartCategory.DOOR,
            centerX = 0f,
            centerY = h - t - drawerH / 2f + 4f,
            centerZ = doorZ,
            sizeX = w - 8f,
            sizeY = drawerH - 14f,
            sizeZ = t,
            explodeZ = 1.3f,
            isDoorOrFront = true,
            slideOffsetZMaxMm = 110f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )

        // Twin doors below
        val doorGap = 4f
        val doorW = (w - doorGap * 3f) / 2f
        val doorH = cabH - 10f
        val doorY = legH + doorH / 2f
        parts += BoxPart3D(
            id = "sr_door_l",
            groupId = "sr_doors",
            nameEn = "Shoe Rack Door",
            nameMr = "शू रॅक दरवाजा",
            category = PartCategory.DOOR,
            centerX = -doorW / 2f - doorGap / 2f,
            centerY = doorY,
            centerZ = doorZ,
            sizeX = doorW,
            sizeY = doorH,
            sizeZ = t,
            explodeZ = 1.3f,
            isDoorOrFront = true,
            swingPivotX = -w / 2f + doorGap,
            swingPivotZ = doorZ,
            swingAngleMaxDeg = 78f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )
        parts += BoxPart3D(
            id = "sr_door_r",
            groupId = "sr_doors",
            nameEn = "Shoe Rack Door",
            nameMr = "शू रॅक दरवाजा",
            category = PartCategory.DOOR,
            centerX = doorW / 2f + doorGap / 2f,
            centerY = doorY,
            centerZ = doorZ,
            sizeX = doorW,
            sizeY = doorH,
            sizeZ = t,
            explodeZ = 1.3f,
            isDoorOrFront = true,
            swingPivotX = w / 2f - doorGap,
            swingPivotZ = doorZ,
            swingAngleMaxDeg = -78f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )

        return parts
    }

    private fun buildDrawerChest(c: StudioConfig): List<BoxPart3D> {
        val w = c.widthMm
        val h = c.heightMm
        val d = c.depthMm
        val t = c.thicknessMm
        val plinthH = 75f
        val bodyD = d - t
        val bodyZ = -t / 2f
        val sideH = h - plinthH - t
        val sideCenterY = plinthH + sideH / 2f
        val innerW = w - 2f * t
        val parts = mutableListOf<BoxPart3D>()

        // Plinth
        parts += BoxPart3D(
            id = "dc_plinth",
            groupId = "dc_plinth",
            nameEn = "Plinth Skirting",
            nameMr = "तळ पट्टी",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = plinthH / 2f,
            centerZ = bodyZ + bodyD / 2f - t,
            sizeX = innerW,
            sizeY = plinthH,
            sizeZ = t,
            explodeY = -0.7f,
            edgeBandingEn = "Top edge",
            edgeBandingMr = "वरची कडा",
        )

        // Sides
        parts += BoxPart3D(
            id = "dc_side_l",
            groupId = "dc_sides",
            nameEn = "Side Panel",
            nameMr = "बाजूचा पत्रा",
            category = PartCategory.CARCASS,
            centerX = -w / 2f + t / 2f,
            centerY = sideCenterY,
            centerZ = bodyZ,
            sizeX = t,
            sizeY = sideH,
            sizeZ = bodyD,
            explodeX = -1.1f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )
        parts += BoxPart3D(
            id = "dc_side_r",
            groupId = "dc_sides",
            nameEn = "Side Panel",
            nameMr = "बाजूचा पत्रा",
            category = PartCategory.CARCASS,
            centerX = w / 2f - t / 2f,
            centerY = sideCenterY,
            centerZ = bodyZ,
            sizeX = t,
            sizeY = sideH,
            sizeZ = bodyD,
            explodeX = 1.1f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )

        // Top & Bottom
        parts += BoxPart3D(
            id = "dc_top",
            groupId = "dc_top",
            nameEn = "Top Slab",
            nameMr = "वरचा टॉप स्लॅब",
            category = PartCategory.TOP,
            centerX = 0f,
            centerY = h - t / 2f,
            centerZ = 2f,
            sizeX = w + 12f,
            sizeY = t,
            sizeZ = d + 8f,
            explodeY = 1.1f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )
        parts += BoxPart3D(
            id = "dc_bottom",
            groupId = "dc_bottom",
            nameEn = "Bottom Panel",
            nameMr = "खालचा पत्रा",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = plinthH + t / 2f,
            centerZ = bodyZ,
            sizeX = innerW,
            sizeY = t,
            sizeZ = bodyD,
            explodeY = -0.5f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )

        // Back ply
        parts += BoxPart3D(
            id = "dc_back",
            groupId = "dc_back",
            nameEn = "Back Ply (8mm)",
            nameMr = "मागील प्लाय (8mm)",
            category = PartCategory.BACK,
            centerX = 0f,
            centerY = sideCenterY,
            centerZ = bodyZ - bodyD / 2f - 4f,
            sizeX = w - 6f,
            sizeY = sideH - 6f,
            sizeZ = 8f,
            explodeZ = -1.2f,
            isBackPly = true,
            edgeBandingEn = "None",
            edgeBandingMr = "गरज नाही",
        )

        // Full-width Drawer Fronts + Handles
        val drawerCount = c.drawerCount.coerceIn(3, 6)
        val frontAreaH = sideH - t - 8f
        val gap = 6f
        val drawerH = (frontAreaH - gap * (drawerCount + 1)) / drawerCount
        val frontZ = bodyZ + bodyD / 2f + t / 2f + 2f

        for (i in 0 until drawerCount) {
            val dy = plinthH + t + gap + drawerH / 2f + i * (drawerH + gap)
            val pullOut = when (i) {
                drawerCount - 1 -> 140f
                drawerCount - 2 -> 60f
                else -> 0f
            }
            parts += BoxPart3D(
                id = "dc_front_$i",
                groupId = "dc_drawers",
                nameEn = "Drawer Front",
                nameMr = "ड्रॉवर फ्रंट",
                category = PartCategory.DOOR,
                centerX = 0f,
                centerY = dy,
                centerZ = frontZ,
                sizeX = w - 8f,
                sizeY = drawerH,
                sizeZ = t,
                explodeZ = 1.3f,
                isDoorOrFront = true,
                slideOffsetZMaxMm = pullOut,
                edgeBandingEn = "All 4 edges",
                edgeBandingMr = "चारही बाजू",
            )
            parts += BoxPart3D(
                id = "dc_handle_$i",
                groupId = "dc_handles",
                nameEn = "Drawer Handle",
                nameMr = "ड्रॉवर हँडल",
                category = PartCategory.HARDWARE,
                centerX = 0f,
                centerY = dy,
                centerZ = frontZ + t / 2f + 9f,
                sizeX = min(200f, w * 0.28f),
                sizeY = 14f,
                sizeZ = 18f,
                explodeZ = 1.5f,
                isHardware = true,
                slideOffsetZMaxMm = pullOut,
            )
        }

        return parts
    }

    private fun buildStudyDesk(c: StudioConfig): List<BoxPart3D> {
        val w = c.widthMm
        val h = c.heightMm
        val d = c.depthMm
        val t = c.thicknessMm
        val topT = max(t, 24f)
        val legH = h - topT
        val pedW = min(420f, w * 0.34f)
        val pedX = w / 2f - pedW / 2f
        val parts = mutableListOf<BoxPart3D>()

        parts += BoxPart3D(
            id = "desk_top",
            groupId = "desk_top",
            nameEn = "Desk Top Slab",
            nameMr = "टेबल टॉप",
            category = PartCategory.TOP,
            centerX = 0f,
            centerY = h - topT / 2f,
            centerZ = 0f,
            sizeX = w,
            sizeY = topT,
            sizeZ = d,
            explodeY = 1.3f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )

        parts += BoxPart3D(
            id = "left_gable",
            groupId = "desk_legs",
            nameEn = "Side Support Panel",
            nameMr = "बाजूचा आधार पत्रा",
            category = PartCategory.CARCASS,
            centerX = -w / 2f + t / 2f + 15f,
            centerY = legH / 2f,
            centerZ = 0f,
            sizeX = t,
            sizeY = legH,
            sizeZ = d - 30f,
            explodeX = -1.2f,
            edgeBandingEn = "Front + Bottom",
            edgeBandingMr = "समोर + तळ",
        )

        val kneeW = w - pedW - t - 15f
        parts += BoxPart3D(
            id = "modesty_panel",
            groupId = "desk_modesty",
            nameEn = "Modesty Back Panel",
            nameMr = "मागील मॉडेस्टी पत्रा",
            category = PartCategory.CARCASS,
            centerX = -pedW / 2f + 7f,
            centerY = legH - 180f,
            centerZ = -d / 2f + t / 2f + 35f,
            sizeX = kneeW,
            sizeY = 330f,
            sizeZ = t,
            explodeZ = -1.1f,
            edgeBandingEn = "Bottom edge",
            edgeBandingMr = "खालची कडा",
        )

        val pedD = d - 30f
        parts += BoxPart3D(
            id = "ped_outer",
            groupId = "desk_ped_sides",
            nameEn = "Pedestal Side Panel",
            nameMr = "ड्रॉवर बॉक्स बाजू",
            category = PartCategory.CARCASS,
            centerX = w / 2f - t / 2f - 10f,
            centerY = legH / 2f,
            centerZ = 0f,
            sizeX = t,
            sizeY = legH,
            sizeZ = pedD,
            explodeX = 1.2f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )
        parts += BoxPart3D(
            id = "ped_inner",
            groupId = "desk_ped_sides",
            nameEn = "Pedestal Side Panel",
            nameMr = "ड्रॉवर बॉक्स बाजू",
            category = PartCategory.CARCASS,
            centerX = pedX - pedW / 2f + t / 2f,
            centerY = legH / 2f,
            centerZ = 0f,
            sizeX = t,
            sizeY = legH,
            sizeZ = pedD,
            explodeX = 0.6f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )
        parts += BoxPart3D(
            id = "ped_bottom",
            groupId = "desk_ped_bottom",
            nameEn = "Pedestal Bottom",
            nameMr = "ड्रॉवर बॉक्स तळ",
            category = PartCategory.CARCASS,
            centerX = pedX - 5f,
            centerY = 60f,
            centerZ = 0f,
            sizeX = pedW - 2f * t - 10f,
            sizeY = t,
            sizeZ = pedD,
            explodeY = -0.6f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )

        val drawerAreaH = legH - 80f
        val drawerH = (drawerAreaH - 16f) / 3f
        val frontW = pedW - 16f
        for (i in 0 until 3) {
            val dy = 72f + drawerH / 2f + i * (drawerH + 5f)
            val zPull = if (i == 2) 135f else 35f
            parts += BoxPart3D(
                id = "drawer_front_$i",
                groupId = "desk_drawers",
                nameEn = "Drawer Front",
                nameMr = "ड्रॉवर फ्रंट",
                category = PartCategory.DOOR,
                centerX = pedX - 5f,
                centerY = dy,
                centerZ = pedD / 2f + t / 2f,
                sizeX = frontW,
                sizeY = drawerH,
                sizeZ = t,
                explodeZ = 1.4f,
                isDoorOrFront = true,
                slideOffsetZMaxMm = zPull,
                edgeBandingEn = "All 4 edges",
                edgeBandingMr = "चारही बाजू",
            )
            parts += BoxPart3D(
                id = "drawer_handle_$i",
                groupId = "desk_handles",
                nameEn = "Drawer Handle",
                nameMr = "ड्रॉवर हँडल",
                category = PartCategory.HARDWARE,
                centerX = pedX - 5f,
                centerY = dy,
                centerZ = pedD / 2f + t + 8f,
                sizeX = min(130f, frontW * 0.4f),
                sizeY = 14f,
                sizeZ = 16f,
                explodeZ = 1.6f,
                isHardware = true,
                slideOffsetZMaxMm = zPull,
            )
        }

        return parts
    }

    private fun buildTvConsole(c: StudioConfig): List<BoxPart3D> {
        val w = c.widthMm
        val h = c.heightMm
        val d = c.depthMm
        val t = c.thicknessMm
        val legH = 110f
        val boxH = h - legH
        val boxCenterY = legH + boxH / 2f
        val innerW = w - 2f * t
        val innerH = boxH - 2f * t
        val parts = mutableListOf<BoxPart3D>()

        val legX = w / 2f - 55f
        val legZ = d / 2f - 50f
        listOf(-legX to legZ, legX to legZ, -legX to -legZ, legX to -legZ).forEachIndexed { idx, (lx, lz) ->
            parts += BoxPart3D(
                id = "tv_leg_$idx",
                groupId = "tv_legs",
                nameEn = "Console Leg",
                nameMr = "स्टँड पाय",
                category = PartCategory.HARDWARE,
                centerX = lx,
                centerY = legH / 2f,
                centerZ = lz,
                sizeX = 32f,
                sizeY = legH,
                sizeZ = 32f,
                explodeY = -1.0f,
                isHardware = true,
            )
        }

        parts += BoxPart3D(
            id = "tv_top",
            groupId = "tv_slabs",
            nameEn = "Top / Bottom Slab",
            nameMr = "वरचा / खालचा स्लॅब",
            category = PartCategory.TOP,
            centerX = 0f,
            centerY = h - t / 2f,
            centerZ = 0f,
            sizeX = w,
            sizeY = t,
            sizeZ = d,
            explodeY = 1.1f,
            edgeBandingEn = "Front + Sides",
            edgeBandingMr = "समोर + बाजू",
        )
        parts += BoxPart3D(
            id = "tv_bottom",
            groupId = "tv_slabs",
            nameEn = "Top / Bottom Slab",
            nameMr = "वरचा / खालचा स्लॅब",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = legH + t / 2f,
            centerZ = 0f,
            sizeX = w,
            sizeY = t,
            sizeZ = d,
            explodeY = -0.7f,
            edgeBandingEn = "Front + Sides",
            edgeBandingMr = "समोर + बाजू",
        )

        parts += BoxPart3D(
            id = "tv_side_l",
            groupId = "tv_sides",
            nameEn = "Side Panel",
            nameMr = "बाजूचा पत्रा",
            category = PartCategory.CARCASS,
            centerX = -w / 2f + t / 2f,
            centerY = boxCenterY,
            centerZ = 0f,
            sizeX = t,
            sizeY = innerH,
            sizeZ = d,
            explodeX = -1.1f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )
        parts += BoxPart3D(
            id = "tv_side_r",
            groupId = "tv_sides",
            nameEn = "Side Panel",
            nameMr = "बाजूचा पत्रा",
            category = PartCategory.CARCASS,
            centerX = w / 2f - t / 2f,
            centerY = boxCenterY,
            centerZ = 0f,
            sizeX = t,
            sizeY = innerH,
            sizeZ = d,
            explodeX = 1.1f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )

        val bayW = (innerW - 2f * t) / 3f
        parts += BoxPart3D(
            id = "tv_div_l",
            groupId = "tv_dividers",
            nameEn = "Inner Divider",
            nameMr = "आतील पार्टीशन",
            category = PartCategory.CARCASS,
            centerX = -bayW / 2f - t / 2f,
            centerY = boxCenterY,
            centerZ = -4f,
            sizeX = t,
            sizeY = innerH,
            sizeZ = d - 16f,
            explodeZ = 0.4f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )
        parts += BoxPart3D(
            id = "tv_div_r",
            groupId = "tv_dividers",
            nameEn = "Inner Divider",
            nameMr = "आतील पार्टीशन",
            category = PartCategory.CARCASS,
            centerX = bayW / 2f + t / 2f,
            centerY = boxCenterY,
            centerZ = -4f,
            sizeX = t,
            sizeY = innerH,
            sizeZ = d - 16f,
            explodeZ = 0.4f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )

        parts += BoxPart3D(
            id = "tv_center_shelf",
            groupId = "tv_shelf",
            nameEn = "Media Shelf",
            nameMr = "सेट-टॉप बॉक्स शेल्फ",
            category = PartCategory.SHELF,
            centerX = 0f,
            centerY = boxCenterY,
            centerZ = -6f,
            sizeX = bayW,
            sizeY = t,
            sizeZ = d - 24f,
            explodeZ = 0.6f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )

        parts += BoxPart3D(
            id = "tv_back",
            groupId = "tv_back",
            nameEn = "Back Ply (8mm)",
            nameMr = "मागील प्लाय (8mm)",
            category = PartCategory.BACK,
            centerX = 0f,
            centerY = boxCenterY,
            centerZ = -d / 2f - 4f,
            sizeX = w - 8f,
            sizeY = boxH - 8f,
            sizeZ = 8f,
            explodeZ = -1.2f,
            isBackPly = true,
            edgeBandingEn = "None",
            edgeBandingMr = "गरज नाही",
        )

        val doorZ = d / 2f + t / 2f + 2f
        val leftBayX = -bayW - t
        val rightBayX = bayW + t
        parts += BoxPart3D(
            id = "tv_door_l",
            groupId = "tv_doors",
            nameEn = "Cabinet Door",
            nameMr = "बाजूचा दरवाजा",
            category = PartCategory.DOOR,
            centerX = leftBayX,
            centerY = boxCenterY,
            centerZ = doorZ,
            sizeX = bayW + t - 4f,
            sizeY = innerH - 2f,
            sizeZ = t,
            explodeZ = 1.4f,
            isDoorOrFront = true,
            swingPivotX = -w / 2f + t,
            swingPivotZ = doorZ,
            swingAngleMaxDeg = 78f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )
        parts += BoxPart3D(
            id = "tv_door_r",
            groupId = "tv_doors",
            nameEn = "Cabinet Door",
            nameMr = "बाजूचा दरवाजा",
            category = PartCategory.DOOR,
            centerX = rightBayX,
            centerY = boxCenterY,
            centerZ = doorZ,
            sizeX = bayW + t - 4f,
            sizeY = innerH - 2f,
            sizeZ = t,
            explodeZ = 1.4f,
            isDoorOrFront = true,
            swingPivotX = w / 2f - t,
            swingPivotZ = doorZ,
            swingAngleMaxDeg = -78f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )

        return parts
    }

    private fun buildBookshelf(c: StudioConfig): List<BoxPart3D> {
        val w = c.widthMm
        val h = c.heightMm
        val d = c.depthMm
        val t = c.thicknessMm
        val plinthH = 70f
        val innerW = w - 2f * t
        val sideH = h - plinthH
        val sideCenterY = plinthH + sideH / 2f
        val parts = mutableListOf<BoxPart3D>()

        parts += BoxPart3D(
            id = "bs_plinth",
            groupId = "bs_plinth",
            nameEn = "Base Skirting",
            nameMr = "तळ पट्टी",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = plinthH / 2f,
            centerZ = d / 2f - t * 1.5f,
            sizeX = innerW,
            sizeY = plinthH,
            sizeZ = t,
            explodeY = -0.8f,
            edgeBandingEn = "Top edge",
            edgeBandingMr = "वरची कडा",
        )

        parts += BoxPart3D(
            id = "bs_side_l",
            groupId = "bs_sides",
            nameEn = "Side Upright",
            nameMr = "उभा बाजू पत्रा",
            category = PartCategory.CARCASS,
            centerX = -w / 2f + t / 2f,
            centerY = sideCenterY,
            centerZ = 0f,
            sizeX = t,
            sizeY = sideH,
            sizeZ = d,
            explodeX = -1.1f,
            edgeBandingEn = "Front + Top",
            edgeBandingMr = "समोर + वर",
        )
        parts += BoxPart3D(
            id = "bs_side_r",
            groupId = "bs_sides",
            nameEn = "Side Upright",
            nameMr = "उभा बाजू पत्रा",
            category = PartCategory.CARCASS,
            centerX = w / 2f - t / 2f,
            centerY = sideCenterY,
            centerZ = 0f,
            sizeX = t,
            sizeY = sideH,
            sizeZ = d,
            explodeX = 1.1f,
            edgeBandingEn = "Front + Top",
            edgeBandingMr = "समोर + वर",
        )

        parts += BoxPart3D(
            id = "bs_bottom",
            groupId = "bs_top_bottom",
            nameEn = "Top / Bottom Panel",
            nameMr = "वरचा / खालचा पत्रा",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = plinthH + t / 2f,
            centerZ = 0f,
            sizeX = innerW,
            sizeY = t,
            sizeZ = d,
            explodeY = -0.6f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )
        parts += BoxPart3D(
            id = "bs_top",
            groupId = "bs_top_bottom",
            nameEn = "Top / Bottom Panel",
            nameMr = "वरचा / खालचा पत्रा",
            category = PartCategory.TOP,
            centerX = 0f,
            centerY = h - t / 2f,
            centerZ = 0f,
            sizeX = innerW,
            sizeY = t,
            sizeZ = d,
            explodeY = 1.0f,
            edgeBandingEn = "Front edge",
            edgeBandingMr = "समोरची कडा",
        )

        parts += BoxPart3D(
            id = "bs_back",
            groupId = "bs_back",
            nameEn = "Back Ply (8mm)",
            nameMr = "मागील प्लाय (8mm)",
            category = PartCategory.BACK,
            centerX = 0f,
            centerY = sideCenterY,
            centerZ = -d / 2f - 4f,
            sizeX = w - 6f,
            sizeY = sideH - 6f,
            sizeZ = 8f,
            explodeZ = -1.2f,
            isBackPly = true,
            edgeBandingEn = "None",
            edgeBandingMr = "गरज नाही",
        )

        val shelfCount = max(2, min(6, c.shelfCount))
        val innerH = sideH - 2f * t
        val step = innerH / (shelfCount + 1)
        for (i in 1..shelfCount) {
            parts += BoxPart3D(
                id = "bs_shelf_$i",
                groupId = "bs_shelves",
                nameEn = "Bookshelf Tier",
                nameMr = "पुस्तक शेल्फ",
                category = PartCategory.SHELF,
                centerX = 0f,
                centerY = plinthH + t + step * i,
                centerZ = 4f,
                sizeX = innerW,
                sizeY = t,
                sizeZ = d - 8f,
                explodeZ = 0.7f,
                edgeBandingEn = "Front edge",
                edgeBandingMr = "समोरची कडा",
            )
        }

        return parts
    }

    private fun buildStorageBed(c: StudioConfig): List<BoxPart3D> {
        val w = c.widthMm
        val h = c.heightMm
        val d = c.depthMm
        val t = c.thicknessMm
        val boxH = 380f
        val parts = mutableListOf<BoxPart3D>()

        parts += BoxPart3D(
            id = "bed_headboard",
            groupId = "bed_headboard",
            nameEn = "Headboard Panel",
            nameMr = "हेडबोर्ड पत्रा",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = h / 2f,
            centerZ = -d / 2f + t / 2f,
            sizeX = w,
            sizeY = h,
            sizeZ = t,
            explodeZ = -1.2f,
            edgeBandingEn = "Top + Sides",
            edgeBandingMr = "वर + दोन्ही बाजू",
        )

        parts += BoxPart3D(
            id = "bed_head_accent",
            groupId = "bed_accent",
            nameEn = "Headboard Accent Panel",
            nameMr = "हेडबोर्ड डिझाइन पट्टी",
            category = PartCategory.DOOR,
            centerX = 0f,
            centerY = h - 220f,
            centerZ = -d / 2f + t + 10f,
            sizeX = w - 60f,
            sizeY = 260f,
            sizeZ = 20f,
            explodeZ = -0.6f,
            isDoorOrFront = true,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )

        parts += BoxPart3D(
            id = "bed_footboard",
            groupId = "bed_footboard",
            nameEn = "Footboard Panel",
            nameMr = "फूटबोर्ड पत्रा",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = boxH / 2f,
            centerZ = d / 2f - t / 2f,
            sizeX = w,
            sizeY = boxH,
            sizeZ = t,
            explodeZ = 1.2f,
            edgeBandingEn = "Top + Sides",
            edgeBandingMr = "वर + दोन्ही बाजू",
        )

        val railLen = d - 2f * t
        parts += BoxPart3D(
            id = "bed_rail_l",
            groupId = "bed_rails",
            nameEn = "Side Box Rail",
            nameMr = "बाजूची स्टोरेज फळी",
            category = PartCategory.CARCASS,
            centerX = -w / 2f + t / 2f,
            centerY = boxH / 2f,
            centerZ = 0f,
            sizeX = t,
            sizeY = boxH,
            sizeZ = railLen,
            explodeX = -1.2f,
            edgeBandingEn = "Top edge",
            edgeBandingMr = "वरची कडा",
        )
        parts += BoxPart3D(
            id = "bed_rail_r",
            groupId = "bed_rails",
            nameEn = "Side Box Rail",
            nameMr = "बाजूची स्टोरेज फळी",
            category = PartCategory.CARCASS,
            centerX = w / 2f - t / 2f,
            centerY = boxH / 2f,
            centerZ = 0f,
            sizeX = t,
            sizeY = boxH,
            sizeZ = railLen,
            explodeX = 1.2f,
            edgeBandingEn = "Top edge",
            edgeBandingMr = "वरची कडा",
        )

        parts += BoxPart3D(
            id = "bed_center_div",
            groupId = "bed_dividers",
            nameEn = "Storage Center Divider",
            nameMr = "आतील स्टोरेज पार्टीशन",
            category = PartCategory.SHELF,
            centerX = 0f,
            centerY = (boxH - t) / 2f,
            centerZ = 0f,
            sizeX = t,
            sizeY = boxH - t,
            sizeZ = railLen,
            explodeY = 0.2f,
            edgeBandingEn = "Top edge",
            edgeBandingMr = "वरची कडा",
        )

        val halfW = (w - 2f * t - 6f) / 2f
        parts += BoxPart3D(
            id = "bed_top_l",
            groupId = "bed_platform",
            nameEn = "Mattress Platform Top",
            nameMr = "गादी सपोर्ट प्लाय",
            category = PartCategory.TOP,
            centerX = -halfW / 2f - 2f,
            centerY = boxH - t / 2f,
            centerZ = 0f,
            sizeX = halfW,
            sizeY = t,
            sizeZ = railLen - 4f,
            explodeY = 1.3f,
            explodeX = -0.3f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )
        parts += BoxPart3D(
            id = "bed_top_r",
            groupId = "bed_platform",
            nameEn = "Mattress Platform Top",
            nameMr = "गादी सपोर्ट प्लाय",
            category = PartCategory.TOP,
            centerX = halfW / 2f + 2f,
            centerY = boxH - t / 2f,
            centerZ = 0f,
            sizeX = halfW,
            sizeY = t,
            sizeZ = railLen - 4f,
            explodeY = 1.3f,
            explodeX = 0.3f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )

        return parts
    }

    private fun buildCoffeeTable(c: StudioConfig): List<BoxPart3D> {
        val w = c.widthMm
        val h = c.heightMm
        val d = c.depthMm
        val t = max(c.thicknessMm, 20f)
        val legSize = 48f
        val legH = h - t
        val parts = mutableListOf<BoxPart3D>()

        parts += BoxPart3D(
            id = "ct_top",
            groupId = "ct_top",
            nameEn = "Table Top Slab",
            nameMr = "टेबल टॉप स्लॅब",
            category = PartCategory.TOP,
            centerX = 0f,
            centerY = h - t / 2f,
            centerZ = 0f,
            sizeX = w,
            sizeY = t,
            sizeZ = d,
            explodeY = 1.3f,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )

        val legX = w / 2f - legSize / 2f - 35f
        val legZ = d / 2f - legSize / 2f - 35f
        listOf(-legX to legZ, legX to legZ, -legX to -legZ, legX to -legZ).forEachIndexed { idx, (lx, lz) ->
            parts += BoxPart3D(
                id = "ct_leg_$idx",
                groupId = "ct_legs",
                nameEn = "Table Leg",
                nameMr = "टेबलचा पाय",
                category = PartCategory.CARCASS,
                centerX = lx,
                centerY = legH / 2f,
                centerZ = lz,
                sizeX = legSize,
                sizeY = legH,
                sizeZ = legSize,
                explodeY = -0.9f,
                edgeBandingEn = "Vertical",
                edgeBandingMr = "उभी बाजू",
            )
        }

        val apronY = h - t - 35f
        parts += BoxPart3D(
            id = "ct_apron_f",
            groupId = "ct_aprons",
            nameEn = "Apron Rail (Long)",
            nameMr = "लांब सपोर्ट पट्टी",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = apronY,
            centerZ = legZ,
            sizeX = legX * 2f - legSize,
            sizeY = 65f,
            sizeZ = 18f,
            explodeZ = 0.7f,
            edgeBandingEn = "Bottom edge",
            edgeBandingMr = "खालची कडा",
        )
        parts += BoxPart3D(
            id = "ct_apron_b",
            groupId = "ct_aprons",
            nameEn = "Apron Rail (Long)",
            nameMr = "लांब सपोर्ट पट्टी",
            category = PartCategory.CARCASS,
            centerX = 0f,
            centerY = apronY,
            centerZ = -legZ,
            sizeX = legX * 2f - legSize,
            sizeY = 65f,
            sizeZ = 18f,
            explodeZ = -0.7f,
            edgeBandingEn = "Bottom edge",
            edgeBandingMr = "खालची कडा",
        )

        parts += BoxPart3D(
            id = "ct_lower_shelf",
            groupId = "ct_shelf",
            nameEn = "Lower Shelf",
            nameMr = "खालचा शेल्फ",
            category = PartCategory.SHELF,
            centerX = 0f,
            centerY = 120f,
            centerZ = 0f,
            sizeX = w - 100f,
            sizeY = 18f,
            sizeZ = d - 100f,
            explodeY = -0.4f,
            isDoorOrFront = true,
            edgeBandingEn = "All 4 edges",
            edgeBandingMr = "चारही बाजू",
        )

        return parts
    }
}
