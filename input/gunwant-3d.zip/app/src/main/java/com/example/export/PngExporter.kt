package com.example.export

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.FileProvider
import com.example.engine.QuotationCalculator
import com.example.engine.Renderer3D
import com.example.engine.SheetLayoutPlan
import com.example.model.AppLanguage
import com.example.model.BoxPart3D
import com.example.model.CutListSummary
import com.example.model.QuotationBreakdown
import com.example.model.StudioConfig
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PngExporter {

    fun renderStudioSheetBitmap(
        config: StudioConfig,
        parts: List<BoxPart3D>,
        cutList: CutListSummary,
        sheetPlan: SheetLayoutPlan,
        quotation: QuotationBreakdown,
        doorOpenProgress: Float,
    ): Bitmap {
        val width = 1600
        val height = 1200
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        canvas.drawColor(Color.parseColor("#FAF6F0"))

        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#2B1D14")
        }
        canvas.drawRect(0f, 0f, width.toFloat(), 108f, headerPaint)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FFF8EE")
            textSize = 36f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        canvas.drawText("Gunwant 3D Furniture Studio", 44f, 52f, titlePaint)

        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E6B88A")
            textSize = 22f
        }
        val furnitureTitle = config.furnitureType.label(config.language)
        val dimText =
            "${config.unit.formatValue(config.widthMm)} × ${config.unit.formatValue(config.heightMm)} × ${config.unit.formatValue(config.depthMm)}"
        val clientSuffix = if (config.clientOrShopName.isNotBlank()) "   |   ${config.clientOrShopName.trim()}" else ""
        canvas.drawText("$furnitureTitle   |   $dimText$clientSuffix", 44f, 86f, subtitlePaint)

        val dateText = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
        val rightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D8C7B4")
            textSize = 20f
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(dateText, width - 44f, 64f, rightPaint)

        val vpWidth = 1040f
        val vpHeight = 930f
        canvas.save()
        canvas.translate(28f, 132f)
        canvas.clipRect(0f, 0f, vpWidth, vpHeight)
        Renderer3D.drawScene(
            canvas = canvas,
            widthPx = vpWidth,
            heightPx = vpHeight,
            config = config.copy(selectedGroupId = null),
            parts = parts,
            doorOpenProgress = doorOpenProgress,
            density = 2.1f,
        )
        canvas.restore()

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D6C9B8")
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRect(28f, 132f, 28f + vpWidth, 132f + vpHeight, borderPaint)

        val panelLeft = 1096f
        val panelRight = width - 28f
        val panelTop = 132f
        val panelBottom = 1062f
        val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(RectF(panelLeft, panelTop, panelRight, panelBottom), 18f, 18f, cardPaint)
        canvas.drawRoundRect(RectF(panelLeft, panelTop, panelRight, panelBottom), 18f, 18f, borderPaint)

        val secTitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#542D13")
            textSize = 25f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#2E251F")
            textSize = 19f
        }
        val monoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#5C4E44")
            textSize = 17f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        }

        var y = panelTop + 42f
        val x = panelLeft + 24f

        val specHeader = if (config.language == AppLanguage.MARATHI) "तपशील आणि मटेरियल" else "Specs & Finish"
        canvas.drawText(specHeader, x, y, secTitlePaint)
        y += 32f

        val bodyColor = config.customBodyColor ?: config.bodyFinish.primaryColor
        val bodyLabel = if (config.customBodyColor != null) {
            if (config.language == AppLanguage.MARATHI) "कस्टम रंग" else "Custom"
        } else {
            config.bodyFinish.label(config.language)
        }
        val swatchPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = bodyColor.toArgb()
        }
        canvas.drawRoundRect(RectF(x, y - 16f, x + 26f, y + 10f), 6f, 6f, swatchPaint)
        canvas.drawText(
            "${if (config.language == AppLanguage.MARATHI) "बॉडी:" else "Body:"} $bodyLabel",
            x + 36f,
            y + 2f,
            bodyPaint,
        )
        y += 32f

        val doorFinish = config.doorFinish ?: config.bodyFinish
        val doorColor = config.customDoorColor ?: if (config.doorFinish != null) doorFinish.primaryColor else bodyColor
        val doorLabel = when {
            config.customDoorColor != null -> if (config.language == AppLanguage.MARATHI) "कस्टम रंग" else "Custom"
            config.doorFinish != null -> doorFinish.label(config.language)
            else -> bodyLabel
        }
        swatchPaint.color = doorColor.toArgb()
        canvas.drawRoundRect(RectF(x, y - 16f, x + 26f, y + 10f), 6f, 6f, swatchPaint)
        canvas.drawText(
            "${if (config.language == AppLanguage.MARATHI) "दरवाजे:" else "Front:"} $doorLabel",
            x + 36f,
            y + 2f,
            bodyPaint,
        )
        y += 32f

        val areaLabel = if (config.language == AppLanguage.MARATHI) {
            "क्षेत्रफळ: ${String.format("%.1f", cutList.totalAreaSqFt)} sq.ft | ${sheetPlan.totalSheets} शीट (8×4)"
        } else {
            "Area: ${String.format("%.1f", cutList.totalAreaSqFt)} sq.ft | ${sheetPlan.totalSheets} sheets (8×4)"
        }
        canvas.drawText(areaLabel, x, y + 2f, bodyPaint)
        y += 28f

        if (config.quotation.includeInPng) {
            val quoteBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#F3DFCE")
            }
            canvas.drawRoundRect(RectF(x, y, panelRight - 24f, y + 58f), 10f, 10f, quoteBg)
            val quoteLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#542D13")
                textSize = 18f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            }
            val quoteTitle = if (config.language == AppLanguage.MARATHI) {
                "अंदाजे खर्च: ${QuotationCalculator.formatInr(quotation.grandTotal)}"
            } else {
                "Est. Quote: ${QuotationCalculator.formatInr(quotation.grandTotal)}"
            }
            canvas.drawText(quoteTitle, x + 14f, y + 36f, quoteLabelPaint)
            y += 74f
        }

        val divPaint = Paint().apply {
            color = Color.parseColor("#E5DDD1")
            strokeWidth = 2f
        }
        canvas.drawLine(x, y, panelRight - 24f, y, divPaint)
        y += 34f

        val partsHeader = if (config.language == AppLanguage.MARATHI) {
            "पार्ट यादी (${cutList.totalPieces} नग)"
        } else {
            "Cut-List (${cutList.totalPieces} pcs)"
        }
        canvas.drawText(partsHeader, x, y, secTitlePaint)
        y += 32f

        for (item in cutList.items.take(10)) {
            if (y > panelBottom - 36f) break
            canvas.drawText("• ${item.qty}× ${item.name(config.language)}", x, y, bodyPaint)
            y += 22f
            canvas.drawText(
                "   ${config.unit.formatLWT(item.lengthMm, item.widthMm, item.thicknessMm)}",
                x,
                y,
                monoPaint,
            )
            y += 28f
        }

        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#6B5D52")
            textSize = 20f
        }
        val footerNote = if (config.language == AppLanguage.MARATHI) {
            "टिप: कटिंगपूर्वी साईटवरील प्रत्यक्ष मापे तपासा • Gunwant 3D Furniture Studio"
        } else {
            "Note: Verify final site measurements before cutting • Gunwant 3D Furniture Studio"
        }
        canvas.drawText(footerNote, 40f, 1135f, footerPaint)

        return bitmap
    }

    fun buildFileName(config: StudioConfig): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return "Gunwant3D_${config.furnitureType.id}_$stamp.png"
    }

    fun savePngToMediaStore(context: Context, bitmap: Bitmap, fileName: String): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/Gunwant3D")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            resolver.openOutputStream(uri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }

    fun writePngToUri(context: Context, bitmap: Bitmap, uri: Uri): Boolean {
        return try {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            } ?: false
        } catch (_: Exception) {
            false
        }
    }

    fun exportToCacheForShare(context: Context, bitmap: Bitmap, fileName: String): Uri? {
        return try {
            val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val file = File(exportDir, fileName)
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file,
            )
        } catch (_: Exception) {
            null
        }
    }

    fun exportCsvToCacheForShare(
        context: Context,
        config: StudioConfig,
        cutList: CutListSummary,
        sheetPlan: SheetLayoutPlan,
        quotation: QuotationBreakdown,
    ): Uri? {
        return try {
            val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val file = File(exportDir, "Gunwant3D_CutList_${config.furnitureType.id}_$stamp.csv")
            val csv = buildString {
                appendLine("Studio,Gunwant 3D Furniture Studio")
                appendLine("Furniture,\"${config.furnitureType.label(config.language)}\"")
                appendLine("Overall Size,\"${config.unit.formatValue(config.widthMm)} x ${config.unit.formatValue(config.heightMm)} x ${config.unit.formatValue(config.depthMm)}\"")
                appendLine("Sheets Required (8x4 ft),${sheetPlan.totalSheets} (${sheetPlan.averageEfficiencyPct}% efficiency)")
                appendLine("Estimated Cost (INR),${quotation.grandTotal.toInt()}")
                appendLine()
                appendLine("Part Name,Qty,Length (mm),Width (mm),Thickness (mm),Area (sq.ft),Edge Banding")
                for (item in cutList.items) {
                    appendLine("\"${item.name(config.language)}\",${item.qty},${item.lengthMm.toInt()},${item.widthMm.toInt()},${item.thicknessMm.toInt()},${String.format(Locale.US, "%.2f", item.totalAreaSqFt)},\"${item.edgeBanding(config.language)}\"")
                }
            }
            file.writeText(csv, Charsets.UTF_8)
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file,
            )
        } catch (_: Exception) {
            null
        }
    }
}
