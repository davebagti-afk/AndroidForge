package com.example.engine

import com.example.model.AppLanguage
import com.example.model.CutListItem
import com.example.model.PartCategory
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class PlacedCutPiece(
    val groupId: String,
    val labelEn: String,
    val labelMr: String,
    val category: PartCategory,
    val xMm: Float,
    val yMm: Float,
    val widthMm: Float,
    val heightMm: Float,
    val origLengthMm: Float,
    val origWidthMm: Float,
    val rotated: Boolean,
) {
    fun label(lang: AppLanguage): String = if (lang == AppLanguage.MARATHI) labelMr else labelEn
}

data class PackedSheet(
    val sheetNumber: Int,
    val thicknessMm: Int,
    val sheetWidthMm: Float,
    val sheetHeightMm: Float,
    val pieces: List<PlacedCutPiece>,
    val usedAreaMm2: Float,
    val efficiencyPct: Int,
)

data class SheetLayoutPlan(
    val sheets: List<PackedSheet>,
    val totalSheets: Int,
    val averageEfficiencyPct: Int,
)

object SheetOptimizer {

    const val SHEET_LENGTH_MM = 2440f // 8 ft
    const val SHEET_WIDTH_MM = 1220f  // 4 ft
    private const val KERF_MM = 4f

    private data class RawPiece(
        val groupId: String,
        val nameEn: String,
        val nameMr: String,
        val category: PartCategory,
        val lengthMm: Float,
        val widthMm: Float,
        val thicknessMm: Int,
    )

    private data class ShelfRow(
        val yMm: Float,
        val rowHeightMm: Float,
        var usedXMm: Float,
    )

    private class MutableSheet(
        val thicknessMm: Int,
        val sheetW: Float = SHEET_LENGTH_MM,
        val sheetH: Float = SHEET_WIDTH_MM,
    ) {
        val shelves = mutableListOf<ShelfRow>()
        val pieces = mutableListOf<PlacedCutPiece>()
        var usedY: Float = 0f

        fun tryPlace(piece: RawPiece, allowRotation: Boolean): Boolean {
            val l = piece.lengthMm.coerceAtMost(sheetW)
            val w = piece.widthMm.coerceAtMost(sheetH)

            val orientations = if (allowRotation) {
                // Prefer orientation that minimizes row height if both fit, or fits existing shelf
                listOf(
                    Triple(l, w, false),
                    Triple(w, l, true),
                ).distinctBy { it.first to it.second }
            } else {
                listOf(Triple(l, w, false))
            }

            // 1. Try fitting into an existing shelf
            for (shelf in shelves) {
                for ((pw, ph, rot) in orientations) {
                    if (pw <= sheetW - shelf.usedXMm && ph <= shelf.rowHeightMm) {
                        pieces += PlacedCutPiece(
                            groupId = piece.groupId,
                            labelEn = piece.nameEn,
                            labelMr = piece.nameMr,
                            category = piece.category,
                            xMm = shelf.usedXMm,
                            yMm = shelf.yMm,
                            widthMm = pw,
                            heightMm = ph,
                            origLengthMm = piece.lengthMm,
                            origWidthMm = piece.widthMm,
                            rotated = rot,
                        )
                        shelf.usedXMm += pw + KERF_MM
                        return true
                    }
                }
            }

            // 2. Try starting a new shelf (pick orientation with smaller height that still fits width)
            val validNew = orientations.filter { (pw, ph, _) ->
                pw <= sheetW && ph <= (sheetH - usedY)
            }.minByOrNull { it.second }

            if (validNew != null) {
                val (pw, ph, rot) = validNew
                val newShelf = ShelfRow(
                    yMm = usedY,
                    rowHeightMm = ph,
                    usedXMm = pw + KERF_MM,
                )
                shelves += newShelf
                pieces += PlacedCutPiece(
                    groupId = piece.groupId,
                    labelEn = piece.nameEn,
                    labelMr = piece.nameMr,
                    category = piece.category,
                    xMm = 0f,
                    yMm = usedY,
                    widthMm = pw,
                    heightMm = ph,
                    origLengthMm = piece.lengthMm,
                    origWidthMm = piece.widthMm,
                    rotated = rot,
                )
                usedY += ph + KERF_MM
                return true
            }

            return false
        }
    }

    fun packSheets(items: List<CutListItem>, allowRotation: Boolean): SheetLayoutPlan {
        val rawPieces = mutableListOf<RawPiece>()
        for (item in items) {
            val l = max(item.lengthMm, item.widthMm)
            val w = min(item.lengthMm, item.widthMm)
            val thick = item.thicknessMm.roundToInt()
            repeat(item.qty) {
                rawPieces += RawPiece(
                    groupId = item.groupId,
                    nameEn = item.nameEn,
                    nameMr = item.nameMr,
                    category = item.category,
                    lengthMm = l,
                    widthMm = w,
                    thicknessMm = thick,
                )
            }
        }

        val byThickness = rawPieces.groupBy { it.thicknessMm }.toSortedMap(compareByDescending { it })
        val packedSheets = mutableListOf<PackedSheet>()
        var sheetIdx = 1

        for ((thick, groupPieces) in byThickness) {
            val sorted = groupPieces.sortedWith(
                compareByDescending<RawPiece> { it.widthMm }.thenByDescending { it.lengthMm },
            )
            val openSheets = mutableListOf<MutableSheet>()

            for (p in sorted) {
                var placed = false
                for (s in openSheets) {
                    if (s.tryPlace(p, allowRotation)) {
                        placed = true
                        break
                    }
                }
                if (!placed) {
                    val fresh = MutableSheet(thicknessMm = thick)
                    fresh.tryPlace(p, allowRotation)
                    openSheets += fresh
                }
            }

            for (ms in openSheets) {
                val sheetArea = ms.sheetW * ms.sheetH
                val usedArea = ms.pieces.sumOf { (it.widthMm * it.heightMm).toDouble() }.toFloat()
                val eff = ((usedArea / sheetArea) * 100f).roundToInt().coerceIn(1, 100)
                packedSheets += PackedSheet(
                    sheetNumber = sheetIdx++,
                    thicknessMm = ms.thicknessMm,
                    sheetWidthMm = ms.sheetW,
                    sheetHeightMm = ms.sheetH,
                    pieces = ms.pieces,
                    usedAreaMm2 = usedArea,
                    efficiencyPct = eff,
                )
            }
        }

        val avgEff = if (packedSheets.isEmpty()) 0 else packedSheets.map { it.efficiencyPct }.average().roundToInt()
        return SheetLayoutPlan(
            sheets = packedSheets,
            totalSheets = packedSheets.size,
            averageEfficiencyPct = avgEff,
        )
    }
}
