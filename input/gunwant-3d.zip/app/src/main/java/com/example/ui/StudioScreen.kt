package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.AppLanguage
import com.example.ui.components.DesignTabContent
import com.example.ui.components.FinishTabContent
import com.example.ui.components.PartsTabContent
import com.example.ui.components.QuoteTabContent
import com.example.ui.components.SizeTabContent
import com.example.ui.components.Viewport3D
import kotlinx.coroutines.launch

@Composable
fun StudioScreen(
    viewModel: StudioViewModel = viewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val config = uiState.config
    val lang = config.language
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    val safLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("image/png"),
    ) { uri ->
        viewModel.completeSafSave(uri)
    }

    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            when (event) {
                is StudioEvent.ShowMessage -> {
                    snackbarHostState.showSnackbar(event.message)
                }
                is StudioEvent.LaunchSafSave -> {
                    safLauncher.launch(event.fileName)
                }
                is StudioEvent.LaunchShareIntent -> {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = event.mimeType
                        putExtra(Intent.EXTRA_STREAM, event.uri)
                        putExtra(Intent.EXTRA_SUBJECT, event.subject)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    val chooserTitle = if (lang == AppLanguage.MARATHI) "शेअर करा" else "Share"
                    context.startActivity(Intent.createChooser(shareIntent, chooserTitle))
                }
            }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            StudioTopBar(
                language = lang,
                isExporting = uiState.isExporting,
                onToggleLanguage = viewModel::toggleLanguage,
                onSharePng = viewModel::sharePng,
                onSavePng = viewModel::savePng,
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 12.dp, vertical = 6.dp),
        ) {
            val isWide = maxWidth >= 700.dp

            val inspectorContent: @Composable (Modifier) -> Unit = { mod ->
                StudioInspectorPane(
                    uiState = uiState,
                    viewModel = viewModel,
                    onCopyCutList = {
                        copyTextToClipboard(context, "Gunwant 3D Cut-List", viewModel.buildFormattedCutListText())
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar(
                                if (lang == AppLanguage.MARATHI) "पार्ट यादी कॉपी झाली" else "Cut-list copied to clipboard",
                            )
                        }
                    },
                    onCopyQuote = {
                        copyTextToClipboard(context, "Gunwant 3D Quote", viewModel.buildFormattedQuotationText())
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar(
                                if (lang == AppLanguage.MARATHI) "कोटेशन कॉपी झाले" else "Quotation copied to clipboard",
                            )
                        }
                    },
                    modifier = mod,
                )
            }

            if (isWide) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    Viewport3D(
                        config = config,
                        parts = uiState.parts,
                        onOrbit = viewModel::orbitBy,
                        onZoom = viewModel::zoomBy,
                        onSelectCameraPreset = viewModel::applyCameraPreset,
                        onToggleDoors = viewModel::toggleDoorsOpen,
                        onToggleExplode = {
                            viewModel.setExplodeFactor(if (config.explodeFactor > 0.05f) 0f else 0.72f)
                        },
                        onToggleDimensions = viewModel::toggleDimensions,
                        onToggleGrid = viewModel::toggleGrid,
                        onCycleBackdrop = viewModel::cycleBackdrop,
                        modifier = Modifier
                            .weight(0.54f)
                            .fillMaxHeight(),
                    )
                    inspectorContent(
                        Modifier
                            .weight(0.46f)
                            .fillMaxHeight(),
                    )
                }
            } else {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    Viewport3D(
                        config = config,
                        parts = uiState.parts,
                        onOrbit = viewModel::orbitBy,
                        onZoom = viewModel::zoomBy,
                        onSelectCameraPreset = viewModel::applyCameraPreset,
                        onToggleDoors = viewModel::toggleDoorsOpen,
                        onToggleExplode = {
                            viewModel.setExplodeFactor(if (config.explodeFactor > 0.05f) 0f else 0.72f)
                        },
                        onToggleDimensions = viewModel::toggleDimensions,
                        onToggleGrid = viewModel::toggleGrid,
                        onCycleBackdrop = viewModel::cycleBackdrop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(0.46f),
                    )
                    inspectorContent(
                        Modifier
                            .fillMaxWidth()
                            .weight(0.54f),
                    )
                }
            }
        }
    }
}

@Composable
private fun StudioTopBar(
    language: AppLanguage,
    isExporting: Boolean,
    onToggleLanguage: () -> Unit,
    onSharePng: () -> Unit,
    onSavePng: () -> Unit,
) {
    Surface(
        color = MaterialTheme.colorScheme.background,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f),
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.primary),
                ) {
                    Icon(
                        imageVector = Icons.Filled.ViewInAr,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(22.dp),
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Gunwant 3D",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 1,
                    )
                    Text(
                        text = if (language == AppLanguage.MARATHI) "फर्निचर डिझाइन स्टुडिओ" else "Furniture Studio",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
                        .clip(RoundedCornerShape(10.dp))
                        .clickable(onClick = onToggleLanguage)
                        .minimumInteractiveComponentSize()
                        .testTag("language_toggle_button"),
                ) {
                    Text(
                        text = if (language == AppLanguage.MARATHI) "मराठी" else "EN",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                    )
                }

                IconButton(
                    onClick = onSharePng,
                    enabled = !isExporting,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("share_png_button"),
                ) {
                    Icon(
                        imageVector = Icons.Filled.Share,
                        contentDescription = if (language == AppLanguage.MARATHI) "PNG शेअर करा" else "Share PNG",
                        tint = MaterialTheme.colorScheme.onBackground,
                    )
                }

                Button(
                    onClick = onSavePng,
                    enabled = !isExporting,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("save_png_button"),
                ) {
                    if (isExporting) {
                        CircularProgressIndicator(
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(16.dp),
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Filled.Download,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "PNG",
                        style = MaterialTheme.typography.labelLarge,
                    )
                }
            }
        }
    }
}

@Composable
private fun StudioInspectorPane(
    uiState: StudioUiState,
    viewModel: StudioViewModel,
    onCopyCutList: () -> Unit,
    onCopyQuote: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val config = uiState.config
    val lang = config.language
    val tabs = StudioTab.entries

    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(18.dp),
        modifier = modifier.border(
            1.dp,
            MaterialTheme.colorScheme.outlineVariant,
            RoundedCornerShape(18.dp),
        ),
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            ScrollableTabRow(
                selectedTabIndex = tabs.indexOf(uiState.activeTab),
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                edgePadding = 6.dp,
            ) {
                tabs.forEach { tab ->
                    val selected = uiState.activeTab == tab
                    Tab(
                        selected = selected,
                        onClick = { viewModel.selectTab(tab) },
                        icon = {
                            Icon(
                                imageVector = tabIcon(tab),
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                            )
                        },
                        text = {
                            Text(
                                text = tab.label(lang),
                                style = MaterialTheme.typography.labelMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        },
                        modifier = Modifier.testTag("tab_${tab.name.lowercase()}"),
                    )
                }
            }

            Box(modifier = Modifier.weight(1f)) {
                when (uiState.activeTab) {
                    StudioTab.DESIGN -> DesignTabContent(
                        config = config,
                        onSelectFurniture = viewModel::selectFurnitureType,
                    )
                    StudioTab.SIZE -> SizeTabContent(
                        config = config,
                        onSetUnit = viewModel::setUnit,
                        onSetWidth = viewModel::setWidthMm,
                        onSetHeight = viewModel::setHeightMm,
                        onSetDepth = viewModel::setDepthMm,
                        onSetThickness = viewModel::setThicknessMm,
                        onSetShelfCount = viewModel::setShelfCount,
                        onSetDrawerCount = viewModel::setDrawerCount,
                        onSetExplode = viewModel::setExplodeFactor,
                    )
                    StudioTab.FINISH -> FinishTabContent(
                        config = config,
                        onSetBodyFinish = viewModel::setBodyFinish,
                        onSetDoorFinish = viewModel::setDoorFinish,
                        onSetCustomBodyColor = viewModel::setCustomBodyColor,
                        onSetCustomDoorColor = viewModel::setCustomDoorColor,
                        onSetHardwareFinish = viewModel::setHardwareFinish,
                        onSetRoomBackdrop = viewModel::setRoomBackdrop,
                    )
                    StudioTab.PARTS -> PartsTabContent(
                        config = config,
                        cutList = uiState.cutList,
                        sheetPlan = uiState.sheetPlan,
                        onSelectPartGroup = viewModel::selectPartGroup,
                        onToggleAllowRotation = viewModel::toggleAllowSheetRotation,
                        onCopyCutList = onCopyCutList,
                        onExportCsv = viewModel::shareCsvCutList,
                    )
                    StudioTab.QUOTE -> QuoteTabContent(
                        config = config,
                        sheetPlan = uiState.sheetPlan,
                        breakdown = uiState.quotationBreakdown,
                        onSetClientName = viewModel::setClientOrShopName,
                        onUpdateQuotation = viewModel::updateQuotation,
                        onCopyQuote = onCopyQuote,
                    )
                }
            }
        }
    }
}

private fun tabIcon(tab: StudioTab): ImageVector = when (tab) {
    StudioTab.DESIGN -> Icons.Filled.Category
    StudioTab.SIZE -> Icons.Filled.Straighten
    StudioTab.FINISH -> Icons.Filled.Palette
    StudioTab.PARTS -> Icons.Filled.FormatListBulleted
    StudioTab.QUOTE -> Icons.Filled.CurrencyRupee
}

private fun copyTextToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
}
