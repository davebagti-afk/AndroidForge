package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppLanguage
import com.example.model.DimensionUnit
import com.example.model.RoomBackdrop
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.studioDataStore: DataStore<Preferences> by preferencesDataStore(name = "gunwant_studio_prefs")

data class PersistedStudioPrefs(
    val language: AppLanguage = AppLanguage.MARATHI,
    val unit: DimensionUnit = DimensionUnit.FT_IN,
    val showDimensions: Boolean = true,
    val showGrid: Boolean = true,
    val roomBackdrop: RoomBackdrop = RoomBackdrop.ROOM_CREAM,
)

class StudioPreferences(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("language")
        val UNIT = stringPreferencesKey("unit")
        val SHOW_DIMENSIONS = booleanPreferencesKey("show_dimensions")
        val SHOW_GRID = booleanPreferencesKey("show_grid")
        val ROOM_BACKDROP = stringPreferencesKey("room_backdrop")
    }

    val prefsFlow: Flow<PersistedStudioPrefs> = context.studioDataStore.data.map { prefs ->
        PersistedStudioPrefs(
            language = prefs[Keys.LANGUAGE]?.let { runCatching { AppLanguage.valueOf(it) }.getOrNull() }
                ?: AppLanguage.MARATHI,
            unit = prefs[Keys.UNIT]?.let { runCatching { DimensionUnit.valueOf(it) }.getOrNull() }
                ?: DimensionUnit.FT_IN,
            showDimensions = prefs[Keys.SHOW_DIMENSIONS] ?: true,
            showGrid = prefs[Keys.SHOW_GRID] ?: true,
            roomBackdrop = prefs[Keys.ROOM_BACKDROP]?.let { runCatching { RoomBackdrop.valueOf(it) }.getOrNull() }
                ?: RoomBackdrop.ROOM_CREAM,
        )
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.studioDataStore.edit { it[Keys.LANGUAGE] = language.name }
    }

    suspend fun setUnit(unit: DimensionUnit) {
        context.studioDataStore.edit { it[Keys.UNIT] = unit.name }
    }

    suspend fun setShowDimensions(show: Boolean) {
        context.studioDataStore.edit { it[Keys.SHOW_DIMENSIONS] = show }
    }

    suspend fun setShowGrid(show: Boolean) {
        context.studioDataStore.edit { it[Keys.SHOW_GRID] = show }
    }

    suspend fun setRoomBackdrop(backdrop: RoomBackdrop) {
        context.studioDataStore.edit { it[Keys.ROOM_BACKDROP] = backdrop.name }
    }
}
