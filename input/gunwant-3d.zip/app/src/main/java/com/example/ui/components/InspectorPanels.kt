package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bed
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Countertops
import androidx.compose.material.icons.filled.Desk
import androidx.compose.material.icons.filled.DoorBack
import androidx.compose.material.icons.filled.DoorSliding
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.TableBar
import androidx.compose.material.icons.filled.TempleHindu
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.AppLanguage
import com.example.model.DimensionUnit
import com.example.model.FurnitureType
import com.example.model.HardwareFinish
import com.example.model.RoomBackdrop
import com.example.model.StudioConfig
import com.example.model.WoodFinish

@Composable
fun DesignTabContent(
    config: StudioConfig,
    onSelectFurniture: (FurnitureType) -> Unit,
    modifier: Modifier = Modifier,
) {
    val lang = config.language
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = modifier.fillMaxSize(),
    ) {
        item {
            Text(
                text = if (lang == AppLanguage.MARATHI) "फर्निचर प्रकार निवडा (${FurnitureType.entries.size})" else "Choose Furniture Type (${FurnitureType.entries.size})",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
            )
        }

        val rows = FurnitureType.entries.chunked(2)
        items(rows) { pair ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                pair.forEach { type ->
                    val selected = type == config.furnitureType
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (selected) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            },
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(
                                width = if (selected) 1.5.dp else 1.dp,
                                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                shape = RoundedCornerShape(14.dp),
                            )
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onSelectFurniture(type) }
                            .testTag("furniture_card_${type.id}"),
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(
                                            if (selected) MaterialTheme.colorScheme.primary
                                            else MaterialTheme.colorScheme.surface,
                                        ),
                                ) {
                                    Icon(
                                        imageVector = furnitureIcon(type),
                                        contentDescription = type.label(lang),
                                        tint = if (selected) MaterialTheme.colorScheme.onPrimary
                                        else MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp),
                                    )
                                }
                                if (selected) {
                                    Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp),
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = type.label(lang),
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${config.unit.formatNumberOnly(type.defaultWidthMm)} × ${config.unit.formatNumberOnly(type.defaultHeightMm)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
                if (pair.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SizeTabContent(
    config: StudioConfig,
    onSetUnit: (DimensionUnit) -> Unit,
    onSetWidth: (Float) -> Unit,
    onSetHeight: (Float) -> Unit,
    onSetDepth: (Float) -> Unit,
    onSetThickness: (Float) -> Unit,
    onSetShelfCount: (Int) -> Unit,
    onSetDrawerCount: (Int) -> Unit,
    onSetExplode: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    val lang = config.language
    val type = config.furnitureType
    val stepMm = when (config.unit) {
        DimensionUnit.MM -> 10f
        DimensionUnit.CM -> 50f
        DimensionUnit.INCH, DimensionUnit.FT_IN -> 25.4f
    }

    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = modifier.fillMaxSize(),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = if (lang == AppLanguage.MARATHI) "मापन एकक (Unit)" else "Measurement Unit",
                    style = MaterialTheme.typography.titleSmall,
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DimensionUnit.entries.forEach { u ->
                        FilterChip(
                            selected = u == config.unit,
                            onClick = { onSetUnit(u) },
                            label = { Text(u.shortLabel) },
                            modifier = Modifier.testTag("unit_chip_${u.name.lowercase()}"),
                        )
                    }
                }
            }
        }

        item {
            DimensionControlCard(
                label = if (lang == AppLanguage.MARATHI) "रुंदी (Width)" else "Width",
                valueText = config.unit.formatValue(config.widthMm),
                value = config.widthMm,
                min = type.minWidthMm,
                max = type.maxWidthMm,
                step = stepMm,
                unit = config.unit,
                onValueChange = onSetWidth,
                testTagPrefix = "width",
                lang = lang,
            )
        }

        item {
            DimensionControlCard(
                label = if (lang == AppLanguage.MARATHI) "उंची (Height)" else "Height",
                valueText = config.unit.formatValue(config.heightMm),
                value = config.heightMm,
                min = type.minHeightMm,
                max = type.maxHeightMm,
                step = stepMm,
                unit = config.unit,
                onValueChange = onSetHeight,
                testTagPrefix = "height",
                lang = lang,
            )
        }

        item {
            DimensionControlCard(
                label = if (lang == AppLanguage.MARATHI) "खोली (Depth)" else "Depth",
                valueText = config.unit.formatValue(config.depthMm),
                value = config.depthMm,
                min = type.minDepthMm,
                max = type.maxDepthMm,
                step = stepMm,
                unit = config.unit,
                onValueChange = onSetDepth,
                testTagPrefix = "depth",
                lang = lang,
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp)),
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(12.dp),
                ) {
                    Text(
                        text = if (lang == AppLanguage.MARATHI) "प्लायवूड / पत्रा जाडी" else "Board Thickness",
                        style = MaterialTheme.typography.titleSmall,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(12f, 18f, 25f).forEach { thick ->
                            FilterChip(
                                selected = config.thicknessMm == thick,
                                onClick = { onSetThickness(thick) },
                                label = { Text("${thick.toInt()} mm") },
                                modifier = Modifier.testTag("thickness_${thick.toInt()}mm"),
                            )
                        }
                    }

                    if (type.supportsShelves) {
                        StepperRow(
                            label = if (lang == AppLanguage.MARATHI) "कप्पे / शेल्फ संख्या" else "Shelf Count",
                            valueText = "${config.shelfCount}",
                            onMinus = { onSetShelfCount(config.shelfCount - 1) },
                            onPlus = { onSetShelfCount(config.shelfCount + 1) },
                            testTagPrefix = "shelf",
                            lang = lang,
                        )
                    }

                    if (type.supportsDrawers) {
                        StepperRow(
                            label = if (lang == AppLanguage.MARATHI) "ड्रॉवर्स संख्या" else "Drawer Count",
                            valueText = "${config.drawerCount}",
                            onMinus = { onSetDrawerCount(config.drawerCount - 1) },
                            onPlus = { onSetDrawerCount(config.drawerCount + 1) },
                            testTagPrefix = "drawer",
                            lang = lang,
                        )
                    }

                    Column {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                text = if (lang == AppLanguage.MARATHI) "पार्ट सुटे करून पहा (Explode)" else "Exploded View",
                                style = MaterialTheme.typography.titleSmall,
                            )
                            Text(
                                text = "${(config.explodeFactor * 100).toInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                        Slider(
                            value = config.explodeFactor,
                            onValueChange = onSetExplode,
                            valueRange = 0f..1f,
                            modifier = Modifier.testTag("explode_slider"),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StepperRow(
    label: String,
    valueText: String,
    onMinus: () -> Unit,
    onPlus: () -> Unit,
    testTagPrefix: String,
    lang: AppLanguage,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Text(text = label, style = MaterialTheme.typography.titleSmall)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            IconButton(
                onClick = onMinus,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface)
                    .testTag("${testTagPrefix}_minus_button"),
            ) {
                Icon(
                    Icons.Filled.Remove,
                    contentDescription = if (lang == AppLanguage.MARATHI) "कमी करा" else "Decrease",
                )
            }
            Text(
                text = valueText,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(horizontal = 8.dp),
            )
            IconButton(
                onClick = onPlus,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface)
                    .testTag("${testTagPrefix}_plus_button"),
            ) {
                Icon(
                    Icons.Filled.Add,
                    contentDescription = if (lang == AppLanguage.MARATHI) "वाढवा" else "Increase",
                )
            }
        }
    }
}

@Composable
private fun DimensionControlCard(
    label: String,
    valueText: String,
    value: Float,
    min: Float,
    max: Float,
    step: Float,
    unit: DimensionUnit,
    onValueChange: (Float) -> Unit,
    testTagPrefix: String,
    lang: AppLanguage,
) {
    var showEditDialog by remember { mutableStateOf(false) }

    if (showEditDialog) {
        val currentInUnit = when (unit) {
            DimensionUnit.MM -> value.toInt().toString()
            DimensionUnit.CM -> String.format("%.1f", value / 10f)
            DimensionUnit.INCH, DimensionUnit.FT_IN -> String.format("%.1f", value / 25.4f)
        }
        val inputUnitLabel = if (unit == DimensionUnit.FT_IN) "inch" else unit.shortLabel
        var textInput by remember { mutableStateOf(currentInUnit) }

        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text("$label ($inputUnitLabel)") },
            text = {
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    label = { Text(if (lang == AppLanguage.MARATHI) "माप टाका" else "Enter measurement") },
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val parsed = textInput.toFloatOrNull()
                        if (parsed != null) {
                            val mm = when (unit) {
                                DimensionUnit.MM -> parsed
                                DimensionUnit.CM -> parsed * 10f
                                DimensionUnit.INCH, DimensionUnit.FT_IN -> parsed * 25.4f
                            }
                            onValueChange(mm.coerceIn(min, max))
                        }
                        showEditDialog = false
                    },
                ) {
                    Text(if (lang == AppLanguage.MARATHI) "सेट करा" else "Apply")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) {
                    Text(if (lang == AppLanguage.MARATHI) "रद्द" else "Cancel")
                }
            },
        )
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp)),
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(text = label, style = MaterialTheme.typography.titleSmall)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    IconButton(
                        onClick = { onValueChange((value - step).coerceIn(min, max)) },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface)
                            .testTag("${testTagPrefix}_minus"),
                    ) {
                        Icon(
                            Icons.Filled.Remove,
                            contentDescription = if (lang == AppLanguage.MARATHI) "कमी करा" else "Decrease",
                            modifier = Modifier.size(18.dp),
                        )
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showEditDialog = true }
                            .testTag("${testTagPrefix}_badge"),
                    ) {
                        Text(
                            text = valueText,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        )
                    }
                    IconButton(
                        onClick = { onValueChange((value + step).coerceIn(min, max)) },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface)
                            .testTag("${testTagPrefix}_plus"),
                    ) {
                        Icon(
                            Icons.Filled.Add,
                            contentDescription = if (lang == AppLanguage.MARATHI) "वाढवा" else "Increase",
                            modifier = Modifier.size(18.dp),
                        )
                    }
                }
            }
            Slider(
                value = value,
                onValueChange = onValueChange,
                valueRange = min..max,
                modifier = Modifier.testTag("${testTagPrefix}_slider"),
            )
        }
    }
}

@Composable
fun FinishTabContent(
    config: StudioConfig,
    onSetBodyFinish: (WoodFinish) -> Unit,
    onSetDoorFinish: (WoodFinish?) -> Unit,
    onSetCustomBodyColor: (Color?) -> Unit,
    onSetCustomDoorColor: (Color?) -> Unit,
    onSetHardwareFinish: (HardwareFinish) -> Unit,
    onSetRoomBackdrop: (RoomBackdrop) -> Unit,
    modifier: Modifier = Modifier,
) {
    val lang = config.language
    var showCustomBodyPicker by remember { mutableStateOf(false) }
    var showCustomDoorPicker by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = modifier.fillMaxSize(),
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = if (lang == AppLanguage.MARATHI) "मुख्य सांगाडा रंग (Body)" else "Body Laminate / Wood Finish",
                    style = MaterialTheme.typography.titleSmall,
                )
                FilterChip(
                    selected = config.customBodyColor != null || showCustomBodyPicker,
                    onClick = { showCustomBodyPicker = !showCustomBodyPicker },
                    label = { Text(if (lang == AppLanguage.MARATHI) "कस्टम रंग" else "Custom") },
                    modifier = Modifier.testTag("custom_body_color_chip"),
                )
            }
            if (showCustomBodyPicker) {
                Spacer(modifier = Modifier.height(6.dp))
                InlineCustomColorPicker(
                    initialColor = config.customBodyColor ?: config.bodyFinish.primaryColor,
                    onColorChange = { onSetCustomBodyColor(it) },
                    lang = lang,
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(WoodFinish.entries) { finish ->
                    FinishSwatchItem(
                        finish = finish,
                        label = finish.label(lang),
                        selected = config.customBodyColor == null && config.bodyFinish == finish,
                        onClick = {
                            showCustomBodyPicker = false
                            onSetBodyFinish(finish)
                        },
                        testTag = "body_finish_${finish.id}",
                    )
                }
            }
        }

        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = if (lang == AppLanguage.MARATHI) "दरवाजे / फ्रंट रंग (Two-Tone)" else "Door & Front Accent Finish",
                    style = MaterialTheme.typography.titleSmall,
                )
                FilterChip(
                    selected = config.customDoorColor != null || showCustomDoorPicker,
                    onClick = { showCustomDoorPicker = !showCustomDoorPicker },
                    label = { Text(if (lang == AppLanguage.MARATHI) "कस्टम रंग" else "Custom") },
                    modifier = Modifier.testTag("custom_door_color_chip"),
                )
            }
            if (showCustomDoorPicker) {
                Spacer(modifier = Modifier.height(6.dp))
                InlineCustomColorPicker(
                    initialColor = config.customDoorColor ?: (config.doorFinish ?: config.bodyFinish).primaryColor,
                    onColorChange = { onSetCustomDoorColor(it) },
                    lang = lang,
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    val isSame = config.customDoorColor == null && config.doorFinish == null
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .width(76.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                showCustomDoorPicker = false
                                onSetDoorFinish(null)
                            }
                            .padding(vertical = 4.dp)
                            .testTag("door_finish_same"),
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(config.customBodyColor ?: config.bodyFinish.primaryColor)
                                .border(
                                    width = if (isSame) 3.dp else 1.5.dp,
                                    color = if (isSame) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                    shape = CircleShape,
                                ),
                        ) {
                            if (isSame) {
                                Icon(
                                    Icons.Filled.Check,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.surface,
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (lang == AppLanguage.MARATHI) "बॉडीप्रमाणे" else "Match Body",
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                items(WoodFinish.entries) { finish ->
                    FinishSwatchItem(
                        finish = finish,
                        label = finish.label(lang),
                        selected = config.customDoorColor == null && config.doorFinish == finish,
                        onClick = {
                            showCustomDoorPicker = false
                            onSetDoorFinish(finish)
                        },
                        testTag = "door_finish_${finish.id}",
                    )
                }
            }
        }

        item {
            Text(
                text = if (lang == AppLanguage.MARATHI) "रूम भिंत व स्टुडिओ बॅकग्राउंड" else "Room Wall & Studio Backdrop",
                style = MaterialTheme.typography.titleSmall,
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(RoomBackdrop.entries) { backdrop ->
                    val selected = config.roomBackdrop == backdrop
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .width(80.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSetRoomBackdrop(backdrop) }
                            .padding(vertical = 4.dp)
                            .testTag("backdrop_${backdrop.id}"),
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .border(
                                    width = if (selected) 3.dp else 1.5.dp,
                                    color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                    shape = CircleShape,
                                ),
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                drawRect(
                                    color = backdrop.wallColor,
                                    topLeft = Offset.Zero,
                                    size = Size(size.width, size.height * 0.62f),
                                )
                                drawRect(
                                    color = backdrop.floorColor,
                                    topLeft = Offset(0f, size.height * 0.62f),
                                    size = Size(size.width, size.height * 0.38f),
                                )
                            }
                            if (selected) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primary,
                                    shape = CircleShape,
                                    modifier = Modifier.size(22.dp),
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.padding(3.dp),
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = backdrop.label(lang),
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = if (lang == AppLanguage.MARATHI) "हँडल व हार्डवेअर" else "Handles & Hardware",
                style = MaterialTheme.typography.titleSmall,
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(HardwareFinish.entries) { hw ->
                    val selected = config.hardwareFinish == hw
                    FilterChip(
                        selected = selected,
                        onClick = { onSetHardwareFinish(hw) },
                        leadingIcon = {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(hw.color)
                                    .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape),
                            )
                        },
                        label = { Text(hw.label(lang)) },
                        modifier = Modifier.testTag("hardware_${hw.id}"),
                    )
                }
            }
        }
    }
}

@Composable
private fun FinishSwatchItem(
    finish: WoodFinish,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(76.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp)
            .testTag(testTag),
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(50.dp)
                .clip(CircleShape)
                .border(
                    width = if (selected) 3.dp else 1.5.dp,
                    color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                    shape = CircleShape,
                ),
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(color = finish.primaryColor)
                if (finish.isWoodGrain) {
                    for (i in 1..4) {
                        val y = size.height * (i / 5f)
                        drawLine(
                            color = finish.grainColor,
                            start = Offset(0f, y),
                            end = Offset(size.width, y - 4f),
                            strokeWidth = 2.5f,
                        )
                    }
                }
            }
            if (selected) {
                Surface(
                    color = MaterialTheme.colorScheme.primary,
                    shape = CircleShape,
                    modifier = Modifier.size(22.dp),
                ) {
                    Icon(
                        imageVector = Icons.Filled.Check,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.padding(3.dp),
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun InlineCustomColorPicker(
    initialColor: Color,
    onColorChange: (Color) -> Unit,
    lang: AppLanguage,
) {
    val hsv = remember(initialColor) {
        val out = FloatArray(3)
        android.graphics.Color.colorToHSV(
            android.graphics.Color.rgb(
                (initialColor.red * 255).toInt(),
                (initialColor.green * 255).toInt(),
                (initialColor.blue * 255).toInt(),
            ),
            out,
        )
        out
    }
    var hue by remember { mutableFloatStateOf(hsv[0]) }
    var sat by remember { mutableFloatStateOf(hsv[1].coerceAtLeast(0.25f)) }
    var value by remember { mutableFloatStateOf(hsv[2].coerceAtLeast(0.35f)) }

    fun emitColor() {
        val argb = android.graphics.Color.HSVToColor(floatArrayOf(hue, sat, value))
        onColorChange(Color(argb))
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp)),
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, sat, value))))
                        .border(1.5.dp, MaterialTheme.colorScheme.outline, CircleShape),
                )
                Text(
                    text = if (lang == AppLanguage.MARATHI) "रंग (Hue) व चमक (Shade) निवडा" else "Adjust Hue & Brightness",
                    style = MaterialTheme.typography.labelMedium,
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                Color.Red,
                                Color.Yellow,
                                Color.Green,
                                Color.Cyan,
                                Color.Blue,
                                Color.Magenta,
                                Color.Red,
                            ),
                        ),
                    ),
            )
            Slider(
                value = hue,
                onValueChange = {
                    hue = it
                    emitColor()
                },
                valueRange = 0f..360f,
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    text = if (lang == AppLanguage.MARATHI) "गडद/फिकट" else "Tone",
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.width(64.dp),
                )
                Slider(
                    value = sat,
                    onValueChange = {
                        sat = it
                        emitColor()
                    },
                    valueRange = 0f..1f,
                    modifier = Modifier.weight(1f),
                )
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    text = if (lang == AppLanguage.MARATHI) "प्रकाश" else "Light",
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.width(64.dp),
                )
                Slider(
                    value = value,
                    onValueChange = {
                        value = it
                        emitColor()
                    },
                    valueRange = 0.15f..1f,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

private fun furnitureIcon(type: FurnitureType): ImageVector = when (type) {
    FurnitureType.WARDROBE -> Icons.Filled.DoorBack
    FurnitureType.SLIDING_WARDROBE -> Icons.Filled.DoorSliding
    FurnitureType.KITCHEN_CABINET -> Icons.Filled.Countertops
    FurnitureType.POOJA_UNIT -> Icons.Filled.TempleHindu
    FurnitureType.SHOE_RACK -> Icons.Filled.ShoppingBag
    FurnitureType.DRAWER_CHEST -> Icons.Filled.Inventory2
    FurnitureType.STUDY_DESK -> Icons.Filled.Desk
    FurnitureType.TV_CONSOLE -> Icons.Filled.Tv
    FurnitureType.BOOKSHELF -> Icons.Filled.ViewAgenda
    FurnitureType.STORAGE_BED -> Icons.Filled.Bed
    FurnitureType.COFFEE_TABLE -> Icons.Filled.TableBar
}
