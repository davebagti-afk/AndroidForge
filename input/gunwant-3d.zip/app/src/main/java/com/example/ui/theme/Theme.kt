package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = WalnutPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF3DFCE),
    onPrimaryContainer = WalnutDark,
    secondary = TeakAmber,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF7E5D0),
    onSecondaryContainer = Color(0xFF4A2B0D),
    tertiary = BrassGold,
    onTertiary = InkCharcoal,
    background = CreamPaper,
    onBackground = InkCharcoal,
    surface = WarmSand,
    onSurface = InkCharcoal,
    surfaceVariant = WarmCard,
    onSurfaceVariant = InkMuted,
    outline = WarmOutline,
    outlineVariant = Color(0xFFEAE2D6),
)

private val DarkColorScheme = darkColorScheme(
    primary = TeakLight,
    onPrimary = Color(0xFF2B1707),
    primaryContainer = Color(0xFF5A3317),
    onPrimaryContainer = Color(0xFFFFDCC0),
    secondary = BrassGold,
    onSecondary = Color(0xFF281A08),
    secondaryContainer = Color(0xFF423121),
    onSecondaryContainer = Color(0xFFF5DFC2),
    tertiary = TeakAmber,
    onTertiary = Color.White,
    background = StudioBgDark,
    onBackground = CreamInk,
    surface = StudioSurfaceDark,
    onSurface = CreamInk,
    surfaceVariant = StudioCardDark,
    onSurfaceVariant = MutedSandInk,
    outline = StudioOutlineDark,
    outlineVariant = Color(0xFF332B25),
)

val StudioShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp),
)

@Composable
fun GunwantStudioTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = StudioTypography,
        shapes = StudioShapes,
        content = content,
    )
}
