package com.example.model

import androidx.compose.ui.graphics.Color
import kotlin.math.floor
import kotlin.math.roundToInt

enum class AppLanguage {
    MARATHI,
    ENGLISH,
}

enum class DimensionUnit(val shortLabel: String) {
    CM("cm"),
    MM("mm"),
    INCH("in"),
    FT_IN("ft-in");

    fun formatValue(mm: Float): String {
        return when (this) {
            MM -> "${mm.roundToInt()} mm"
            CM -> {
                val cm = mm / 10f
                if (cm % 1f == 0f) "${cm.roundToInt()} cm" else String.format("%.1f cm", cm)
            }
            INCH -> {
                val inches = mm / 25.4f
                String.format("%.1f\"", inches)
            }
            FT_IN -> formatFeetInches(mm)
        }
    }

    fun formatNumberOnly(mm: Float): String {
        return when (this) {
            MM -> "${mm.roundToInt()}"
            CM -> {
                val cm = mm / 10f
                if (cm % 1f == 0f) "${cm.roundToInt()}" else String.format("%.1f", cm)
            }
            INCH -> String.format("%.1f", mm / 25.4f)
            FT_IN -> formatFeetInches(mm)
        }
    }

    fun formatLWT(lengthMm: Float, widthMm: Float, thicknessMm: Float): String {
        return when (this) {
            MM -> "${lengthMm.roundToInt()} × ${widthMm.roundToInt()} × ${thicknessMm.roundToInt()} mm"
            CM -> "${formatShortCm(lengthMm)} × ${formatShortCm(widthMm)} × ${thicknessMm.roundToInt()}mm"
            INCH, FT_IN -> String.format(
                "%.1f\" × %.1f\" × %dmm",
                lengthMm / 25.4f,
                widthMm / 25.4f,
                thicknessMm.roundToInt(),
            )
        }
    }

    private fun formatShortCm(mm: Float): String {
        val cm = mm / 10f
        return if (cm % 1f == 0f) "${cm.roundToInt()}" else String.format("%.1f", cm)
    }

    private fun formatFeetInches(mm: Float): String {
        val totalInches = (mm / 25.4f).coerceAtLeast(0f)
        var feet = floor(totalInches / 12f).toInt()
        var remInches = totalInches - feet * 12f
        if (remInches >= 11.95f) {
            feet += 1
            remInches = 0f
        }
        val inchStr = if (remInches % 1f < 0.05f || remInches % 1f > 0.95f) {
            "${remInches.roundToInt()}\""
        } else {
            String.format("%.1f\"", remInches)
        }
        return if (feet > 0) "$feet' $inchStr" else inchStr
    }
}

enum class FurnitureType(
    val id: String,
    val titleEn: String,
    val titleMr: String,
    val defaultWidthMm: Float,
    val defaultHeightMm: Float,
    val defaultDepthMm: Float,
    val minWidthMm: Float,
    val maxWidthMm: Float,
    val minHeightMm: Float,
    val maxHeightMm: Float,
    val minDepthMm: Float,
    val maxDepthMm: Float,
    val defaultShelves: Int,
    val defaultDrawers: Int,
    val supportsShelves: Boolean,
    val supportsDrawers: Boolean,
    val supportsDoors: Boolean,
    val defaultHardwareInr: Float,
) {
    WARDROBE(
        id = "wardrobe",
        titleEn = "2-Door Wardrobe",
        titleMr = "कपाट (२ दरवाजे)",
        defaultWidthMm = 1200f,
        defaultHeightMm = 2000f,
        defaultDepthMm = 560f,
        minWidthMm = 750f,
        maxWidthMm = 2400f,
        minHeightMm = 1500f,
        maxHeightMm = 2450f,
        minDepthMm = 450f,
        maxDepthMm = 700f,
        defaultShelves = 4,
        defaultDrawers = 1,
        supportsShelves = true,
        supportsDrawers = true,
        supportsDoors = true,
        defaultHardwareInr = 2600f,
    ),
    SLIDING_WARDROBE(
        id = "sliding_wardrobe",
        titleEn = "3-Door Sliding Wardrobe",
        titleMr = "स्लायडिंग कपाट (३ दरवाजे)",
        defaultWidthMm = 1800f,
        defaultHeightMm = 2100f,
        defaultDepthMm = 600f,
        minWidthMm = 1200f,
        maxWidthMm = 2800f,
        minHeightMm = 1700f,
        maxHeightMm = 2500f,
        minDepthMm = 500f,
        maxDepthMm = 720f,
        defaultShelves = 4,
        defaultDrawers = 2,
        supportsShelves = true,
        supportsDrawers = true,
        supportsDoors = true,
        defaultHardwareInr = 5200f,
    ),
    KITCHEN_CABINET(
        id = "kitchen_cabinet",
        titleEn = "Kitchen Base Unit",
        titleMr = "किचन कॅबिनेट",
        defaultWidthMm = 900f,
        defaultHeightMm = 850f,
        defaultDepthMm = 600f,
        minWidthMm = 450f,
        maxWidthMm = 1800f,
        minHeightMm = 720f,
        maxHeightMm = 950f,
        minDepthMm = 450f,
        maxDepthMm = 700f,
        defaultShelves = 1,
        defaultDrawers = 0,
        supportsShelves = true,
        supportsDrawers = false,
        supportsDoors = true,
        defaultHardwareInr = 1800f,
    ),
    POOJA_UNIT(
        id = "pooja_unit",
        titleEn = "Pooja Mandir Unit",
        titleMr = "देवघर (मंदिर)",
        defaultWidthMm = 800f,
        defaultHeightMm = 1450f,
        defaultDepthMm = 420f,
        minWidthMm = 500f,
        maxWidthMm = 1400f,
        minHeightMm = 900f,
        maxHeightMm = 2100f,
        minDepthMm = 320f,
        maxDepthMm = 600f,
        defaultShelves = 1,
        defaultDrawers = 1,
        supportsShelves = false,
        supportsDrawers = false,
        supportsDoors = true,
        defaultHardwareInr = 1500f,
    ),
    SHOE_RACK(
        id = "shoe_rack",
        titleEn = "Shoe Rack Cabinet",
        titleMr = "शू रॅक",
        defaultWidthMm = 900f,
        defaultHeightMm = 1050f,
        defaultDepthMm = 360f,
        minWidthMm = 550f,
        maxWidthMm = 1500f,
        minHeightMm = 650f,
        maxHeightMm = 1600f,
        minDepthMm = 280f,
        maxDepthMm = 460f,
        defaultShelves = 4,
        defaultDrawers = 1,
        supportsShelves = true,
        supportsDrawers = false,
        supportsDoors = true,
        defaultHardwareInr = 1400f,
    ),
    DRAWER_CHEST(
        id = "drawer_chest",
        titleEn = "Chest of Drawers",
        titleMr = "चेस्ट ऑफ ड्रॉवर्स",
        defaultWidthMm = 850f,
        defaultHeightMm = 1000f,
        defaultDepthMm = 480f,
        minWidthMm = 500f,
        maxWidthMm = 1300f,
        minHeightMm = 650f,
        maxHeightMm = 1400f,
        minDepthMm = 380f,
        maxDepthMm = 600f,
        defaultShelves = 4,
        defaultDrawers = 4,
        supportsShelves = false,
        supportsDrawers = true,
        supportsDoors = true,
        defaultHardwareInr = 2800f,
    ),
    STUDY_DESK(
        id = "study_desk",
        titleEn = "Study & Office Desk",
        titleMr = "स्टडी टेबल",
        defaultWidthMm = 1350f,
        defaultHeightMm = 750f,
        defaultDepthMm = 620f,
        minWidthMm = 900f,
        maxWidthMm = 2000f,
        minHeightMm = 680f,
        maxHeightMm = 820f,
        minDepthMm = 500f,
        maxDepthMm = 850f,
        defaultShelves = 3,
        defaultDrawers = 3,
        supportsShelves = false,
        supportsDrawers = false,
        supportsDoors = true,
        defaultHardwareInr = 2100f,
    ),
    TV_CONSOLE(
        id = "tv_console",
        titleEn = "TV Media Unit",
        titleMr = "टीव्ही युनिट",
        defaultWidthMm = 1600f,
        defaultHeightMm = 520f,
        defaultDepthMm = 420f,
        minWidthMm = 1000f,
        maxWidthMm = 2400f,
        minHeightMm = 380f,
        maxHeightMm = 700f,
        minDepthMm = 320f,
        maxDepthMm = 550f,
        defaultShelves = 1,
        defaultDrawers = 0,
        supportsShelves = false,
        supportsDrawers = false,
        supportsDoors = true,
        defaultHardwareInr = 1900f,
    ),
    BOOKSHELF(
        id = "bookshelf",
        titleEn = "Open Bookshelf",
        titleMr = "बुकशेल्फ",
        defaultWidthMm = 900f,
        defaultHeightMm = 1800f,
        defaultDepthMm = 340f,
        minWidthMm = 500f,
        maxWidthMm = 1800f,
        minHeightMm = 900f,
        maxHeightMm = 2400f,
        minDepthMm = 240f,
        maxDepthMm = 480f,
        defaultShelves = 4,
        defaultDrawers = 0,
        supportsShelves = true,
        supportsDrawers = false,
        supportsDoors = false,
        defaultHardwareInr = 600f,
    ),
    STORAGE_BED(
        id = "storage_bed",
        titleEn = "Storage Bed",
        titleMr = "स्टोरेज पलंग",
        defaultWidthMm = 1600f,
        defaultHeightMm = 980f,
        defaultDepthMm = 2050f,
        minWidthMm = 950f,
        maxWidthMm = 2000f,
        minHeightMm = 750f,
        maxHeightMm = 1250f,
        minDepthMm = 1850f,
        maxDepthMm = 2200f,
        defaultShelves = 2,
        defaultDrawers = 0,
        supportsShelves = false,
        supportsDrawers = false,
        supportsDoors = false,
        defaultHardwareInr = 3200f,
    ),
    COFFEE_TABLE(
        id = "coffee_table",
        titleEn = "Center Coffee Table",
        titleMr = "सेंटर टेबल",
        defaultWidthMm = 1050f,
        defaultHeightMm = 440f,
        defaultDepthMm = 600f,
        minWidthMm = 600f,
        maxWidthMm = 1500f,
        minHeightMm = 340f,
        maxHeightMm = 550f,
        minDepthMm = 450f,
        maxDepthMm = 900f,
        defaultShelves = 1,
        defaultDrawers = 0,
        supportsShelves = false,
        supportsDrawers = false,
        supportsDoors = false,
        defaultHardwareInr = 500f,
    );

    fun label(lang: AppLanguage): String = if (lang == AppLanguage.MARATHI) titleMr else titleEn
}

enum class WoodFinish(
    val id: String,
    val titleEn: String,
    val titleMr: String,
    val primaryColor: Color,
    val edgeColor: Color,
    val grainColor: Color,
    val isWoodGrain: Boolean,
) {
    NATURAL_TEAK(
        id = "teak",
        titleEn = "Natural Teak",
        titleMr = "सागवान (Teak)",
        primaryColor = Color(0xFFB87842),
        edgeColor = Color(0xFF8C5629),
        grainColor = Color(0xFF9C6030),
        isWoodGrain = true,
    ),
    WARM_WALNUT(
        id = "walnut",
        titleEn = "Warm Walnut",
        titleMr = "अक्रोड (Walnut)",
        primaryColor = Color(0xFF6B432B),
        edgeColor = Color(0xFF4B2E1D),
        grainColor = Color(0xFF563420),
        isWoodGrain = true,
    ),
    HONEY_OAK(
        id = "oak",
        titleEn = "Honey Oak",
        titleMr = "हनी ओक (Oak)",
        primaryColor = Color(0xFFD6A872),
        edgeColor = Color(0xFFB3844F),
        grainColor = Color(0xFFBF8E59),
        isWoodGrain = true,
    ),
    IVORY_MATTE(
        id = "ivory",
        titleEn = "Ivory Matte",
        titleMr = "आयव्हरी मॅट",
        primaryColor = Color(0xFFF0E8DA),
        edgeColor = Color(0xFFD1C6B4),
        grainColor = Color(0xFFE4DACB),
        isWoodGrain = false,
    ),
    PURE_WHITE(
        id = "white",
        titleEn = "Arctic White",
        titleMr = "पांढरा (White)",
        primaryColor = Color(0xFFF7F7F5),
        edgeColor = Color(0xFFD8D8D4),
        grainColor = Color(0xFFEBEBE7),
        isWoodGrain = false,
    ),
    CHARCOAL_SLATE(
        id = "charcoal",
        titleEn = "Charcoal Slate",
        titleMr = "चारकोल ग्रे",
        primaryColor = Color(0xFF3E4247),
        edgeColor = Color(0xFF282B2F),
        grainColor = Color(0xFF32363B),
        isWoodGrain = false,
    ),
    SAGE_GREEN(
        id = "sage",
        titleEn = "Sage Laminate",
        titleMr = "सेज ग्रीन",
        primaryColor = Color(0xFF7D9380),
        edgeColor = Color(0xFF5D7060),
        grainColor = Color(0xFF6D8270),
        isWoodGrain = false,
    ),
    TERRACOTTA(
        id = "terracotta",
        titleEn = "Terracotta Clay",
        titleMr = "टेराकोटा",
        primaryColor = Color(0xFFB5664C),
        edgeColor = Color(0xFF8C4933),
        grainColor = Color(0xFF9F543C),
        isWoodGrain = false,
    ),
    ROSEWOOD(
        id = "rosewood",
        titleEn = "Sheesham Rosewood",
        titleMr = "शीशम (Rosewood)",
        primaryColor = Color(0xFF85462D),
        edgeColor = Color(0xFF5E2F1C),
        grainColor = Color(0xFF6B3520),
        isWoodGrain = true,
    ),
    WENGE_DARK(
        id = "wenge",
        titleEn = "Dark Wenge",
        titleMr = "वेंगे डार्क",
        primaryColor = Color(0xFF3A2921),
        edgeColor = Color(0xFF231813),
        grainColor = Color(0xFF2B1E18),
        isWoodGrain = true,
    ),
    ROYAL_NAVY(
        id = "navy",
        titleEn = "Royal Navy",
        titleMr = "रॉयल नेव्ही",
        primaryColor = Color(0xFF2E4765),
        edgeColor = Color(0xFF1F3147),
        grainColor = Color(0xFF263B54),
        isWoodGrain = false,
    ),
    OLIVE_MIST(
        id = "olive",
        titleEn = "Olive Mist",
        titleMr = "ऑलिव्ह ग्रीन",
        primaryColor = Color(0xFF8C8E68),
        edgeColor = Color(0xFF6A6C4C),
        grainColor = Color(0xFF7B7D59),
        isWoodGrain = false,
    );

    fun label(lang: AppLanguage): String = if (lang == AppLanguage.MARATHI) titleMr else titleEn
}

enum class HardwareFinish(
    val id: String,
    val titleEn: String,
    val titleMr: String,
    val color: Color,
) {
    BRUSHED_BRASS("brass", "Brushed Brass", "पितळी (Brass)", Color(0xFFD4A74F)),
    MATTE_BLACK("black", "Matte Black", "मॅट ब्लॅक", Color(0xFF232325)),
    STAINLESS_STEEL("steel", "Brushed Steel", "स्टील (SS)", Color(0xFFBDC3C7));

    fun label(lang: AppLanguage): String = if (lang == AppLanguage.MARATHI) titleMr else titleEn
}

enum class RoomBackdrop(
    val id: String,
    val titleEn: String,
    val titleMr: String,
    val isRoomScene: Boolean,
    val isDark: Boolean,
    val wallColor: Color,
    val floorColor: Color,
) {
    STUDIO_WARM(
        id = "studio_warm",
        titleEn = "Warm Studio",
        titleMr = "स्टुडिओ लाइट",
        isRoomScene = false,
        isDark = false,
        wallColor = Color(0xFFF5EFE6),
        floorColor = Color(0xFFEAE0D0),
    ),
    STUDIO_DARK(
        id = "studio_dark",
        titleEn = "Dark Studio",
        titleMr = "डार्क ड्राफ्ट",
        isRoomScene = false,
        isDark = true,
        wallColor = Color(0xFF1D1916),
        floorColor = Color(0xFF120F0D),
    ),
    ROOM_CREAM(
        id = "room_cream",
        titleEn = "Cream Wall Room",
        titleMr = "क्रीम भिंत रूम",
        isRoomScene = true,
        isDark = false,
        wallColor = Color(0xFFF3ECE0),
        floorColor = Color(0xFFD5B796),
    ),
    ROOM_SAGE(
        id = "room_sage",
        titleEn = "Sage Wall Room",
        titleMr = "सेज भिंत रूम",
        isRoomScene = true,
        isDark = false,
        wallColor = Color(0xFFD9E2D7),
        floorColor = Color(0xFFCBB194),
    ),
    ROOM_SLATE(
        id = "room_slate",
        titleEn = "Slate Wall Room",
        titleMr = "ग्रे भिंत रूम",
        isRoomScene = true,
        isDark = true,
        wallColor = Color(0xFF393E46),
        floorColor = Color(0xFF5D4837),
    );

    fun label(lang: AppLanguage): String = if (lang == AppLanguage.MARATHI) titleMr else titleEn
}

enum class CameraPreset(val titleEn: String, val titleMr: String, val yawDeg: Float, val pitchDeg: Float) {
    ISO("Iso", "३डी", 34f, -22f),
    FRONT("Front", "समोर", 0f, -6f),
    SIDE("Side", "बाजू", 88f, -10f),
    TOP("Top", "वर", 12f, -72f),
}

enum class PartCategory(val titleEn: String, val titleMr: String) {
    CARCASS("Frame & Panels", "मुख्य सांगाडा"),
    SHELF("Shelves", "कप्पे / शेल्फ"),
    DOOR("Doors & Fronts", "दरवाजे / ड्रॉवर"),
    TOP("Top & Counter", "टॉप स्लॅब"),
    BACK("Back Ply", "मागील प्लाय"),
    HARDWARE("Hardware", "हार्डवेअर"),
}

data class BoxPart3D(
    val id: String,
    val groupId: String,
    val nameEn: String,
    val nameMr: String,
    val category: PartCategory,
    val centerX: Float,
    val centerY: Float,
    val centerZ: Float,
    val sizeX: Float,
    val sizeY: Float,
    val sizeZ: Float,
    val explodeX: Float = 0f,
    val explodeY: Float = 0f,
    val explodeZ: Float = 0f,
    val isDoorOrFront: Boolean = false,
    val isHardware: Boolean = false,
    val isCounterTop: Boolean = false,
    val isBackPly: Boolean = false,
    val swingPivotX: Float? = null,
    val swingPivotZ: Float? = null,
    val swingAngleMaxDeg: Float = 0f,
    val slideOffsetXMaxMm: Float = 0f,
    val slideOffsetZMaxMm: Float = 0f,
    val edgeBandingEn: String = "Front edge",
    val edgeBandingMr: String = "समोरची कडा",
)

data class CutListItem(
    val groupId: String,
    val nameEn: String,
    val nameMr: String,
    val category: PartCategory,
    val qty: Int,
    val lengthMm: Float,
    val widthMm: Float,
    val thicknessMm: Float,
    val totalAreaSqFt: Float,
    val edgeBandingEn: String,
    val edgeBandingMr: String,
) {
    fun name(lang: AppLanguage): String = if (lang == AppLanguage.MARATHI) nameMr else nameEn
    fun edgeBanding(lang: AppLanguage): String =
        if (lang == AppLanguage.MARATHI) edgeBandingMr else edgeBandingEn
}

data class CutListSummary(
    val items: List<CutListItem>,
    val totalPieces: Int,
    val totalAreaSqFt: Float,
    val estimatedSheets8x4: Int,
)

data class QuotationConfig(
    val plyRatePerSqFt: Float = 115f,
    val laminateRatePerSqFt: Float = 45f,
    val hardwareCostInr: Float = 2600f,
    val labourPercent: Float = 30f,
    val includeGst18: Boolean = false,
    val includeInPng: Boolean = true,
)

data class QuotationBreakdown(
    val plywoodCost: Float,
    val laminateCost: Float,
    val hardwareCost: Float,
    val materialSubtotal: Float,
    val labourCost: Float,
    val gstAmount: Float,
    val grandTotal: Float,
)

data class StudioConfig(
    val furnitureType: FurnitureType = FurnitureType.WARDROBE,
    val widthMm: Float = FurnitureType.WARDROBE.defaultWidthMm,
    val heightMm: Float = FurnitureType.WARDROBE.defaultHeightMm,
    val depthMm: Float = FurnitureType.WARDROBE.defaultDepthMm,
    val thicknessMm: Float = 18f,
    val shelfCount: Int = FurnitureType.WARDROBE.defaultShelves,
    val drawerCount: Int = FurnitureType.WARDROBE.defaultDrawers,
    val doorsOpen: Boolean = false,
    val explodeFactor: Float = 0f,
    val bodyFinish: WoodFinish = WoodFinish.NATURAL_TEAK,
    val doorFinish: WoodFinish? = WoodFinish.IVORY_MATTE,
    val customBodyColor: Color? = null,
    val customDoorColor: Color? = null,
    val clientOrShopName: String = "",
    val hardwareFinish: HardwareFinish = HardwareFinish.MATTE_BLACK,
    val roomBackdrop: RoomBackdrop = RoomBackdrop.ROOM_CREAM,
    val unit: DimensionUnit = DimensionUnit.FT_IN,
    val language: AppLanguage = AppLanguage.MARATHI,
    val showDimensions: Boolean = true,
    val showGrid: Boolean = true,
    val allowSheetRotation: Boolean = true,
    val quotation: QuotationConfig = QuotationConfig(),
    val selectedGroupId: String? = null,
    val yawDeg: Float = CameraPreset.ISO.yawDeg,
    val pitchDeg: Float = CameraPreset.ISO.pitchDeg,
    val zoom: Float = 1.0f,
) {
    val darkViewport: Boolean get() = roomBackdrop.isDark
}
