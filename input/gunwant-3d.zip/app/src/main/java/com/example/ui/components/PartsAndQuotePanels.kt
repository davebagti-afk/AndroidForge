package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.PackedSheet
import com.example.engine.QuotationCalculator
import com.example.engine.SheetLayoutPlan
import com.example.model.AppLanguage
import com.example.model.CutListSummary
import com.example.model.PartCategory
import com.example.model.QuotationBreakdown
import com.example.model.QuotationConfig
import com.example.model.StudioConfig
import android.graphics.Paint as AndroidPaint
import android.graphics.Typeface

@Composable
fun PartsTabContent(
    config: StudioConfig,
    cutList: CutListSummary,
    sheetPlan: SheetLayoutPlan,
    onSelectPartGroup: (String) -> Unit,
    onToggleAllowRotation: () -> Unit,
    onCopyCutList: () -> Unit,
    onExportCsv: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val lang = config.language
    var showSheetMap by rememberSaveable { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = modifier.fillMaxSize(),
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (lang == AppLanguage.MARATHI) {
                                    "मटेरियल (${cutList.totalPieces} पार्ट)"
                                } else {
                                    "Material (${cutList.totalPieces} pcs)"
                                },
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                            )
                            Text(
                                text = if (lang == AppLanguage.MARATHI) {
                                    "${String.format("%.1f", cutList.totalAreaSqFt)} sq.ft • ${sheetPlan.totalSheets} शीट (8×4) • ${sheetPlan.averageEfficiencyPct}% वापर"
                                } else {
                                    "${String.format("%.1f", cutList.totalAreaSqFt)} sq.ft • ${sheetPlan.totalSheets} sheets (8×4) • ${sheetPlan.averageEfficiencyPct}% used"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        FilledTonalButton(
                            onClick = onCopyCutList,
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("copy_cutlist_button"),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ContentCopy,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (lang == AppLanguage.MARATHI) "कॉपी" else "Copy")
                        }
                        FilledTonalButton(
                            onClick = onExportCsv,
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("export_csv_button"),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.FileDownload,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (lang == AppLanguage.MARATHI) "CSV शेअर" else "CSV")
                        }
                    }
                }
            }
        }

        // Sub-view Switch: Part List vs 8x4 Sheet Cutting Optimizer
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth(),
            ) {
                FilterChip(
                    selected = !showSheetMap,
                    onClick = { showSheetMap = false },
                    leadingIcon = {
                        Icon(Icons.Filled.List, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    label = { Text(if (lang == AppLanguage.MARATHI) "पार्ट यादी" else "Part List") },
                    modifier = Modifier.testTag("parts_subtab_list"),
                )
                FilterChip(
                    selected = showSheetMap,
                    onClick = { showSheetMap = true },
                    leadingIcon = {
                        Icon(Icons.Filled.GridView, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    label = { Text(if (lang == AppLanguage.MARATHI) "8×4 कटिंग नकाशा" else "8×4 Sheet Map") },
                    modifier = Modifier.testTag("parts_subtab_sheets"),
                )
            }
        }

        if (!showSheetMap) {
            items(cutList.items, key = { it.groupId }) { item ->
                val selected = config.selectedGroupId == item.groupId
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (selected) {
                            MaterialTheme.colorScheme.secondaryContainer
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant
                        },
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = if (selected) 1.5.dp else 1.dp,
                            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                            shape = RoundedCornerShape(12.dp),
                        )
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSelectPartGroup(item.groupId) }
                        .testTag("part_row_${item.groupId}"),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f),
                        ) {
                            Surface(
                                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp),
                            ) {
                                Text(
                                    text = "${item.qty}×",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = item.name(lang),
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                                Text(
                                    text = config.unit.formatLWT(item.lengthMm, item.widthMm, item.thicknessMm),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                                Text(
                                    text = "${if (lang == AppLanguage.MARATHI) "एज बँडिंग:" else "Edge:"} ${item.edgeBanding(lang)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                        Text(
                            text = "${String.format("%.1f", item.totalAreaSqFt)} ft²",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        } else {
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                ) {
                    Text(
                        text = if (lang == AppLanguage.MARATHI) "पार्ट फिरवून बसवा (Rotation)" else "Allow 90° Piece Rotation",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Switch(
                        checked = config.allowSheetRotation,
                        onCheckedChange = { onToggleAllowRotation() },
                        modifier = Modifier.testTag("sheet_rotation_switch"),
                    )
                }
            }

            items(sheetPlan.sheets, key = { it.sheetNumber }) { sheet ->
                SheetDiagramCard(
                    sheet = sheet,
                    lang = lang,
                    selectedGroupId = config.selectedGroupId,
                )
            }
        }
    }
}

@Composable
private fun SheetDiagramCard(
    sheet: PackedSheet,
    lang: AppLanguage,
    selectedGroupId: String?,
) {
    val density = LocalDensity.current.density
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp)),
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = if (lang == AppLanguage.MARATHI) {
                        "शीट #${sheet.sheetNumber} (${sheet.thicknessMm}mm प्लाय • 8×4 ft)"
                    } else {
                        "Sheet #${sheet.sheetNumber} (${sheet.thicknessMm}mm • 8×4 ft)"
                    },
                    style = MaterialTheme.typography.titleSmall,
                )
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(8.dp),
                ) {
                    Text(
                        text = "${sheet.efficiencyPct}%",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(2f) // 2440 : 1220 = 2 : 1
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFE7DEC8))
                    .border(1.5.dp, Color(0xFF7A4420), RoundedCornerShape(8.dp)),
            ) {
                val scaleX = size.width / sheet.sheetWidthMm
                val scaleY = size.height / sheet.sheetHeightMm
                val textPaint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
                    color = Color(0xFF1F1610).toArgb()
                    textSize = 9.5f * density
                    typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                }

                for (p in sheet.pieces) {
                    val left = p.xMm * scaleX
                    val top = p.yMm * scaleY
                    val w = p.widthMm * scaleX
                    val h = p.heightMm * scaleY
                    val isSel = selectedGroupId == p.groupId

                    val fill = when {
                        isSel -> Color(0xFFF3A847)
                        p.category == PartCategory.DOOR -> Color(0xFFD8B894)
                        p.category == PartCategory.TOP -> Color(0xFFCFA072)
                        p.category == PartCategory.SHELF -> Color(0xFFE0C8A8)
                        p.category == PartCategory.BACK -> Color(0xFFC8C2B8)
                        else -> Color(0xFFD2AA80)
                    }
                    drawRect(
                        color = fill,
                        topLeft = Offset(left, top),
                        size = Size(w, h),
                    )
                    drawRect(
                        color = if (isSel) Color(0xFF7A2E00) else Color(0xFF5D3A1F),
                        topLeft = Offset(left, top),
                        size = Size(w, h),
                        style = Stroke(width = if (isSel) 2.5f * density else 1.2f * density),
                    )

                    if (w > 34f * density && h > 16f * density) {
                        val dimLabel = "${p.origLengthMm.toInt()}×${p.origWidthMm.toInt()}"
                        drawIntoCanvas { c ->
                            c.nativeCanvas.drawText(
                                dimLabel,
                                left + 4f * density,
                                top + 12f * density,
                                textPaint,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuoteTabContent(
    config: StudioConfig,
    sheetPlan: SheetLayoutPlan,
    breakdown: QuotationBreakdown,
    onSetClientName: (String) -> Unit,
    onUpdateQuotation: ((QuotationConfig) -> QuotationConfig) -> Unit,
    onCopyQuote: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val lang = config.language
    val q = config.quotation

    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = modifier.fillMaxSize(),
    ) {
        item {
            OutlinedTextField(
                value = config.clientOrShopName,
                onValueChange = onSetClientName,
                singleLine = true,
                label = {
                    Text(
                        if (lang == AppLanguage.MARATHI) "ग्राहकाचे / दुकानाचे नाव (ऐच्छिक)" else "Customer / Shop Name (Optional)",
                    )
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("client_name_input"),
            )
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column {
                            Text(
                                text = if (lang == AppLanguage.MARATHI) "एकूण अंदाजे खर्च (Quote)" else "Estimated Total Quote",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                            )
                            Text(
                                text = QuotationCalculator.formatInr(breakdown.grandTotal),
                                style = MaterialTheme.typography.displaySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                        FilledTonalButton(
                            onClick = onCopyQuote,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("copy_quote_button"),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ContentCopy,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (lang == AppLanguage.MARATHI) "कोटेशन कॉपी" else "Copy")
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(8.dp))

                    QuoteLineRow(
                        label = if (lang == AppLanguage.MARATHI) {
                            "प्लायवूड (${sheetPlan.totalSheets} शीट × 32 ft²)"
                        } else {
                            "Plywood (${sheetPlan.totalSheets} sheets × 32 ft²)"
                        },
                        value = QuotationCalculator.formatInr(breakdown.plywoodCost),
                    )
                    QuoteLineRow(
                        label = if (lang == AppLanguage.MARATHI) "लॅमिनेट व एज बँडिंग" else "Laminate & Edge Banding",
                        value = QuotationCalculator.formatInr(breakdown.laminateCost),
                    )
                    QuoteLineRow(
                        label = if (lang == AppLanguage.MARATHI) "हार्डवेअर व फिटिंग" else "Hardware & Fittings",
                        value = QuotationCalculator.formatInr(breakdown.hardwareCost),
                    )
                    QuoteLineRow(
                        label = if (lang == AppLanguage.MARATHI) "सुतारकाम मजुरी (${q.labourPercent.toInt()}%)" else "Labour (${q.labourPercent.toInt()}%)",
                        value = QuotationCalculator.formatInr(breakdown.labourCost),
                    )
                    if (q.includeGst18) {
                        QuoteLineRow(
                            label = "GST (18%)",
                            value = QuotationCalculator.formatInr(breakdown.gstAmount),
                        )
                    }
                }
            }
        }

        item {
            RateSliderCard(
                label = if (lang == AppLanguage.MARATHI) "प्लायवूड दर (प्रति sq.ft)" else "Plywood Rate (/sq.ft)",
                valueText = "₹${q.plyRatePerSqFt.toInt()}",
                value = q.plyRatePerSqFt,
                min = 55f,
                max = 220f,
                step = 5f,
                onValueChange = { v -> onUpdateQuotation { it.copy(plyRatePerSqFt = v) } },
                testTag = "ply_rate_slider",
            )
        }

        item {
            RateSliderCard(
                label = if (lang == AppLanguage.MARATHI) "लॅमिनेट दर (प्रति sq.ft)" else "Laminate Rate (/sq.ft)",
                valueText = "₹${q.laminateRatePerSqFt.toInt()}",
                value = q.laminateRatePerSqFt,
                min = 20f,
                max = 120f,
                step = 5f,
                onValueChange = { v -> onUpdateQuotation { it.copy(laminateRatePerSqFt = v) } },
                testTag = "laminate_rate_slider",
            )
        }

        item {
            RateSliderCard(
                label = if (lang == AppLanguage.MARATHI) "हार्डवेअर व फिटिंग खर्च" else "Hardware & Fittings",
                valueText = QuotationCalculator.formatInr(q.hardwareCostInr),
                value = q.hardwareCostInr,
                min = 300f,
                max = 12000f,
                step = 250f,
                onValueChange = { v -> onUpdateQuotation { it.copy(hardwareCostInr = v) } },
                testTag = "hardware_rate_slider",
            )
        }

        item {
            RateSliderCard(
                label = if (lang == AppLanguage.MARATHI) "सुतारकाम मजुरी (%)" else "Carpentry Labour (%)",
                valueText = "${q.labourPercent.toInt()}%",
                value = q.labourPercent,
                min = 15f,
                max = 60f,
                step = 5f,
                onValueChange = { v -> onUpdateQuotation { it.copy(labourPercent = v) } },
                testTag = "labour_rate_slider",
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp)),
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            text = if (lang == AppLanguage.MARATHI) "GST (18%) जोडा" else "Include GST (18%)",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Switch(
                            checked = q.includeGst18,
                            onCheckedChange = { checked -> onUpdateQuotation { it.copy(includeGst18 = checked) } },
                            modifier = Modifier.testTag("gst_switch"),
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            text = if (lang == AppLanguage.MARATHI) "PNG मध्ये खर्च दाखवा" else "Show Quote in PNG",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Switch(
                            checked = q.includeInPng,
                            onCheckedChange = { checked -> onUpdateQuotation { it.copy(includeInPng = checked) } },
                            modifier = Modifier.testTag("quote_in_png_switch"),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QuoteLineRow(label: String, value: String) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
        )
    }
}

@Composable
private fun RateSliderCard(
    label: String,
    valueText: String,
    value: Float,
    min: Float,
    max: Float,
    step: Float,
    onValueChange: (Float) -> Unit,
    testTag: String,
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp)),
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(text = label, style = MaterialTheme.typography.titleSmall)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    IconButton(
                        onClick = { onValueChange((value - step).coerceIn(min, max)) },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface),
                    ) {
                        Icon(Icons.Filled.Remove, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(8.dp),
                    ) {
                        Text(
                            text = valueText,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        )
                    }
                    IconButton(
                        onClick = { onValueChange((value + step).coerceIn(min, max)) },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface),
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                }
            }
            Slider(
                value = value.coerceIn(min, max),
                onValueChange = onValueChange,
                valueRange = min..max,
                modifier = Modifier.testTag(testTag),
            )
        }
    }
}
