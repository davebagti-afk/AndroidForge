package com.example.engine

import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.example.model.BoxPart3D
import com.example.model.StudioConfig
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

object Renderer3D {

    private data class Vec3(val x: Float, val y: Float, val z: Float) {
        operator fun plus(o: Vec3) = Vec3(x + o.x, y + o.y, z + o.z)
        operator fun minus(o: Vec3) = Vec3(x - o.x, y - o.y, z - o.z)
        fun dot(o: Vec3): Float = x * o.x + y * o.y + z * o.z
        fun cross(o: Vec3) = Vec3(
            y * o.z - z * o.y,
            z * o.x - x * o.z,
            x * o.y - y * o.x,
        )
        fun normalized(): Vec3 {
            val len = sqrt(x * x + y * y + z * z)
            return if (len > 1e-5f) Vec3(x / len, y / len, z / len) else Vec3(0f, 1f, 0f)
        }
    }

    private data class ProjectedFace(
        val screenX: FloatArray,
        val screenY: FloatArray,
        val depthZ: Float,
        val fillColor: Int,
        val strokeColor: Int,
        val grainColor: Int?,
        val isSelected: Boolean,
        val strokeWidthPx: Float,
    )

    private val FACE_INDICES = arrayOf(
        intArrayOf(4, 5, 6, 7), // Front (+Z)
        intArrayOf(1, 0, 3, 2), // Back (-Z)
        intArrayOf(0, 4, 7, 3), // Left (-X)
        intArrayOf(5, 1, 2, 6), // Right (+X)
        intArrayOf(3, 7, 6, 2), // Top (+Y)
        intArrayOf(0, 1, 5, 4), // Bottom (-Y)
    )

    private val LIGHT_DIR = Vec3(-0.45f, 0.78f, 0.58f).normalized()

    fun drawScene(
        canvas: Canvas,
        widthPx: Float,
        heightPx: Float,
        config: StudioConfig,
        parts: List<BoxPart3D>,
        doorOpenProgress: Float,
        density: Float,
    ) {
        if (widthPx <= 10f || heightPx <= 10f) return

        val backdrop = config.roomBackdrop
        val bgTop = backdrop.wallColor.toArgb()
        val bgBottom = if (backdrop.isRoomScene) {
            shadeColor(backdrop.wallColor, 0.88f, false)
        } else {
            backdrop.floorColor.toArgb()
        }
        val bgPaint = Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, heightPx, bgTop, bgBottom, Shader.TileMode.CLAMP)
        }
        canvas.drawRect(0f, 0f, widthPx, heightPx, bgPaint)

        val maxDim = max(config.widthMm, max(config.heightMm, config.depthMm)).coerceAtLeast(500f)
        val focalDist = maxDim * 3.4f
        val minViewport = min(widthPx, heightPx)
        val scaleBase = (minViewport * 0.55f / maxDim) * config.zoom
        val centerScreenX = widthPx * 0.5f
        val centerScreenY = heightPx * 0.52f

        val yawRad = (config.yawDeg * PI / 180.0).toFloat()
        val pitchRad = (config.pitchDeg * PI / 180.0).toFloat()
        val centerWorld = Vec3(0f, config.heightMm * 0.5f, 0f)

        fun toCam(p: Vec3): Vec3 {
            val rel = p - centerWorld
            val cy = cos(yawRad)
            val sy = sin(yawRad)
            val x1 = rel.x * cy - rel.z * sy
            val z1 = rel.x * sy + rel.z * cy
            val y1 = rel.y
            val cp = cos(pitchRad)
            val sp = sin(pitchRad)
            val y2 = y1 * cp - z1 * sp
            val z2 = y1 * sp + z1 * cp
            return Vec3(x1, y2, z2)
        }

        fun project(cam: Vec3): Pair<Float, Float> {
            val denom = (focalDist - cam.z).coerceAtLeast(maxDim * 0.45f)
            val factor = (focalDist / denom) * scaleBase
            return (centerScreenX + cam.x * factor) to (centerScreenY - cam.y * factor)
        }

        // Room wall & floor scene if enabled
        if (backdrop.isRoomScene) {
            drawRoomEnvironment(
                canvas = canvas,
                config = config,
                maxDim = maxDim,
                density = density,
                toCam = ::toCam,
                project = ::project,
            )
        }

        // Architectural floor grid at Y = 0
        if (config.showGrid) {
            drawFloorGrid(
                canvas = canvas,
                config = config,
                maxDim = maxDim,
                density = density,
                toCam = ::toCam,
                project = ::project,
            )
        }

        // Soft ground contact shadow
        drawGroundShadow(
            canvas = canvas,
            config = config,
            toCam = ::toCam,
            project = ::project,
        )

        // Transform all parts into faces & depth-sort
        val explodeMm = config.explodeFactor * (maxDim * 0.14f)
        val faces = ArrayList<ProjectedFace>(parts.size * 4)

        val bodyFinish = config.bodyFinish
        val doorFinish = config.doorFinish ?: bodyFinish

        for (part in parts) {
            val hx = part.sizeX * 0.5f
            val hy = part.sizeY * 0.5f
            val hz = part.sizeZ * 0.5f

            val baseVerts = arrayOf(
                Vec3(part.centerX - hx, part.centerY - hy, part.centerZ - hz),
                Vec3(part.centerX + hx, part.centerY - hy, part.centerZ - hz),
                Vec3(part.centerX + hx, part.centerY + hy, part.centerZ - hz),
                Vec3(part.centerX - hx, part.centerY + hy, part.centerZ - hz),
                Vec3(part.centerX - hx, part.centerY - hy, part.centerZ + hz),
                Vec3(part.centerX + hx, part.centerY - hy, part.centerZ + hz),
                Vec3(part.centerX + hx, part.centerY + hy, part.centerZ + hz),
                Vec3(part.centerX - hx, part.centerY + hy, part.centerZ + hz),
            )

            val swingRad = if (part.swingPivotX != null && part.swingAngleMaxDeg != 0f && doorOpenProgress > 0.001f) {
                (part.swingAngleMaxDeg * doorOpenProgress * PI / 180.0).toFloat()
            } else {
                0f
            }

            val slideOffset = Vec3(
                part.slideOffsetXMaxMm * doorOpenProgress,
                0f,
                part.slideOffsetZMaxMm * doorOpenProgress,
            )

            val explodeOffset = Vec3(
                part.explodeX * explodeMm,
                part.explodeY * explodeMm,
                part.explodeZ * explodeMm,
            )

            val camVerts = Array(8) { idx ->
                var worldV = baseVerts[idx]
                if (swingRad != 0f && part.swingPivotX != null && part.swingPivotZ != null) {
                    val dx = worldV.x - part.swingPivotX
                    val dz = worldV.z - part.swingPivotZ
                    val cs = cos(swingRad)
                    val sn = sin(swingRad)
                    worldV = Vec3(
                        x = part.swingPivotX + dx * cs + dz * sn,
                        y = worldV.y,
                        z = part.swingPivotZ - dx * sn + dz * cs,
                    )
                }
                toCam(worldV + slideOffset + explodeOffset)
            }

            val isSelected = config.selectedGroupId != null && config.selectedGroupId == part.groupId
            val baseColor: Color
            val edgeColor: Color
            val grainColor: Color?

            val effectiveBodyColor = config.customBodyColor ?: bodyFinish.primaryColor
            val effectiveBodyEdge = config.customBodyColor?.let { darken(it, 0.24f) } ?: bodyFinish.edgeColor
            val effectiveBodyGrain = if (config.customBodyColor == null && bodyFinish.isWoodGrain) bodyFinish.grainColor else null

            val effectiveDoorColor = config.customDoorColor ?: if (config.doorFinish != null) doorFinish.primaryColor else effectiveBodyColor
            val effectiveDoorEdge = config.customDoorColor?.let { darken(it, 0.24f) }
                ?: if (config.doorFinish != null) doorFinish.edgeColor else effectiveBodyEdge
            val effectiveDoorGrain = if (config.customDoorColor == null && config.doorFinish != null && doorFinish.isWoodGrain) {
                doorFinish.grainColor
            } else if (config.customDoorColor == null && config.doorFinish == null) {
                effectiveBodyGrain
            } else {
                null
            }

            when {
                part.isHardware -> {
                    baseColor = config.hardwareFinish.color
                    edgeColor = darken(baseColor, 0.25f)
                    grainColor = null
                }
                part.isCounterTop -> {
                    baseColor = Color(0xFFECE7DF)
                    edgeColor = Color(0xFFBDB5A8)
                    grainColor = null
                }
                part.isBackPly -> {
                    baseColor = darken(effectiveBodyColor, 0.14f)
                    edgeColor = effectiveBodyEdge
                    grainColor = null
                }
                part.isDoorOrFront -> {
                    baseColor = effectiveDoorColor
                    edgeColor = effectiveDoorEdge
                    grainColor = effectiveDoorGrain
                }
                else -> {
                    baseColor = effectiveBodyColor
                    edgeColor = effectiveBodyEdge
                    grainColor = effectiveBodyGrain
                }
            }

            for (faceIdx in FACE_INDICES) {
                val v0 = camVerts[faceIdx[0]]
                val v1 = camVerts[faceIdx[1]]
                val v2 = camVerts[faceIdx[2]]
                val v3 = camVerts[faceIdx[3]]

                val normal = (v1 - v0).cross(v2 - v0).normalized()
                val centerCam = Vec3(
                    (v0.x + v1.x + v2.x + v3.x) * 0.25f,
                    (v0.y + v1.y + v2.y + v3.y) * 0.25f,
                    (v0.z + v1.z + v2.z + v3.z) * 0.25f,
                )
                val toCamera = Vec3(-centerCam.x, -centerCam.y, focalDist - centerCam.z).normalized()
                if (normal.dot(toCamera) <= 0.01f) continue

                val p0 = project(v0)
                val p1 = project(v1)
                val p2 = project(v2)
                val p3 = project(v3)

                val diffuse = max(0f, normal.dot(LIGHT_DIR))
                val lightIntensity = 0.56f + 0.44f * diffuse
                val shaded = shadeColor(baseColor, lightIntensity, isSelected)
                val outline = if (isSelected) {
                    AndroidColor.parseColor("#E69126")
                } else {
                    edgeColor.toArgb()
                }

                faces += ProjectedFace(
                    screenX = floatArrayOf(p0.first, p1.first, p2.first, p3.first),
                    screenY = floatArrayOf(p0.second, p1.second, p2.second, p3.second),
                    depthZ = centerCam.z,
                    fillColor = shaded,
                    strokeColor = outline,
                    grainColor = grainColor?.let { shadeColor(it, lightIntensity, false) },
                    isSelected = isSelected,
                    strokeWidthPx = if (isSelected) 2.2f * density else 1.0f * density,
                )
            }
        }

        faces.sortBy { it.depthZ }

        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeJoin = Paint.Join.ROUND
        }
        val grainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 0.85f * density
        }
        val quadPath = Path()

        for (face in faces) {
            quadPath.reset()
            quadPath.moveTo(face.screenX[0], face.screenY[0])
            quadPath.lineTo(face.screenX[1], face.screenY[1])
            quadPath.lineTo(face.screenX[2], face.screenY[2])
            quadPath.lineTo(face.screenX[3], face.screenY[3])
            quadPath.close()

            fillPaint.color = face.fillColor
            canvas.drawPath(quadPath, fillPaint)

            if (face.grainColor != null) {
                grainPaint.color = face.grainColor
                grainPaint.alpha = 95
                for (t in floatArrayOf(0.24f, 0.50f, 0.76f)) {
                    val ax = lerp(face.screenX[0], face.screenX[3], t)
                    val ay = lerp(face.screenY[0], face.screenY[3], t)
                    val bx = lerp(face.screenX[1], face.screenX[2], t)
                    val by = lerp(face.screenY[1], face.screenY[2], t)
                    canvas.drawLine(ax, ay, bx, by, grainPaint)
                }
            }

            strokePaint.color = face.strokeColor
            strokePaint.strokeWidth = face.strokeWidthPx
            canvas.drawPath(quadPath, strokePaint)
        }

        if (config.showDimensions) {
            drawDimensionCallouts(
                canvas = canvas,
                config = config,
                density = density,
                toCam = ::toCam,
                project = ::project,
            )
        }
    }

    private fun drawRoomEnvironment(
        canvas: Canvas,
        config: StudioConfig,
        maxDim: Float,
        density: Float,
        toCam: (Vec3) -> Vec3,
        project: (Vec3) -> Pair<Float, Float>,
    ) {
        val wallZ = -config.depthMm * 0.5f - 130f
        val halfW = maxDim * 1.35f
        val wallH = max(config.heightMm * 1.4f, maxDim * 1.15f)
        val floorFrontZ = config.depthMm * 0.5f + maxDim * 0.85f

        // Floor polygon
        val f0 = project(toCam(Vec3(-halfW, 0f, wallZ)))
        val f1 = project(toCam(Vec3(halfW, 0f, wallZ)))
        val f2 = project(toCam(Vec3(halfW, 0f, floorFrontZ)))
        val f3 = project(toCam(Vec3(-halfW, 0f, floorFrontZ)))
        val floorPath = Path().apply {
            moveTo(f0.first, f0.second)
            lineTo(f1.first, f1.second)
            lineTo(f2.first, f2.second)
            lineTo(f3.first, f3.second)
            close()
        }
        val floorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = config.roomBackdrop.floorColor.toArgb()
        }
        canvas.drawPath(floorPath, floorPaint)

        // Draw back wall only if camera is mostly looking from front (avoid hiding model from rear view)
        val wallCamZ = toCam(Vec3(0f, config.heightMm * 0.5f, wallZ)).z
        val modelCamZ = toCam(Vec3(0f, config.heightMm * 0.5f, 0f)).z
        if (wallCamZ < modelCamZ) {
            val w0 = project(toCam(Vec3(-halfW, 0f, wallZ)))
            val w1 = project(toCam(Vec3(halfW, 0f, wallZ)))
            val w2 = project(toCam(Vec3(halfW, wallH, wallZ)))
            val w3 = project(toCam(Vec3(-halfW, wallH, wallZ)))
            val wallPath = Path().apply {
                moveTo(w0.first, w0.second)
                lineTo(w1.first, w1.second)
                lineTo(w2.first, w2.second)
                lineTo(w3.first, w3.second)
                close()
            }
            val wallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = shadeColor(config.roomBackdrop.wallColor, 0.96f, false)
            }
            canvas.drawPath(wallPath, wallPaint)

            // Wall baseboard skirting strip (90mm high)
            val sk0 = project(toCam(Vec3(-halfW, 0f, wallZ + 2f)))
            val sk1 = project(toCam(Vec3(halfW, 0f, wallZ + 2f)))
            val sk2 = project(toCam(Vec3(halfW, 90f, wallZ + 2f)))
            val sk3 = project(toCam(Vec3(-halfW, 90f, wallZ + 2f)))
            val skirtingPath = Path().apply {
                moveTo(sk0.first, sk0.second)
                lineTo(sk1.first, sk1.second)
                lineTo(sk2.first, sk2.second)
                lineTo(sk3.first, sk3.second)
                close()
            }
            val skirtingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = shadeColor(config.roomBackdrop.wallColor, 0.78f, false)
            }
            canvas.drawPath(skirtingPath, skirtingPaint)

            val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = shadeColor(config.roomBackdrop.wallColor, 0.68f, false)
                strokeWidth = 1.2f * density
            }
            canvas.drawLine(w0.first, w0.second, w1.first, w1.second, cornerPaint)
        }
    }

    private fun drawFloorGrid(
        canvas: Canvas,
        config: StudioConfig,
        maxDim: Float,
        density: Float,
        toCam: (Vec3) -> Vec3,
        project: (Vec3) -> Pair<Float, Float>,
    ) {
        val gridHalf = maxDim * 0.9f
        val step = (gridHalf / 4f)
        val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (config.darkViewport) AndroidColor.argb(42, 240, 224, 200) else AndroidColor.argb(45, 110, 82, 55)
            strokeWidth = 1f * density
        }
        val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (config.darkViewport) AndroidColor.argb(85, 220, 160, 90) else AndroidColor.argb(75, 130, 80, 40)
            strokeWidth = 1.4f * density
        }

        for (i in -4..4) {
            val offset = i * step
            val pA = project(toCam(Vec3(offset, 0f, -gridHalf)))
            val pB = project(toCam(Vec3(offset, 0f, gridHalf)))
            canvas.drawLine(pA.first, pA.second, pB.first, pB.second, if (i == 0) axisPaint else gridPaint)

            val pC = project(toCam(Vec3(-gridHalf, 0f, offset)))
            val pD = project(toCam(Vec3(gridHalf, 0f, offset)))
            canvas.drawLine(pC.first, pC.second, pD.first, pD.second, if (i == 0) axisPaint else gridPaint)
        }
    }

    private fun drawGroundShadow(
        canvas: Canvas,
        config: StudioConfig,
        toCam: (Vec3) -> Vec3,
        project: (Vec3) -> Pair<Float, Float>,
    ) {
        val hw = config.widthMm * 0.54f
        val hd = config.depthMm * 0.54f
        val c0 = project(toCam(Vec3(-hw, 1f, -hd)))
        val c1 = project(toCam(Vec3(hw, 1f, -hd)))
        val c2 = project(toCam(Vec3(hw, 1f, hd)))
        val c3 = project(toCam(Vec3(-hw, 1f, hd)))

        val shadowPath = Path().apply {
            moveTo(c0.first, c0.second)
            lineTo(c1.first, c1.second)
            lineTo(c2.first, c2.second)
            lineTo(c3.first, c3.second)
            close()
        }
        val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = if (config.darkViewport) AndroidColor.argb(65, 0, 0, 0) else AndroidColor.argb(32, 60, 40, 20)
        }
        canvas.drawPath(shadowPath, shadowPaint)
    }

    private fun drawDimensionCallouts(
        canvas: Canvas,
        config: StudioConfig,
        density: Float,
        toCam: (Vec3) -> Vec3,
        project: (Vec3) -> Pair<Float, Float>,
    ) {
        val hw = config.widthMm * 0.5f
        val hd = config.depthMm * 0.5f
        val h = config.heightMm
        val offset = max(80f, min(140f, max(hw, hd) * 0.22f))

        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (config.darkViewport) AndroidColor.parseColor("#E8B06B") else AndroidColor.parseColor("#7A4420")
            strokeWidth = 1.4f * density
            pathEffect = DashPathEffect(floatArrayOf(6f * density, 4f * density), 0f)
        }
        val pillBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (config.darkViewport) AndroidColor.argb(215, 36, 30, 26) else AndroidColor.argb(230, 255, 252, 247)
            style = Paint.Style.FILL
        }
        val pillStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (config.darkViewport) AndroidColor.parseColor("#E8B06B") else AndroidColor.parseColor("#B87A45")
            strokeWidth = 1f * density
            style = Paint.Style.STROKE
        }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (config.darkViewport) AndroidColor.parseColor("#FFF4E4") else AndroidColor.parseColor("#3B2110")
            textSize = 11.5f * density
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        fun drawDimLine(a: Vec3, b: Vec3, label: String) {
            val pa = project(toCam(a))
            val pb = project(toCam(b))
            canvas.drawLine(pa.first, pa.second, pb.first, pb.second, linePaint)
            val mx = (pa.first + pb.first) * 0.5f
            val my = (pa.second + pb.second) * 0.5f
            val tw = textPaint.measureText(label)
            val padX = 7f * density
            val padY = 4f * density
            val fm = textPaint.fontMetrics
            val textH = fm.descent - fm.ascent
            val rect = RectF(
                mx - tw * 0.5f - padX,
                my - textH * 0.5f - padY,
                mx + tw * 0.5f + padX,
                my + textH * 0.5f + padY,
            )
            canvas.drawRoundRect(rect, 6f * density, 6f * density, pillBgPaint)
            canvas.drawRoundRect(rect, 6f * density, 6f * density, pillStrokePaint)
            canvas.drawText(label, mx, my - (fm.ascent + fm.descent) * 0.5f, textPaint)
        }

        drawDimLine(
            Vec3(-hw, 0f, hd + offset),
            Vec3(hw, 0f, hd + offset),
            "W ${config.unit.formatValue(config.widthMm)}",
        )

        drawDimLine(
            Vec3(hw + offset, 0f, -hd),
            Vec3(hw + offset, h, -hd),
            "H ${config.unit.formatValue(config.heightMm)}",
        )

        drawDimLine(
            Vec3(-hw - offset, 0f, -hd),
            Vec3(-hw - offset, 0f, hd),
            "D ${config.unit.formatValue(config.depthMm)}",
        )
    }

    private fun shadeColor(color: Color, intensity: Float, highlight: Boolean): Int {
        val factor = if (highlight) min(1.22f, intensity * 1.16f) else intensity
        val r = (color.red * factor).coerceIn(0f, 1f)
        val g = (color.green * factor).coerceIn(0f, 1f)
        val b = (color.blue * factor).coerceIn(0f, 1f)
        return AndroidColor.rgb((r * 255).toInt(), (g * 255).toInt(), (b * 255).toInt())
    }

    private fun darken(color: Color, amount: Float): Color {
        val f = (1f - amount).coerceIn(0f, 1f)
        return Color(color.red * f, color.green * f, color.blue * f, color.alpha)
    }

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t
}
