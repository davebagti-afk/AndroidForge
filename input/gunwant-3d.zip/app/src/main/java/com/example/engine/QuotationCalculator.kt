package com.example.engine

import com.example.model.CutListSummary
import com.example.model.QuotationBreakdown
import com.example.model.QuotationConfig
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.roundToLong

object QuotationCalculator {

    fun calculate(
        cutList: CutListSummary,
        sheetPlan: SheetLayoutPlan,
        quotation: QuotationConfig,
    ): QuotationBreakdown {
        // Use actual sheet sq.ft (32 sq.ft per 8x4 sheet) or cut area * 1.12, whichever gives realistic shop billing
        val billableSqFt = (sheetPlan.totalSheets.coerceAtLeast(1) * 32f)
            .coerceAtLeast(cutList.totalAreaSqFt * 1.10f)
        val plywoodCost = billableSqFt * quotation.plyRatePerSqFt
        // Laminate covers outer/inner visible faces (~1.35x board area)
        val laminateCost = (cutList.totalAreaSqFt * 1.35f) * quotation.laminateRatePerSqFt
        val hardwareCost = quotation.hardwareCostInr
        val materialSubtotal = plywoodCost + laminateCost + hardwareCost
        val labourCost = materialSubtotal * (quotation.labourPercent / 100f)
        val beforeGst = materialSubtotal + labourCost
        val gstAmount = if (quotation.includeGst18) beforeGst * 0.18f else 0f
        val grandTotal = beforeGst + gstAmount

        return QuotationBreakdown(
            plywoodCost = plywoodCost,
            laminateCost = laminateCost,
            hardwareCost = hardwareCost,
            materialSubtotal = materialSubtotal,
            labourCost = labourCost,
            gstAmount = gstAmount,
            grandTotal = grandTotal,
        )
    }

    fun formatInr(amount: Float): String {
        val nf = NumberFormat.getNumberInstance(Locale("en", "IN"))
        return "₹ ${nf.format(amount.roundToLong())}"
    }
}
