package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.StudioPreferences
import com.example.engine.FurnitureBuilder
import com.example.engine.QuotationCalculator
import com.example.engine.SheetLayoutPlan
import com.example.engine.SheetOptimizer
import com.example.export.PngExporter
import com.example.model.AppLanguage
import com.example.model.BoxPart3D
import com.example.model.CameraPreset
import com.example.model.CutListSummary
import com.example.model.DimensionUnit
import com.example.model.FurnitureType
import com.example.model.HardwareFinish
import com.example.model.QuotationBreakdown
import com.example.model.QuotationConfig
import com.example.model.RoomBackdrop
import com.example.model.StudioConfig
import com.example.model.WoodFinish
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class StudioTab(val titleEn: String, val titleMr: String) {
    DESIGN("Design", "प्रकार"),
    SIZE("Size", "मापे"),
    FINISH("Finish", "रंग"),
    PARTS("Parts", "पार्ट्स"),
    QUOTE("Quote ₹", "खर्च ₹");

    fun label(lang: AppLanguage): String = if (lang == AppLanguage.MARATHI) titleMr else titleEn
}

sealed class StudioEvent {
    data class ShowMessage(val message: String) : StudioEvent()
    data class LaunchSafSave(val fileName: String, val bitmap: Bitmap) : StudioEvent()
    data class LaunchShareIntent(val uri: Uri, val mimeType: String, val subject: String) : StudioEvent()
}

data class StudioUiState(
    val config: StudioConfig = StudioConfig(),
    val parts: List<BoxPart3D> = emptyList(),
    val cutList: CutListSummary = CutListSummary(emptyList(), 0, 0f, 1),
    val sheetPlan: SheetLayoutPlan = SheetLayoutPlan(emptyList(), 0, 0),
    val quotationBreakdown: QuotationBreakdown = QuotationBreakdown(0f, 0f, 0f, 0f, 0f, 0f, 0f),
    val activeTab: StudioTab = StudioTab.DESIGN,
    val isExporting: Boolean = false,
)

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = StudioPreferences(application.applicationContext)

    private val _uiState = MutableStateFlow(recomputeState(StudioConfig(), StudioTab.DESIGN))
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<StudioEvent>()
    val events: SharedFlow<StudioEvent> = _events.asSharedFlow()

    private var pendingSafBitmap: Bitmap? = null

    init {
        viewModelScope.launch {
            val saved = prefs.prefsFlow.first()
            updateConfig {
                it.copy(
                    language = saved.language,
                    unit = saved.unit,
                    showDimensions = saved.showDimensions,
                    showGrid = saved.showGrid,
                    roomBackdrop = saved.roomBackdrop,
                )
            }
        }
    }

    private fun recomputeState(config: StudioConfig, tab: StudioTab): StudioUiState {
        val parts = FurnitureBuilder.buildParts(config)
        val cutList = FurnitureBuilder.buildCutList(parts)
        val sheetPlan = SheetOptimizer.packSheets(cutList.items, config.allowSheetRotation)
        val breakdown = QuotationCalculator.calculate(cutList, sheetPlan, config.quotation)
        return StudioUiState(
            config = config,
            parts = parts,
            cutList = cutList,
            sheetPlan = sheetPlan,
            quotationBreakdown = breakdown,
            activeTab = tab,
        )
    }

    private fun updateConfig(transform: (StudioConfig) -> StudioConfig) {
        _uiState.update { current ->
            val nextConfig = transform(current.config)
            recomputeState(nextConfig, current.activeTab).copy(isExporting = current.isExporting)
        }
    }

    fun selectTab(tab: StudioTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun selectFurnitureType(type: FurnitureType) {
        updateConfig {
            it.copy(
                furnitureType = type,
                widthMm = type.defaultWidthMm,
                heightMm = type.defaultHeightMm,
                depthMm = type.defaultDepthMm,
                shelfCount = type.defaultShelves,
                drawerCount = type.defaultDrawers,
                doorsOpen = false,
                explodeFactor = 0f,
                selectedGroupId = null,
                quotation = it.quotation.copy(hardwareCostInr = type.defaultHardwareInr),
                yawDeg = CameraPreset.ISO.yawDeg,
                pitchDeg = CameraPreset.ISO.pitchDeg,
                zoom = 1.0f,
            )
        }
    }

    fun setWidthMm(widthMm: Float) {
        updateConfig {
            it.copy(widthMm = widthMm.coerceIn(it.furnitureType.minWidthMm, it.furnitureType.maxWidthMm))
        }
    }

    fun setHeightMm(heightMm: Float) {
        updateConfig {
            it.copy(heightMm = heightMm.coerceIn(it.furnitureType.minHeightMm, it.furnitureType.maxHeightMm))
        }
    }

    fun setDepthMm(depthMm: Float) {
        updateConfig {
            it.copy(depthMm = depthMm.coerceIn(it.furnitureType.minDepthMm, it.furnitureType.maxDepthMm))
        }
    }

    fun setThicknessMm(thicknessMm: Float) {
        updateConfig { it.copy(thicknessMm = thicknessMm) }
    }

    fun setShelfCount(count: Int) {
        updateConfig { it.copy(shelfCount = count.coerceIn(1, 6)) }
    }

    fun setDrawerCount(count: Int) {
        val minD = if (itMinDrawerIs3()) 3 else 0
        val maxD = if (itMinDrawerIs3()) 6 else 2
        updateConfig { it.copy(drawerCount = count.coerceIn(minD, maxD)) }
    }

    private fun itMinDrawerIs3(): Boolean =
        _uiState.value.config.furnitureType == FurnitureType.DRAWER_CHEST

    fun toggleDoorsOpen() {
        updateConfig { it.copy(doorsOpen = !it.doorsOpen) }
    }

    fun setExplodeFactor(factor: Float) {
        updateConfig { it.copy(explodeFactor = factor.coerceIn(0f, 1f)) }
    }

    fun setBodyFinish(finish: WoodFinish) {
        updateConfig { it.copy(bodyFinish = finish, customBodyColor = null) }
    }

    fun setDoorFinish(finish: WoodFinish?) {
        updateConfig { it.copy(doorFinish = finish, customDoorColor = null) }
    }

    fun setCustomBodyColor(color: androidx.compose.ui.graphics.Color?) {
        updateConfig { it.copy(customBodyColor = color) }
    }

    fun setCustomDoorColor(color: androidx.compose.ui.graphics.Color?) {
        updateConfig { it.copy(customDoorColor = color) }
    }

    fun setClientOrShopName(name: String) {
        updateConfig { it.copy(clientOrShopName = name) }
    }

    fun setHardwareFinish(finish: HardwareFinish) {
        updateConfig { it.copy(hardwareFinish = finish) }
    }

    fun setRoomBackdrop(backdrop: RoomBackdrop) {
        updateConfig { it.copy(roomBackdrop = backdrop) }
        viewModelScope.launch { prefs.setRoomBackdrop(backdrop) }
    }

    fun toggleAllowSheetRotation() {
        updateConfig { it.copy(allowSheetRotation = !it.allowSheetRotation) }
    }

    fun updateQuotation(transform: (QuotationConfig) -> QuotationConfig) {
        updateConfig { it.copy(quotation = transform(it.quotation)) }
    }

    fun selectPartGroup(groupId: String?) {
        updateConfig {
            val next = if (it.selectedGroupId == groupId) null else groupId
            it.copy(selectedGroupId = next)
        }
    }

    fun applyCameraPreset(preset: CameraPreset) {
        updateConfig {
            it.copy(
                yawDeg = preset.yawDeg,
                pitchDeg = preset.pitchDeg,
                zoom = 1.0f,
            )
        }
    }

    fun orbitBy(deltaX: Float, deltaY: Float) {
        _uiState.update { state ->
            val nextYaw = (state.config.yawDeg + deltaX * 0.42f) % 360f
            val nextPitch = (state.config.pitchDeg + deltaY * 0.35f).coerceIn(-85f, 15f)
            state.copy(
                config = state.config.copy(
                    yawDeg = nextYaw,
                    pitchDeg = nextPitch,
                ),
            )
        }
    }

    fun zoomBy(scaleFactor: Float) {
        _uiState.update { state ->
            val nextZoom = (state.config.zoom * scaleFactor).coerceIn(0.55f, 2.2f)
            state.copy(config = state.config.copy(zoom = nextZoom))
        }
    }

    fun toggleLanguage() {
        val next = if (_uiState.value.config.language == AppLanguage.MARATHI) {
            AppLanguage.ENGLISH
        } else {
            AppLanguage.MARATHI
        }
        updateConfig { it.copy(language = next) }
        viewModelScope.launch { prefs.setLanguage(next) }
    }

    fun setUnit(unit: DimensionUnit) {
        updateConfig { it.copy(unit = unit) }
        viewModelScope.launch { prefs.setUnit(unit) }
    }

    fun toggleDimensions() {
        val next = !_uiState.value.config.showDimensions
        updateConfig { it.copy(showDimensions = next) }
        viewModelScope.launch { prefs.setShowDimensions(next) }
    }

    fun toggleGrid() {
        val next = !_uiState.value.config.showGrid
        updateConfig { it.copy(showGrid = next) }
        viewModelScope.launch { prefs.setShowGrid(next) }
    }

    fun cycleBackdrop() {
        val entries = RoomBackdrop.entries
        val nextIdx = (entries.indexOf(_uiState.value.config.roomBackdrop) + 1) % entries.size
        setRoomBackdrop(entries[nextIdx])
    }

    fun savePng() {
        val state = _uiState.value
        if (state.isExporting) return
        viewModelScope.launch {
            _uiState.update { it.copy(isExporting = true) }
            val doorProg = if (state.config.doorsOpen) 1f else 0f
            val bitmap = withContext(Dispatchers.Default) {
                PngExporter.renderStudioSheetBitmap(
                    config = state.config,
                    parts = state.parts,
                    cutList = state.cutList,
                    sheetPlan = state.sheetPlan,
                    quotation = state.quotationBreakdown,
                    doorOpenProgress = doorProg,
                )
            }
            val fileName = PngExporter.buildFileName(state.config)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val uri = withContext(Dispatchers.IO) {
                    PngExporter.savePngToMediaStore(getApplication(), bitmap, fileName)
                }
                bitmap.recycle()
                _uiState.update { it.copy(isExporting = false) }
                val msg = if (uri != null) {
                    if (state.config.language == AppLanguage.MARATHI) {
                        "PNG गॅलरीमध्ये सेव्ह झाली (Pictures/Gunwant3D)"
                    } else {
                        "Saved PNG to Pictures/Gunwant3D"
                    }
                } else {
                    if (state.config.language == AppLanguage.MARATHI) {
                        "PNG सेव्ह करताना अडचण आली"
                    } else {
                        "Could not save PNG"
                    }
                }
                _events.emit(StudioEvent.ShowMessage(msg))
            } else {
                pendingSafBitmap = bitmap
                _uiState.update { it.copy(isExporting = false) }
                _events.emit(StudioEvent.LaunchSafSave(fileName, bitmap))
            }
        }
    }

    fun completeSafSave(uri: Uri?) {
        val bitmap = pendingSafBitmap
        pendingSafBitmap = null
        if (uri == null || bitmap == null) {
            bitmap?.recycle()
            return
        }
        val lang = _uiState.value.config.language
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                PngExporter.writePngToUri(getApplication(), bitmap, uri)
            }
            bitmap.recycle()
            val msg = if (ok) {
                if (lang == AppLanguage.MARATHI) "PNG फाईल सेव्ह झाली" else "PNG saved successfully"
            } else {
                if (lang == AppLanguage.MARATHI) "PNG सेव्ह होऊ शकली नाही" else "Failed to save PNG"
            }
            _events.emit(StudioEvent.ShowMessage(msg))
        }
    }

    fun sharePng() {
        val state = _uiState.value
        if (state.isExporting) return
        viewModelScope.launch {
            _uiState.update { it.copy(isExporting = true) }
            val doorProg = if (state.config.doorsOpen) 1f else 0f
            val uri = withContext(Dispatchers.Default) {
                val bitmap = PngExporter.renderStudioSheetBitmap(
                    config = state.config,
                    parts = state.parts,
                    cutList = state.cutList,
                    sheetPlan = state.sheetPlan,
                    quotation = state.quotationBreakdown,
                    doorOpenProgress = doorProg,
                )
                val fileName = PngExporter.buildFileName(state.config)
                val outUri = withContext(Dispatchers.IO) {
                    PngExporter.exportToCacheForShare(getApplication(), bitmap, fileName)
                }
                bitmap.recycle()
                outUri
            }
            _uiState.update { it.copy(isExporting = false) }
            if (uri != null) {
                _events.emit(
                    StudioEvent.LaunchShareIntent(
                        uri = uri,
                        mimeType = "image/png",
                        subject = "Gunwant 3D - ${state.config.furnitureType.label(state.config.language)}",
                    ),
                )
            } else {
                val msg = if (state.config.language == AppLanguage.MARATHI) {
                    "PNG शेअर तयार होऊ शकली नाही"
                } else {
                    "Could not prepare PNG to share"
                }
                _events.emit(StudioEvent.ShowMessage(msg))
            }
        }
    }

    fun shareCsvCutList() {
        val state = _uiState.value
        if (state.isExporting) return
        viewModelScope.launch {
            _uiState.update { it.copy(isExporting = true) }
            val uri = withContext(Dispatchers.IO) {
                PngExporter.exportCsvToCacheForShare(
                    context = getApplication(),
                    config = state.config,
                    cutList = state.cutList,
                    sheetPlan = state.sheetPlan,
                    quotation = state.quotationBreakdown,
                )
            }
            _uiState.update { it.copy(isExporting = false) }
            if (uri != null) {
                _events.emit(
                    StudioEvent.LaunchShareIntent(
                        uri = uri,
                        mimeType = "text/csv",
                        subject = "Gunwant 3D Cut-List - ${state.config.furnitureType.label(state.config.language)}",
                    ),
                )
            } else {
                val msg = if (state.config.language == AppLanguage.MARATHI) {
                    "CSV एक्सपोर्ट तयार होऊ शकली नाही"
                } else {
                    "Could not export CSV"
                }
                _events.emit(StudioEvent.ShowMessage(msg))
            }
        }
    }

    fun buildFormattedCutListText(): String {
        val state = _uiState.value
        val cfg = state.config
        val lang = cfg.language
        val sb = StringBuilder()
        sb.appendLine("Gunwant 3D Furniture Studio")
        sb.appendLine("${cfg.furnitureType.label(lang)}: ${cfg.unit.formatValue(cfg.widthMm)} × ${cfg.unit.formatValue(cfg.heightMm)} × ${cfg.unit.formatValue(cfg.depthMm)}")
        sb.appendLine(
            if (lang == AppLanguage.MARATHI) {
                "मटेरियल: ${cfg.bodyFinish.label(lang)} | दरवाजे: ${(cfg.doorFinish ?: cfg.bodyFinish).label(lang)} | जाडी: ${cfg.thicknessMm.toInt()} mm"
            } else {
                "Finish: ${cfg.bodyFinish.label(lang)} | Front: ${(cfg.doorFinish ?: cfg.bodyFinish).label(lang)} | Board: ${cfg.thicknessMm.toInt()} mm"
            }
        )
        sb.appendLine("--------------------")
        state.cutList.items.forEach { item ->
            sb.appendLine(
                "${item.qty}× ${item.name(lang)} — ${cfg.unit.formatLWT(item.lengthMm, item.widthMm, item.thicknessMm)} (${item.edgeBanding(lang)})"
            )
        }
        sb.appendLine("--------------------")
        sb.appendLine(
            if (lang == AppLanguage.MARATHI) {
                "एकूण नग: ${state.cutList.totalPieces} | क्षेत्रफळ: ${String.format("%.1f", state.cutList.totalAreaSqFt)} sq.ft | पॅक्ड शीट्स (8×4): ${state.sheetPlan.totalSheets} (${state.sheetPlan.averageEfficiencyPct}% वापर)"
            } else {
                "Total Pieces: ${state.cutList.totalPieces} | Area: ${String.format("%.1f", state.cutList.totalAreaSqFt)} sq.ft | Packed Sheets (8×4): ${state.sheetPlan.totalSheets} (${state.sheetPlan.averageEfficiencyPct}% used)"
            }
        )
        return sb.toString()
    }

    fun buildFormattedQuotationText(): String {
        val state = _uiState.value
        val cfg = state.config
        val lang = cfg.language
        val q = state.quotationBreakdown
        return if (lang == AppLanguage.MARATHI) {
            buildString {
                appendLine("*Gunwant 3D Furniture Studio - कोटेशन*")
                if (cfg.clientOrShopName.isNotBlank()) {
                    appendLine("नाव / दुकान: ${cfg.clientOrShopName.trim()}")
                }
                appendLine("प्रकार: ${cfg.furnitureType.label(lang)}")
                appendLine("मापे: ${cfg.unit.formatValue(cfg.widthMm)} × ${cfg.unit.formatValue(cfg.heightMm)} × ${cfg.unit.formatValue(cfg.depthMm)}")
                appendLine("फिनिश: ${cfg.bodyFinish.label(lang)} / ${(cfg.doorFinish ?: cfg.bodyFinish).label(lang)}")
                appendLine("--------------------")
                appendLine("• प्लायवूड (${state.sheetPlan.totalSheets} शीट 8×4): ${QuotationCalculator.formatInr(q.plywoodCost)}")
                appendLine("• लॅमिनेट व एज बँडिंग: ${QuotationCalculator.formatInr(q.laminateCost)}")
                appendLine("• हार्डवेअर व फिटिंग: ${QuotationCalculator.formatInr(q.hardwareCost)}")
                appendLine("• सुतारकाम मजुरी (${cfg.quotation.labourPercent.toInt()}%): ${QuotationCalculator.formatInr(q.labourCost)}")
                if (cfg.quotation.includeGst18) {
                    appendLine("• GST (18%): ${QuotationCalculator.formatInr(q.gstAmount)}")
                }
                appendLine("--------------------")
                appendLine("*एकूण अंदाजे खर्च: ${QuotationCalculator.formatInr(q.grandTotal)}*")
            }
        } else {
            buildString {
                appendLine("*Gunwant 3D Furniture Studio - Estimate*")
                if (cfg.clientOrShopName.isNotBlank()) {
                    appendLine("Client / Shop: ${cfg.clientOrShopName.trim()}")
                }
                appendLine("Item: ${cfg.furnitureType.label(lang)}")
                appendLine("Size: ${cfg.unit.formatValue(cfg.widthMm)} × ${cfg.unit.formatValue(cfg.heightMm)} × ${cfg.unit.formatValue(cfg.depthMm)}")
                appendLine("Finish: ${cfg.bodyFinish.label(lang)} / ${(cfg.doorFinish ?: cfg.bodyFinish).label(lang)}")
                appendLine("--------------------")
                appendLine("• Plywood (${state.sheetPlan.totalSheets} sheets 8×4): ${QuotationCalculator.formatInr(q.plywoodCost)}")
                appendLine("• Laminate & Edge Banding: ${QuotationCalculator.formatInr(q.laminateCost)}")
                appendLine("• Hardware & Fittings: ${QuotationCalculator.formatInr(q.hardwareCost)}")
                appendLine("• Labour (${cfg.quotation.labourPercent.toInt()}%): ${QuotationCalculator.formatInr(q.labourCost)}")
                if (cfg.quotation.includeGst18) {
                    appendLine("• GST (18%): ${QuotationCalculator.formatInr(q.gstAmount)}")
                }
                appendLine("--------------------")
                appendLine("*Estimated Total: ${QuotationCalculator.formatInr(q.grandTotal)}*")
            }
        }
    }
}
