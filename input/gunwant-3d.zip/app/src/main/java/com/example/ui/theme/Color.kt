package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm Architectural Joinery Workshop Palette
val WalnutPrimary = Color(0xFF7A4420)
val WalnutDark = Color(0xFF542D13)
val TeakAmber = Color(0xFFC87D32)
val BrassGold = Color(0xFFD9A05B)

val CreamPaper = Color(0xFFFAF6F0)
val WarmSand = Color(0xFFF2ECE1)
val WarmCard = Color(0xFFFFFFFF)
val WarmOutline = Color(0xFFDCD2C4)
val InkCharcoal = Color(0xFF201A16)
val InkMuted = Color(0xFF6B5D52)

// Dark Drafting Studio Palette
val StudioBgDark = Color(0xFF151210)
val StudioSurfaceDark = Color(0xFF211C18)
val StudioCardDark = Color(0xFF2B241F)
val StudioOutlineDark = Color(0xFF453B33)
val CreamInk = Color(0xFFF5EFE6)
val MutedSandInk = Color(0xFFBBAE9F)
val TeakLight = Color(0xFFE6A259)
