package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DoorSliding
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.outlined.DoorSliding
import androidx.compose.material.icons.outlined.GridOff
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.Renderer3D
import com.example.model.AppLanguage
import com.example.model.BoxPart3D
import com.example.model.CameraPreset
import com.example.model.StudioConfig
import kotlin.math.abs

@Composable
fun Viewport3D(
    config: StudioConfig,
    parts: List<BoxPart3D>,
    onOrbit: (Float, Float) -> Unit,
    onZoom: (Float) -> Unit,
    onSelectCameraPreset: (CameraPreset) -> Unit,
    onToggleDoors: () -> Unit,
    onToggleExplode: () -> Unit,
    onToggleDimensions: () -> Unit,
    onToggleGrid: () -> Unit,
    onCycleBackdrop: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current.density
    val doorOpenProgress by animateFloatAsState(
        targetValue = if (config.doorsOpen) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMediumLow,
        ),
        label = "door_swing",
    )

    val lang = config.language
    val isDarkVp = config.darkViewport
    val overlayBg = if (isDarkVp) Color(0xCC241E1A) else Color(0xE6FFFFFF)
    val overlayFg = if (isDarkVp) Color(0xFFF6EFE6) else Color(0xFF281E17)
    val overlayBorder = if (isDarkVp) Color(0xFF4A3D34) else Color(0xFFDCD0C0)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
            .testTag("viewport_3d_canvas"),
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        if (abs(pan.x) > 0.1f || abs(pan.y) > 0.1f) {
                            onOrbit(pan.x, pan.y)
                        }
                        if (abs(zoom - 1f) > 0.002f) {
                            onZoom(zoom)
                        }
                    }
                },
        ) {
            drawIntoCanvas { canvas ->
                Renderer3D.drawScene(
                    canvas = canvas.nativeCanvas,
                    widthPx = size.width,
                    heightPx = size.height,
                    config = config,
                    parts = parts,
                    doorOpenProgress = doorOpenProgress,
                    density = density,
                )
            }
        }

        // Top-left Furniture HUD Badge
        Surface(
            color = overlayBg,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(10.dp)
                .border(1.dp, overlayBorder, RoundedCornerShape(12.dp)),
        ) {
            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                Text(
                    text = config.furnitureType.label(lang),
                    style = MaterialTheme.typography.labelLarge,
                    color = overlayFg,
                )
                Text(
                    text = "${config.unit.formatValue(config.widthMm)} × ${config.unit.formatValue(config.heightMm)} × ${config.unit.formatValue(config.depthMm)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    text = config.roomBackdrop.label(lang),
                    style = MaterialTheme.typography.labelSmall,
                    color = overlayFg.copy(alpha = 0.72f),
                )
            }
        }

        // Top-right Room/Studio Backdrop cycler + Zoom Controls
        Column(
            verticalArrangement = Arrangement.spacedBy(6.dp),
            horizontalAlignment = Alignment.End,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(10.dp),
        ) {
            ViewportIconButton(
                icon = if (config.roomBackdrop.isRoomScene) Icons.Filled.Home else Icons.Outlined.Home,
                contentDescription = if (lang == AppLanguage.MARATHI) "खोली / स्टुडिओ बॅकग्राउंड बदला" else "Cycle room/studio backdrop",
                active = config.roomBackdrop.isRoomScene,
                overlayBg = overlayBg,
                overlayFg = overlayFg,
                overlayBorder = overlayBorder,
                onClick = onCycleBackdrop,
                testTag = "toggle_backdrop_button",
            )
            ViewportIconButton(
                icon = Icons.Filled.Add,
                contentDescription = if (lang == AppLanguage.MARATHI) "झूम इन" else "Zoom in",
                active = false,
                overlayBg = overlayBg,
                overlayFg = overlayFg,
                overlayBorder = overlayBorder,
                onClick = { onZoom(1.15f) },
                testTag = "zoom_in_button",
            )
            ViewportIconButton(
                icon = Icons.Filled.Remove,
                contentDescription = if (lang == AppLanguage.MARATHI) "झूम आउट" else "Zoom out",
                active = false,
                overlayBg = overlayBg,
                overlayFg = overlayFg,
                overlayBorder = overlayBorder,
                onClick = { onZoom(0.87f) },
                testTag = "zoom_out_button",
            )
        }

        // Bottom-left Camera Presets
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(10.dp),
        ) {
            CameraPreset.entries.forEach { preset ->
                val isSelected = abs(config.yawDeg - preset.yawDeg) < 4f &&
                    abs(config.pitchDeg - preset.pitchDeg) < 4f
                Surface(
                    color = if (isSelected) MaterialTheme.colorScheme.primary else overlayBg,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .border(
                            1.dp,
                            if (isSelected) MaterialTheme.colorScheme.primary else overlayBorder,
                            RoundedCornerShape(10.dp),
                        )
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onSelectCameraPreset(preset) }
                        .minimumInteractiveComponentSize()
                        .testTag("camera_preset_${preset.name.lowercase()}"),
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    ) {
                        Text(
                            text = if (lang == AppLanguage.MARATHI) preset.titleMr else preset.titleEn,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else overlayFg,
                        )
                    }
                }
            }
        }

        // Bottom-right Quick Tools: Doors/Drawers Open, Explode, Dims, Grid
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(10.dp),
        ) {
            if (config.furnitureType.supportsDoors) {
                ViewportIconButton(
                    icon = if (config.doorsOpen) Icons.Filled.DoorSliding else Icons.Outlined.DoorSliding,
                    contentDescription = if (lang == AppLanguage.MARATHI) "दरवाजे / ड्रॉवर उघडा" else "Toggle doors/drawers open",
                    active = config.doorsOpen,
                    overlayBg = overlayBg,
                    overlayFg = overlayFg,
                    overlayBorder = overlayBorder,
                    onClick = onToggleDoors,
                    testTag = "toggle_doors_button",
                )
            }
            ViewportIconButton(
                icon = Icons.Filled.OpenInFull,
                contentDescription = if (lang == AppLanguage.MARATHI) "पार्ट सुटे पहा (Explode)" else "Toggle exploded view",
                active = config.explodeFactor > 0.05f,
                overlayBg = overlayBg,
                overlayFg = overlayFg,
                overlayBorder = overlayBorder,
                onClick = onToggleExplode,
                testTag = "toggle_explode_button",
            )
            ViewportIconButton(
                icon = Icons.Filled.Straighten,
                contentDescription = if (lang == AppLanguage.MARATHI) "मापे दाखवा / लपवा" else "Toggle dimensions",
                active = config.showDimensions,
                overlayBg = overlayBg,
                overlayFg = overlayFg,
                overlayBorder = overlayBorder,
                onClick = onToggleDimensions,
                testTag = "toggle_dims_button",
            )
            ViewportIconButton(
                icon = if (config.showGrid) Icons.Filled.GridOn else Icons.Outlined.GridOff,
                contentDescription = if (lang == AppLanguage.MARATHI) "ग्रिड दाखवा / लपवा" else "Toggle floor grid",
                active = config.showGrid,
                overlayBg = overlayBg,
                overlayFg = overlayFg,
                overlayBorder = overlayBorder,
                onClick = onToggleGrid,
                testTag = "toggle_grid_button",
            )
        }
    }
}

@Composable
private fun ViewportIconButton(
    icon: ImageVector,
    contentDescription: String,
    active: Boolean,
    overlayBg: Color,
    overlayFg: Color,
    overlayBorder: Color,
    onClick: () -> Unit,
    testTag: String,
) {
    val bg = if (active) MaterialTheme.colorScheme.primary else overlayBg
    val fg = if (active) MaterialTheme.colorScheme.onPrimary else overlayFg
    val border = if (active) MaterialTheme.colorScheme.primary else overlayBorder

    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(bg)
            .border(1.dp, border, CircleShape)
            .testTag(testTag),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = fg,
            modifier = Modifier.size(20.dp),
        )
    }
}
