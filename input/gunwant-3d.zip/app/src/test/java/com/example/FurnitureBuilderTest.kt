package com.example

import com.example.engine.FurnitureBuilder
import com.example.engine.QuotationCalculator
import com.example.engine.SheetOptimizer
import com.example.model.DimensionUnit
import com.example.model.FurnitureType
import com.example.model.QuotationConfig
import com.example.model.StudioConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FurnitureBuilderTest {

    @Test
    fun `all 11 furniture types generate parts cut lists sheets and quotation`() {
        for (type in FurnitureType.entries) {
            val config = StudioConfig(
                furnitureType = type,
                widthMm = type.defaultWidthMm,
                heightMm = type.defaultHeightMm,
                depthMm = type.defaultDepthMm,
                shelfCount = type.defaultShelves,
                drawerCount = type.defaultDrawers,
            )
            val parts = FurnitureBuilder.buildParts(config)
            val cutList = FurnitureBuilder.buildCutList(parts)
            val sheetPlan = SheetOptimizer.packSheets(cutList.items, allowRotation = true)
            val quote = QuotationCalculator.calculate(cutList, sheetPlan, QuotationConfig())

            assertTrue("Parts empty for $type", parts.isNotEmpty())
            assertTrue("CutList empty for $type", cutList.items.isNotEmpty())
            assertTrue("SheetPlan empty for $type", sheetPlan.totalSheets >= 1)
            assertTrue("Efficiency out of range for $type", sheetPlan.averageEfficiencyPct in 1..100)
            assertTrue("Quote <= 0 for $type", quote.grandTotal > 0f)
        }
    }

    @Test
    fun `wardrobe shelf count and drawer count change generated parts`() {
        val cfgBase = StudioConfig(furnitureType = FurnitureType.WARDROBE, shelfCount = 2, drawerCount = 0)
        val cfgMore = StudioConfig(furnitureType = FurnitureType.WARDROBE, shelfCount = 5, drawerCount = 2)

        val partsBase = FurnitureBuilder.buildParts(cfgBase)
        val partsMore = FurnitureBuilder.buildParts(cfgMore)

        // +3 shelves + 1 drawer cover shelf + 2 drawer fronts = +6 parts
        assertEquals(partsBase.size + 6, partsMore.size)
    }

    @Test
    fun `ft-in formatter converts standard 8x4 sheet dimensions cleanly`() {
        assertEquals("8' 0\"", DimensionUnit.FT_IN.formatValue(2438.4f))
        assertEquals("4' 0\"", DimensionUnit.FT_IN.formatValue(1219.2f))
    }
}
